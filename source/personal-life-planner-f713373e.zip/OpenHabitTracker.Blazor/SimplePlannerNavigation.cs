using OpenHabitTracker.Blazor.Pages;
namespace OpenHabitTracker.Blazor;

public static class SimplePlannerNavigation
{
    public static bool IsAllowed(Type page) => page == typeof(Home) || page == typeof(Today)
        || page == typeof(PlannerCalendar) || page == typeof(Workouts)
        || page == typeof(SimpleTaskEditor) || page == typeof(SimpleSettings);
    // Project old preferences/notification links without changing persisted data.
    public static string Resolve(string? path)
    {
        string route = (path ?? "").Trim('/').Split('?', '#')[0];
        if (route is "calendar" or "preferences" or "today") return route;
        if (route is "settings" or "data" or "more") return "preferences";
        if (route is "sport" or "workouts") return "sport";
        var parts = route.Split('/');
        if (parts.Length == 2 && long.TryParse(parts[1], out long id) && id > 0)
        {
            if (parts[0] is "task" or "tasks") return $"task/{id}";
            if (parts[0] is "sport" or "workouts") return $"sport/{id}";
        }
        return "today";
    }
}
