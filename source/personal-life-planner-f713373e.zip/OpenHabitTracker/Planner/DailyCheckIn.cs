using System.Text.Json;
using OpenHabitTracker.Data.Models;

namespace OpenHabitTracker.Planner;

// Additive note envelope: uses the existing local store, export/import and sync.
public sealed class DailyCheckIn
{
    public const string Prefix = "<!-- personal-life-planner:checkin:v1 -->\n```json\n";
    public DateTime Date { get; set; } = DateTime.Today;
    public int Energy { get; set; } = 3;
    public string Mood { get; set; } = "Спокойно";
    public static readonly string[] Moods = ["Отлично", "Хорошо", "Спокойно", "Усталость", "Непросто"];
    public string ToContent() => Prefix + JsonSerializer.Serialize(this) + "\n```";
    public static DailyCheckIn? FromNote(NoteModel note)
    {
        if (note.IsDeleted || !note.Content.StartsWith(Prefix, StringComparison.Ordinal) || !note.Content.EndsWith("\n```", StringComparison.Ordinal)) return null;
        try
        {
            var value = JsonSerializer.Deserialize<DailyCheckIn>(note.Content[Prefix.Length..^4]);
            return value is not null && value.Energy is >= 1 and <= 5 && Moods.Contains(value.Mood) ? value : null;
        }
        catch (JsonException) { return null; }
    }
}
