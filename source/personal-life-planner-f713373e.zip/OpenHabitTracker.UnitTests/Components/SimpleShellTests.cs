using Bunit;
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.DependencyInjection;
using NSubstitute;
using OpenHabitTracker.Blazor;
using OpenHabitTracker.Blazor.Layout;
using OpenHabitTracker.Blazor.Pages;
using OpenHabitTracker.Data.Models;

namespace OpenHabitTracker.UnitTests.Components;
[TestFixture]
public class SimpleShellTests
{
    private static void Prepare(AppTestContext app)
    {
        app.Ctx.Services.AddSingleton(Substitute.For<INavBarFragment>());
        app.JsInterop.GetWindowDimensions().Returns(new Dimensions { Width = 393, Height = 852 });
    }
    [Test]
    public async Task DefaultShell_HasThreeTabsOneSettingsLinkAndNoSamples()
    {
        using AppTestContext app = new(); Prepare(app); await app.Store.Initialize();
        var cut = app.Ctx.Render<Main>();
        cut.WaitForElement("#main-content");
        Assert.Multiple(() =>
        {
            Assert.That(cut.FindAll(".kos-bottom-nav a").Select(x => x.TextContent.Trim()), Is.EqualTo(new[] { "Сегодня", "Календарь", "Спорт" }));
            Assert.That(cut.FindAll("a[href='preferences']").Count, Is.EqualTo(1));
            Assert.That(cut.Find(".kos-brand").TextContent, Does.Not.Contain("@if").And.Not.Contain("PERSONAL OS"));
            Assert.That(cut.FindAll(".kos-legacy-nav,#sidebar-container,[data-main-step-1],[data-main-step-6],[data-main-step-7]"), Is.Empty);
        });
        Assert.That(await app.Store.GetNotes(), Is.Empty);
        Assert.That(await app.Store.GetCategories(), Is.Empty);
        Assert.That(await app.Store.GetSettings(), Has.Count.EqualTo(1));
    }
    [Test]
    public async Task OldLaunchPreferences_AreProjectedSafelyButNotOverwritten()
    {
        using AppTestContext app = new(); Prepare(app);
        await app.Start(s => { s.StartPage = "/habits"; s.StartSidebar = "Data"; s.ShowHelp = true; });
        await app.ClientState.UpdateSettings();
        var cut = app.Ctx.Render<Main>(); cut.WaitForElement("#main-content");
        Assert.That(cut.FindAll("#sidebar-container"), Is.Empty);
        Assert.That(app.Get<NavigationManager>().Uri, Does.EndWith("today"));
        var settings = (await app.Store.GetSettings()).Single();
        Assert.That(settings.StartPage, Is.EqualTo("/habits"));
        Assert.That(settings.StartSidebar, Is.EqualTo("Data"));
    }
    [TestCase("notes", "today")]
    [TestCase("habits/5", "today")]
    [TestCase("progress", "today")]
    [TestCase("/tasks/12", "task/12")]
    [TestCase("/workouts/4", "sport/4")]
    [TestCase("/settings", "preferences")]
    [TestCase("calendar", "calendar")]
    public void LegacyDestinations_MapToSimpleExperience(string oldPath,string expected) =>
        Assert.That(SimplePlannerNavigation.Resolve(oldPath), Is.EqualTo(expected));
    [Test]
    public void ComplexPageTypes_AreNotReachableThroughTheSimpleRouter()
    {
        Assert.Multiple(() =>
        {
            Assert.That(SimplePlannerNavigation.IsAllowed(typeof(Tasks)), Is.False);
            Assert.That(SimplePlannerNavigation.IsAllowed(typeof(Habits)), Is.False);
            Assert.That(SimplePlannerNavigation.IsAllowed(typeof(OpenHabitTracker.Blazor.Pages.Data)), Is.False);
            Assert.That(SimplePlannerNavigation.IsAllowed(typeof(Settings)), Is.False);
            Assert.That(SimplePlannerNavigation.IsAllowed(typeof(PlannerProgress)), Is.False);
            Assert.That(SimplePlannerNavigation.IsAllowed(typeof(Today)), Is.True);
            Assert.That(SimplePlannerNavigation.IsAllowed(typeof(SimpleTaskEditor)), Is.True);
            Assert.That(SimplePlannerNavigation.IsAllowed(typeof(SimpleSettings)), Is.True);
        });
    }
}
