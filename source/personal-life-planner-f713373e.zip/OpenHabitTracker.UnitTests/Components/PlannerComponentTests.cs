using AngleSharp.Dom;
using Bunit;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using OpenHabitTracker.Blazor.Pages;
using OpenHabitTracker.Data;
using OpenHabitTracker.Data.Models;
using OpenHabitTracker.Planner;
using OpenHabitTracker.Services;

namespace OpenHabitTracker.UnitTests.Components;

[TestFixture]
public class PlannerComponentTests
{
    private static IElement Button<T>(IRenderedComponent<T> cut, string name) where T : IComponent =>
        cut.FindAll("button").Single(b => b.TextContent.Trim() == name || b.GetAttribute("aria-label") == name);

    private static IElement Field<T>(IRenderedComponent<T> cut, string name) where T : IComponent
    {
        var accessible = cut.FindAll($"input[aria-label='{name}'], select[aria-label='{name}'], textarea[aria-label='{name}']");
        if (accessible.Count > 0) return accessible.Single();
        return cut.FindAll("label").Single(label => label.TextContent.Trim().StartsWith(name, StringComparison.Ordinal))
            .QuerySelector("input,select,textarea")!;
    }

    [Test]
    public async Task QuickAdd_InputEnablesSaveAndCompletionPersists()
    {
        using AppTestContext app = new();
        await app.Start();
        var cut = app.Ctx.Render<Today>();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("input"), Is.Not.Empty));
        var save = Button(cut, "Добавить");
        Assert.That(save.HasAttribute("disabled"), Is.True);
        Field(cut, "Задача").Input("Купить продукты");
        Assert.That(Button(cut, "Добавить").HasAttribute("disabled"), Is.False);
        Button(cut, "Добавить").Click();
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Купить продукты")));
        var stored = (await app.Store.GetTasks()).Single();
        Assert.Multiple(() =>
        {
            Assert.That(stored.Title, Is.EqualTo("Купить продукты"));
            Assert.That(stored.PlannedAt?.Date, Is.EqualTo(DateTime.Today));
            Assert.That(cut.Find($"a[href='task/{stored.Id}']").TextContent, Is.EqualTo("Купить продукты"));
        });
        cut.Find("button[aria-label='Выполнить']").Click();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("button[aria-label='Отменить выполнение']"), Has.Count.EqualTo(1)));
        Assert.That((await app.Store.GetTask(stored.Id))!.CompletedAt, Is.Not.Null);
    }

    [TestCase(-2)]
    [TestCase(2)]
    public async Task SimpleTaskEditor_TitleAndOptionalScheduleSaveWithoutReplacingOtherFields(int dayOffset)
    {
        using AppTestContext app = new();
        await app.Start();
        ITaskService tasks = app.Get<ITaskService>();
        DateTime planned = DateTime.Today.AddDays(dayOffset).AddHours(9).AddMinutes(30);
        var initial = new TaskModel { Title = "Исходное дело", PlannedAt = planned, Priority = Priority.High, Color = "bg-warning-subtle", Duration = new TimeOnly(0, 45), Items = [new ItemModel { Title = "Пункт списка" }] };
        await app.ClientState.AddUserData([new CategoryModel { Title = "Дом", Tasks = [initial] }]);
        await tasks.Initialize();
        var task = tasks.Tasks!.Single();
        var originalEntity = (await app.Store.GetTask(task.Id))!;
        Assert.That(originalEntity.CategoryId, Is.GreaterThan(0));
        var cut = app.Ctx.Render<SimpleTaskEditor>(parameters => parameters.Add(p => p.Id, task.Id));
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("input[aria-label='Название задачи']"), Has.Count.EqualTo(1)));
        Assert.That(cut.Find("details").HasAttribute("open"), Is.False);
        Field(cut, "Название задачи").Input("Изменённое дело");
        Assert.That(Button(cut, "Сохранить").HasAttribute("disabled"), Is.False);
        cut.Find("form").Submit();
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Сохранено.")));
        var renamed = (await app.Store.GetTask(task.Id))!;
        Assert.Multiple(() =>
        {
            Assert.That(renamed.Title, Is.EqualTo("Изменённое дело"));
            Assert.That(renamed.PlannedAt, Is.EqualTo(planned));
            Assert.That(renamed.Priority, Is.EqualTo(Priority.High));
            Assert.That(renamed.Color, Is.EqualTo("bg-warning-subtle"));
            Assert.That(renamed.CategoryId, Is.EqualTo(originalEntity.CategoryId));
            Assert.That(renamed.Duration, Is.EqualTo(new TimeOnly(0, 45)));
        });
        var checklistItem = (await app.Store.GetItems()).Single();
        Assert.That(checklistItem.Title, Is.EqualTo("Пункт списка"));
        Assert.That(checklistItem.DoneAt, Is.Null);
        Field(cut, "Дата задачи").Change("2030-02-17");
        Field(cut, "Время задачи").Change("14:15");
        cut.Find("form").Submit();
        var moved = (await app.Store.GetTask(task.Id))!;
        Assert.That(moved.PlannedAt, Is.EqualTo(new DateTime(2030, 2, 17, 14, 15, 0)));
        Assert.That((await app.Store.GetTasks()), Has.Count.EqualTo(1));
        Button(cut, "Выполнить").Click();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("button").Any(button => button.TextContent.Trim() == "Отменить выполнение"), Is.True));
        Assert.That((await app.Store.GetTask(task.Id))!.CompletedAt, Is.Not.Null);
        Assert.That((await app.Store.GetItems()).Single().DoneAt, Is.Not.Null);
    }

    [Test]
    public async Task SportQuickEntry_RequiresOnlyDateKindAndMinutesAndDefaultsToCompletedLog()
    {
        using AppTestContext app = new();
        await app.Start();
        var cut = app.Ctx.Render<Workouts>();
        cut.WaitForAssertion(() => Assert.That(cut.Find("h1").TextContent, Is.EqualTo("Спорт")));
        Button(cut, "Новая тренировка").Click();
        Assert.That(cut.Find("details").HasAttribute("open"), Is.False);
        Assert.That(cut.FindAll("form > label"), Has.Count.EqualTo(3));
        Assert.That(Field(cut, "Вид тренировки").QuerySelectorAll("option").Select(option => option.TextContent),
            Is.EqualTo(new[] { "Бокс", "Силовая", "Кардио", "Другое" }));
        Assert.That(cut.Find("input[type=checkbox]").HasAttribute("checked"), Is.True);
        Field(cut, "Вид тренировки").Change("Кардио");
        Field(cut, "Продолжительность, мин").Change("35");
        Assert.That(Button(cut, "Сохранить тренировку").GetAttribute("type"), Is.EqualTo("submit"));
        cut.Find("form").Submit();
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Тренировка сохранена.")));
        var note = (await app.Store.GetNotes()).Single();
        var stored = Workout.FromNote(new NoteModel { Content = note.Content })!;
        Assert.Multiple(() =>
        {
            Assert.That(stored.Date.Date, Is.EqualTo(DateTime.Today));
            Assert.That(stored.Kind, Is.EqualTo("Кардио"));
            Assert.That(stored.Minutes, Is.EqualTo(35));
            Assert.That(stored.Completed, Is.True);
            Assert.That(stored.Exercises, Is.Empty);
            Assert.That(stored.Notes, Is.Empty);
            Assert.That(stored.Feeling, Is.Empty);
        });
        cut.Render(parameters => parameters.Add(p => p.Id, note.Id));
        Assert.That(cut.FindAll(".kos-workout-detail"), Has.Count.EqualTo(1));
        Assert.That(cut.FindAll(".kos-workout-detail section"), Is.Empty); // absent optional values do not produce empty blocks
    }

    [TestCase(false)]
    [TestCase(true)]
    public async Task SportEdit_ChangingDurationPreservesExistingFlagPastDateAndCollapsedExtras(bool completed)
    {
        using AppTestContext app = new();
        await app.Start();
        INoteService notes = app.Get<INoteService>();
        await notes.Initialize();
        DateTime pastDate = DateTime.Today.AddDays(-4);
        Workout workout = new() { Date = pastDate, Kind = "Силовая", Completed = completed, Minutes = 45, Notes = "Подробная запись", Feeling = "Бодро", Exercises = [new() { Name = "Жим", Sets = 3, Reps = 8, Weight = 62.5m }] };
        var original = new NoteModel { Title = "Прошлая тренировка", Content = workout.ToContent() };
        notes.NewNote = original;
        await notes.AddNote();
        var cut = app.Ctx.Render<Workouts>(parameters => parameters.Add(p => p.Id, original.Id));
        cut.WaitForAssertion(() => Assert.That(cut.FindAll(".kos-workout-detail"), Has.Count.EqualTo(1)));
        Assert.That(cut.Find(".kos-workout-detail").TextContent, Does.Contain("Подробная запись").And.Contain("Бодро").And.Contain("Жим"));
        Button(cut, "Редактировать").Click();
        Assert.Multiple(() =>
        {
            Assert.That(cut.Find("details").HasAttribute("open"), Is.False);
            Assert.That(cut.FindAll(".kos-workout-detail"), Is.Empty);
            Assert.That(cut.Find("input[type=checkbox]").HasAttribute("checked"), Is.EqualTo(completed));
        });
        Field(cut, "Продолжительность, мин").Change("55");
        Assert.That(Button(cut, "Сохранить тренировку").GetAttribute("type"), Is.EqualTo("submit"));
        cut.Find("form").Submit();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("form"), Is.Empty));
        var stored = (await app.Store.GetNotes()).Single();
        var edited = Workout.FromNote(new NoteModel { Content = stored.Content })!;
        Assert.Multiple(() =>
        {
            Assert.That(stored.Id, Is.EqualTo(original.Id));
            Assert.That(edited.Date, Is.EqualTo(pastDate));
            Assert.That(edited.Kind, Is.EqualTo("Силовая"));
            Assert.That(edited.Completed, Is.EqualTo(completed));
            Assert.That(edited.Minutes, Is.EqualTo(55));
            Assert.That(edited.Notes, Is.EqualTo(workout.Notes));
            Assert.That(edited.Feeling, Is.EqualTo(workout.Feeling));
            Assert.That(edited.Exercises.Single().Name, Is.EqualTo("Жим"));
            Assert.That(edited.Exercises.Single().Sets, Is.EqualTo(3));
            Assert.That(edited.Exercises.Single().Reps, Is.EqualTo(8));
            Assert.That(edited.Exercises.Single().Weight, Is.EqualTo(62.5m));
        });
        cut.Render(parameters => parameters.Add(p => p.Id, (long?)null));
        Assert.That(cut.FindAll(".kos-workout-detail"), Is.Empty);
        Assert.That(cut.FindAll($"a[href='sport/{original.Id}']"), Has.Count.EqualTo(1));
    }

    [Test]
    public async Task SportRouteChange_DiscardsUnsavedEditorAndNeverWritesThePreviouslySelectedRecord()
    {
        using AppTestContext app = new();
        await app.Start();
        INoteService notes = app.Get<INoteService>();
        await notes.Initialize();
        var first = new NoteModel { Title = "Первая", Content = new Workout { Kind = "Бокс", Minutes = 45, Completed = true }.ToContent() };
        var second = new NoteModel { Title = "Вторая", Content = new Workout { Kind = "Кардио", Minutes = 60, Completed = true }.ToContent() };
        notes.NewNote = first; await notes.AddNote();
        notes.NewNote = second; await notes.AddNote();
        var cut = app.Ctx.Render<Workouts>(parameters => parameters.Add(p => p.Id, first.Id));
        cut.WaitForAssertion(() => Assert.That(cut.FindAll(".kos-workout-detail"), Has.Count.EqualTo(1)));
        Button(cut, "Редактировать").Click();
        Field(cut, "Продолжительность, мин").Change("99");
        cut.Render(parameters => parameters.Add(p => p.Id, (long?)null));
        Assert.That(cut.FindAll("form"), Is.Empty);
        cut.Render(parameters => parameters.Add(p => p.Id, second.Id));
        Assert.That(cut.FindAll("form"), Is.Empty);
        Assert.That(cut.Find(".kos-workout-detail h2").TextContent, Is.EqualTo("Кардио"));
        Button(cut, "Редактировать").Click();
        Field(cut, "Продолжительность, мин").Change("65");
        cut.Find("form").Submit();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("form"), Is.Empty));
        Assert.That(Workout.FromNote(new NoteModel { Content = (await app.Store.GetNote(first.Id))!.Content })!.Minutes, Is.EqualTo(45));
        Assert.That(Workout.FromNote(new NoteModel { Content = (await app.Store.GetNote(second.Id))!.Content })!.Minutes, Is.EqualTo(65));

        cut.Render(parameters => parameters.Add(p => p.Id, (long?)null));
        Button(cut, "Новая тренировка").Click();
        Field(cut, "Продолжительность, мин").Change("20");
        Assert.That(cut.FindAll(".simple-sport-history"), Is.Empty);
        cut.Render(parameters => parameters.Add(p => p.Id, first.Id));
        Assert.That(cut.FindAll("form"), Is.Empty);
        Assert.That(cut.Find(".kos-workout-detail h2").TextContent, Is.EqualTo("Бокс"));
        Assert.That(await app.Store.GetNotes(), Has.Count.EqualTo(2));
    }

    [Test]
    public async Task SportBlankDuration_ShowsParsingErrorAndDoesNotSilentlySaveThePreviousNumber()
    {
        using AppTestContext app = new();
        await app.Start();
        INoteService notes = app.Get<INoteService>();
        await notes.Initialize();
        var original = new NoteModel { Title = "Тренировка", Content = new Workout { Minutes = 45, Completed = true }.ToContent() };
        notes.NewNote = original; await notes.AddNote();
        string originalContent = original.Content;
        var cut = app.Ctx.Render<Workouts>(parameters => parameters.Add(p => p.Id, original.Id));
        cut.WaitForAssertion(() => Assert.That(cut.FindAll(".kos-workout-detail"), Has.Count.EqualTo(1)));
        Button(cut, "Редактировать").Click();
        Field(cut, "Продолжительность, мин").Change("");
        cut.Find("form").Submit();
        cut.WaitForAssertion(() => Assert.That(cut.Find("[role='status']").TextContent, Does.Contain("Проверьте")));
        Assert.That(cut.FindAll("form"), Has.Count.EqualTo(1));
        Assert.That((await app.Store.GetNote(original.Id))!.Content, Is.EqualTo(originalContent));
        Assert.That(await app.Store.GetNotes(), Has.Count.EqualTo(1));
        Field(cut, "Продолжительность, мин").Change("50");
        cut.Find("form").Submit();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("form"), Is.Empty));
        Assert.That(Workout.FromNote(new NoteModel { Content = (await app.Store.GetNote(original.Id))!.Content })!.Minutes, Is.EqualTo(50));
    }

    [Test]
    public async Task TaskEditor_ClearingDateThenQueuedTimeClearKeepsTaskUnscheduled()
    {
        using AppTestContext app = new();
        await app.Start();
        ITaskService tasks = app.Get<ITaskService>();
        await tasks.Initialize();
        var task = new TaskModel { Title = "Убрать расписание", PlannedAt = DateTime.Today.AddDays(2).AddHours(9) };
        tasks.NewTask = task; await tasks.AddTask();
        var cut = app.Ctx.Render<SimpleTaskEditor>(parameters => parameters.Add(p => p.Id, task.Id));
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("input[aria-label='Дата задачи']"), Has.Count.EqualTo(1)));
        Field(cut, "Дата задачи").Change("");
        // A time-clear callback already queued by the browser can arrive after the date changed.
        var time = cut.FindComponents<InputDate<TimeOnly?>>().Single();
        await cut.InvokeAsync(() => time.Instance.ValueChanged.InvokeAsync((TimeOnly?)null));
        cut.Find("form").Submit();
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Сохранено.")));
        Assert.That((await app.Store.GetTask(task.Id))!.PlannedAt, Is.Null);
        cut.Render(parameters => parameters.Add(p => p.Id, task.Id));
        Assert.That(Field(cut, "Дата задачи").GetAttribute("value"), Is.Null.Or.Empty);
        Assert.That(Field(cut, "Время задачи").GetAttribute("value"), Is.Null.Or.Empty);
    }

    [Test]
    public async Task QuickTask_ClearingOptionalDateAndTimeSavesUndatedTask()
    {
        using AppTestContext app = new();
        await app.Start();
        var cut = app.Ctx.Render<Today>();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("input[aria-label='Дата задачи']"), Has.Count.EqualTo(1)));
        Field(cut, "Задача").Input("Дело без даты");
        Field(cut, "Дата задачи").Change("");
        var time = cut.FindComponents<InputDate<TimeOnly?>>().Single();
        await cut.InvokeAsync(() => time.Instance.ValueChanged.InvokeAsync((TimeOnly?)null));
        cut.Find("form").Submit();
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Дело без даты")));
        Assert.That((await app.Store.GetTasks()).Single().PlannedAt, Is.Null);
        Assert.That(cut.Markup, Does.Contain("Без даты"));
    }

    [Test]
    public async Task TodayReschedule_ClearingDatePersistsAsUndatedTask()
    {
        using AppTestContext app = new();
        await app.Start();
        ITaskService tasks = app.Get<ITaskService>();
        await tasks.Initialize();
        var task = new TaskModel { Title = "Снять дату переноса", PlannedAt = DateTime.Today.AddHours(9) };
        tasks.NewTask = task; await tasks.AddTask();
        var cut = app.Ctx.Render<Today>();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("input[aria-label='Перенести на дату']"), Has.Count.EqualTo(1)));
        Field(cut, "Перенести на дату").Change("");
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Без даты")));
        Assert.That((await app.Store.GetTask(task.Id))!.PlannedAt, Is.Null);
    }

    [Test]
    public async Task SportDetail_MissingRecordLeavesOtherNotesUntouched()
    {
        using AppTestContext app = new();
        await app.Start();
        var cut = app.Ctx.Render<Workouts>(parameters => parameters.Add(p => p.Id, 99999));
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Запись не найдена")));
        Assert.That(cut.FindAll(".kos-workout-detail"), Is.Empty);
        Assert.That(await app.Store.GetNotes(), Is.Empty);
    }
}
