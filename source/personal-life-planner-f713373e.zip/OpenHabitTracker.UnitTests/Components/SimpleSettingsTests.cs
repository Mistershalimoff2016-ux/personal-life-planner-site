using Bunit;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.Extensions.DependencyInjection;
using OpenHabitTracker.App;
using OpenHabitTracker.Blazor.Files;
using OpenHabitTracker.Blazor.Pages;
using OpenHabitTracker.Data;
using OpenHabitTracker.Data.Models;
using OpenHabitTracker.Planner;
using System.Text.Json;

namespace OpenHabitTracker.UnitTests.Components;

[TestFixture]
public class SimpleSettingsTests
{
    private AppTestContext _app = null!;
    private RecordingSaveFile _save = null!;
    private ClientState _state = null!;
    private static readonly DateTime Planned = new(2030, 6, 4, 10, 0, 0);

    private sealed class RecordingSaveFile : ISaveFile
    {
        public List<(string Filename, string Content)> Files { get; } = [];
        public Task<string> SaveFileDialog(string filename, string content)
        {
            Files.Add((filename, content));
            return Task.FromResult(filename);
        }
    }

    [SetUp]
    public async Task SetUp()
    {
        _app = new AppTestContext();
        _save = new RecordingSaveFile();
        _app.Ctx.Services.AddSingleton<ISaveFile>(_save);
        _state = await _app.Start();
    }

    [TearDown]
    public void TearDown() => _app.Dispose();

    private Task SeedExisting() => _state.AddUserData(
    [
        new CategoryModel
        {
            Title = "Личное",
            Tasks = [new() { Title = "Сохранённая задача", PlannedAt = Planned }],
            Notes = [new() { Title = "Сохранённая заметка", Content = "Старый текст" }],
            Habits = [new() { Title = "Сохранённая привычка" }]
        }
    ]);

    private static string BackupWithNewRecords() => JsonSerializer.Serialize(new UserImportExportData
    {
        Settings = new() { StartPage = "/notes", Culture = "en", IsDarkMode = false },
        Categories =
        [
            new CategoryModel
            {
                Title = "Личное",
                Tasks =
                [
                    new() { Title = "Сохранённая задача", PlannedAt = Planned, CompletedAt = Planned.AddHours(1) },
                    new() { Title = "Восстановленная задача", PlannedAt = Planned.AddDays(1) }
                ],
                Notes =
                [
                    new() { Title = "Сохранённая заметка", Content = "Старый текст" },
                    new() { Title = "Восстановленная заметка", Content = "Текст из копии" },
                    new() { Title = "Тренировка из копии", Content = new Workout { Date = Planned.Date, Kind = "Бокс", Minutes = 45, Completed = true }.ToContent() }
                ],
                Habits = [new() { Title = "Сохранённая привычка" }, new() { Title = "Восстановленная привычка" }]
            }
        ]
    });

    private static void Upload(IRenderedComponent<SimpleSettings> cut, string content, string filename = "backup.json") =>
        cut.FindComponent<InputFile>().UploadFiles(InputFileContent.CreateFromText(content, filename, contentType: "application/json"));

    [Test]
    public async Task JsonExport_UsesSaveFileAndRetainsAllRecordsIncludingHiddenNotesAndHabits()
    {
        Workout workout = new() { Date = Planned.Date, Kind = "Силовая", Minutes = 50, Notes = "Сохранить вместе с копией" };
        await _state.AddUserData(
        [
            new CategoryModel
            {
                Title = "Скрытый раздел",
                Notes =
                [
                    new() { Title = "Скрытая заметка", Content = "Важный текст" },
                    new() { Title = "Тренировка", Content = workout.ToContent() }
                ],
                Tasks = [new() { Title = "Задача", PlannedAt = Planned, Items = [new() { Title = "Пункт задачи" }] }],
                Habits = [new() { Title = "Скрытая привычка", TimesDone = [new() { StartedAt = Planned, CompletedAt = Planned.AddMinutes(5) }] }]
            }
        ]);
        long categoryId = (await _app.Store.GetCategories()).Single().Id;
        _state.Settings.HiddenCategoryIds.Add(categoryId);
        await _state.UpdateSettings();
        var cut = _app.Ctx.Render<SimpleSettings>();

        cut.FindAll("button").Single(b => b.TextContent == "Скачать резервную копию").Click();
        cut.WaitForAssertion(() => Assert.That(_save.Files, Has.Count.EqualTo(1)));
        var file = _save.Files.Single();
        UserImportExportData exported = JsonSerializer.Deserialize<UserImportExportData>(file.Content)!;
        CategoryModel category = exported.Categories.Single(c => c.Title == "Скрытый раздел");

        Assert.Multiple(() =>
        {
            Assert.That(file.Filename, Does.StartWith("Planner-").And.EndWith(".json"));
            Assert.That(category.Notes.Single(n => n.Title == "Скрытая заметка").Content, Is.EqualTo("Важный текст"));
            Assert.That(Workout.FromNote(category.Notes.Single(n => n.Title == "Тренировка"))!.Notes, Is.EqualTo(workout.Notes));
            Assert.That(category.Tasks.Single().Items!.Single().Title, Is.EqualTo("Пункт задачи"));
            Assert.That(category.Habits.Single().Title, Is.EqualTo("Скрытая привычка"));
            Assert.That(category.Habits.Single().TimesDone!.Single().CompletedAt, Is.EqualTo(Planned.AddMinutes(5)));
            Assert.That(exported.Settings.HiddenCategoryIds, Does.Contain(categoryId));
        });
    }

    [TestCase("broken.json", "{")]
    [TestCase("wrong-shape.json", "{\"Categories\":\"not a list\"}")]
    [TestCase("wrong-format.json", "Categories: []")]
    public async Task InvalidJsonBackup_ShowsFriendlyErrorAndDoesNotImport(string filename, string content)
    {
        await SeedExisting();
        long existingId = (await _app.Store.GetTasks()).Single().Id;
        var cut = _app.Ctx.Render<SimpleSettings>();

        Upload(cut, content, filename);
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("[role='alert']"), Has.Count.EqualTo(1)));

        Assert.Multiple(() =>
        {
            Assert.That(cut.Find("[role='alert']").TextContent, Does.Contain("копию"));
            Assert.That(cut.FindAll(".simple-backup-preview"), Is.Empty);
        });
        Assert.That((await _app.Store.GetTasks()).Single().Id, Is.EqualTo(existingId));
        Assert.That((await _app.Store.GetNotes()).Single().Content, Is.EqualTo("Старый текст"));
        Assert.That((await _app.Store.GetHabits()).Single().Title, Is.EqualTo("Сохранённая привычка"));
    }

    [Test]
    public async Task BackupPreview_CancelLeavesExistingDataAndSettingsUnchanged()
    {
        await SeedExisting();
        string originalStartPage = _state.Settings.StartPage;
        long existingId = (await _app.Store.GetTasks()).Single().Id;
        var cut = _app.Ctx.Render<SimpleSettings>();

        Upload(cut, BackupWithNewRecords());
        cut.WaitForAssertion(() => Assert.That(cut.FindAll(".simple-backup-preview"), Has.Count.EqualTo(1)));
        Assert.That((await _app.Store.GetTasks()).Single().Id, Is.EqualTo(existingId), "Reading the preview must not write data.");
        cut.FindAll("button").Single(b => b.TextContent == "Отмена").Click();

        Assert.Multiple(() =>
        {
            Assert.That(cut.FindAll(".simple-backup-preview"), Is.Empty);
            Assert.That(_state.Settings.StartPage, Is.EqualTo(originalStartPage));
        });
        Assert.That((await _app.Store.GetTasks()).Single().Id, Is.EqualTo(existingId));
        Assert.That((await _app.Store.GetNotes()).Select(n => n.Title), Is.EqualTo(new[] { "Сохранённая заметка" }));
        Assert.That((await _app.Store.GetHabits()).Select(h => h.Title), Is.EqualTo(new[] { "Сохранённая привычка" }));
    }

    [Test]
    public async Task Restore_MergesRecordsWithoutDeletingOrChangingExistingTaskOrLaunchSettings()
    {
        await SeedExisting();
        _state.Settings.StartPage = "/today";
        _state.Settings.Culture = "ru";
        _state.Settings.IsDarkMode = true;
        await _state.UpdateSettings();
        long existingTaskId = (await _app.Store.GetTasks()).Single().Id;
        long existingNoteId = (await _app.Store.GetNotes()).Single().Id;
        long existingHabitId = (await _app.Store.GetHabits()).Single().Id;
        var cut = _app.Ctx.Render<SimpleSettings>();

        Upload(cut, BackupWithNewRecords());
        cut.WaitForAssertion(() => Assert.That(cut.FindAll(".simple-backup-preview"), Has.Count.EqualTo(1)));
        cut.FindAll("button").Single(b => b.TextContent == "Восстановить записи").Click();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll(".simple-backup-preview"), Is.Empty));

        var tasks = await _app.Store.GetTasks();
        var notes = await _app.Store.GetNotes();
        var habits = await _app.Store.GetHabits();
        var settings = (await _app.Store.GetSettings()).Single();
        Assert.Multiple(() =>
        {
            Assert.That(tasks.Select(t => t.Title), Is.EquivalentTo(new[] { "Сохранённая задача", "Восстановленная задача" }));
            Assert.That(tasks.Single(t => t.Id == existingTaskId).CompletedAt, Is.Null, "An existing task is not overwritten by a backup match.");
            Assert.That(notes.Single(n => n.Id == existingNoteId).Content, Is.EqualTo("Старый текст"));
            Assert.That(notes.Single(n => n.Title == "Восстановленная заметка").Content, Is.EqualTo("Текст из копии"));
            Assert.That(Workout.FromNote(new NoteModel { Content = notes.Single(n => n.Title == "Тренировка из копии").Content })!.Minutes, Is.EqualTo(45));
            Assert.That(habits.Single(h => h.Id == existingHabitId).Title, Is.EqualTo("Сохранённая привычка"));
            Assert.That(habits.Select(h => h.Title), Is.EquivalentTo(new[] { "Сохранённая привычка", "Восстановленная привычка" }));
            Assert.That((settings.StartPage, settings.Culture, settings.IsDarkMode), Is.EqualTo(("/today", "ru", true)));
        });

        Upload(cut, BackupWithNewRecords());
        cut.WaitForAssertion(() => Assert.That(cut.Find(".simple-backup-preview").TextContent, Does.Contain("уже есть")));
        Assert.That((await _app.Store.GetTasks()).Count, Is.EqualTo(2), "Repeated reading of the same backup must not duplicate records.");
    }
}
