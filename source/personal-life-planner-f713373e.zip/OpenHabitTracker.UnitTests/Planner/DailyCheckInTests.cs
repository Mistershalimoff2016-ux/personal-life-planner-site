using System.Text;
using OpenHabitTracker.Backup.File;
using OpenHabitTracker.Data;
using OpenHabitTracker.Data.Models;
using OpenHabitTracker.Planner;
using OpenHabitTracker.UnitTests.Components;

namespace OpenHabitTracker.UnitTests.Planner;

[TestFixture]
public class DailyCheckInTests
{
    [TestCase(1, "Непросто")]
    [TestCase(5, "Отлично")]
    public void NoteEnvelope_RoundTripPreservesDateEnergyAndMood(int energy, string mood)
    {
        DailyCheckIn value = new() { Date = new(2026, 11, 17), Energy = energy, Mood = mood };
        DailyCheckIn result = DailyCheckIn.FromNote(new NoteModel { Content = value.ToContent() })!;
        Assert.Multiple(() =>
        {
            Assert.That(result.Date, Is.EqualTo(value.Date));
            Assert.That(result.Energy, Is.EqualTo(energy));
            Assert.That(result.Mood, Is.EqualTo(mood));
        });
    }

    [TestCase("Обычная заметка")]
    [TestCase("<!-- personal-life-planner:checkin:v2 -->\n```json\n{}\n```")]
    [TestCase("<!-- personal-life-planner:checkin:v1 -->\n```json\n{broken}\n```")]
    [TestCase("<!-- personal-life-planner:checkin:v1 -->\n```json\n{\"Energy\":0}\n```")]
    [TestCase("<!-- personal-life-planner:checkin:v1 -->\n```json\n{\"Energy\":6}\n```")]
    [TestCase("<!-- personal-life-planner:checkin:v1 -->\n```json\n{\"Mood\":\"unknown\"}\n```")]
    [TestCase("<!-- personal-life-planner:checkin:v1 -->\n```json\n{\"Mood\":null}\n```")]
    [TestCase("<!-- personal-life-planner:checkin:v1 -->\n```json\n{\"Date\":\"invalid-date\"}\n```")]
    public void UnsupportedOrDamagedNote_IsNotRecognizedAsCheckIn(string content) =>
        Assert.That(DailyCheckIn.FromNote(new NoteModel { Content = content }), Is.Null);

    [Test]
    public void DeletedNote_IsNotShownAsDailyState() =>
        Assert.That(DailyCheckIn.FromNote(new NoteModel { IsDeleted = true, Content = new DailyCheckIn().ToContent() }), Is.Null);

    [TestCase("json")]
    [TestCase("yaml")]
    public async Task ExistingBackup_RestoresCheckInAlongsideWorkoutNoteTaskAndHabit(string format)
    {
        using AppTestContext source = new();
        await source.Start();
        DailyCheckIn checkIn = new() { Date = new(2026, 11, 17), Energy = 4, Mood = "Хорошо" };
        Workout workout = new() { Date = new(2026, 11, 16), Kind = "Силовая", Completed = true, Minutes = 45, Exercises = [new() { Name = "Присед", Weight = 62.5m, Sets = 3, Reps = 8 }] };
        await source.ClientState.AddUserData([
            new CategoryModel
            {
                Title = "Личное",
                Notes = [new() { Title = "Состояние", Content = checkIn.ToContent() }, new() { Title = "Тренировка", Content = workout.ToContent() }, new() { Title = "Обычная заметка", Content = "Мои планы\nВторая строка" }],
                Tasks = [new() { Title = "Выполненное дело", CompletedAt = new(2026, 11, 17, 11, 30, 0) }],
                Habits = [new() { Title = "Читать", RepeatCount = 1, RepeatInterval = 1, RepeatPeriod = Period.Day }]
            }
        ]);
        string backup = format == "json" ? await new JsonImportExport(source.ClientState).GetDataExportFileString() : await new YamlImportExport(source.ClientState).GetDataExportFileString();
        using MemoryStream stream = new(Encoding.UTF8.GetBytes(backup));
        UserImportExportData data = format == "json" ? await new JsonImportExport(source.ClientState).ReadDataFile(stream) : await new YamlImportExport(source.ClientState).ReadDataFile(stream);
        using AppTestContext destination = new();
        await destination.Start();
        await destination.ClientState.SetUserData(data);
        var storedNotes = await destination.Store.GetNotes();
        var state = storedNotes.Select(n => DailyCheckIn.FromNote(new NoteModel { Content = n.Content })).OfType<DailyCheckIn>().Single();
        var training = storedNotes.Select(n => Workout.FromNote(new NoteModel { Content = n.Content })).OfType<Workout>().Single();
        var task = (await destination.Store.GetTasks()).Single();
        var habit = (await destination.Store.GetHabits()).Single();
        Assert.Multiple(() =>
        {
            Assert.That(storedNotes, Has.Count.EqualTo(3));
            Assert.That((state.Date, state.Energy, state.Mood), Is.EqualTo((checkIn.Date, 4, "Хорошо")));
            Assert.That(training.ToContent(), Is.EqualTo(workout.ToContent()));
            Assert.That(storedNotes.Single(n => n.Title == "Обычная заметка").Content, Is.EqualTo("Мои планы\nВторая строка"));
            Assert.That(task.Title, Is.EqualTo("Выполненное дело"));
            Assert.That(task.CompletedAt, Is.EqualTo(new DateTime(2026, 11, 17, 11, 30, 0)));
            Assert.That((habit.Title, habit.RepeatCount, habit.RepeatInterval, habit.RepeatPeriod), Is.EqualTo(("Читать", 1, 1, Period.Day)));
        });
    }
}
