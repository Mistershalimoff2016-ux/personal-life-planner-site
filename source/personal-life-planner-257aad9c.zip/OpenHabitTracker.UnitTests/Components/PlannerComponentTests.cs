using AngleSharp.Dom;
using Bunit;
using OpenHabitTracker.Blazor.Pages;
using OpenHabitTracker.Data.Models;
using OpenHabitTracker.Planner;
using OpenHabitTracker.Services;

namespace OpenHabitTracker.UnitTests.Components;

[TestFixture]
public class PlannerComponentTests
{
    private static IElement Button(IRenderedComponent<Workouts> cut, string name) =>
        cut.FindAll("button").Single(b => b.TextContent.Trim() == name);

    [Test]
    public async Task QuickAdd_InputEnablesSaveAndCompletionPersists()
    {
        using AppTestContext app = new();
        await app.Start();
        var cut = app.Ctx.Render<Today>();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("input[maxlength]").Count, Is.EqualTo(1)));
        cut.Find("input[maxlength]").Input("Купить продукты");
        var save = cut.Find("button[aria-label='Добавить задачу']");
        Assert.That(save.HasAttribute("disabled"), Is.False);
        save.Click();
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Купить продукты")));
        Assert.That((await app.Store.GetTasks()).Single().Title, Is.EqualTo("Купить продукты"));
        cut.Find("button[aria-label='Выполнить']").Click();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("button[aria-label='Выполнено — отменить']"), Has.Count.EqualTo(1)));
        Assert.That((await app.Store.GetTasks()).Single().CompletedAt, Is.Not.Null);
    }

    [Test]
    public async Task CheckIn_SavedStateIsLoadedFromStoreAndUpdatingDoesNotDuplicateTheDay()
    {
        using AppTestContext app = new();
        await app.Start();
        var first = app.Ctx.Render<Today>();
        first.WaitForAssertion(() => Assert.That(first.FindAll("button.kos-vital"), Has.Count.EqualTo(2)));
        first.Find("button.kos-vital").Click();
        first.FindAll(".kos-checkin select")[0].Change("5");
        first.FindAll(".kos-checkin select")[1].Change("Усталость");
        first.Find(".kos-checkin").Submit();
        first.WaitForAssertion(() => Assert.That(first.Markup, Does.Contain("Состояние сохранено.")));
        var stored = (await app.Store.GetNotes()).Single();
        var checkIn = DailyCheckIn.FromNote(new NoteModel { Content = stored.Content })!;
        Assert.Multiple(() =>
        {
            Assert.That(checkIn.Energy, Is.EqualTo(5));
            Assert.That(checkIn.Mood, Is.EqualTo("Усталость"));
            Assert.That(checkIn.Date.Date, Is.EqualTo(DateTime.Today));
        });

        first.Dispose();
        app.ClientState.Notes = null; // the fresh page must load the saved entity from SQLite
        var reopened = app.Ctx.Render<Today>();
        reopened.WaitForAssertion(() => Assert.That(reopened.FindAll("button.kos-vital"), Has.Count.EqualTo(2)));
        Assert.That(reopened.FindAll("button.kos-vital")[1].TextContent, Does.Contain("Усталость"));
        reopened.Find("button.kos-vital").Click();
        Assert.That(reopened.FindAll(".kos-checkin select")[0].GetAttribute("value"), Is.EqualTo("5"));
        Assert.That(reopened.FindAll(".kos-checkin select")[1].GetAttribute("value"), Is.EqualTo("Усталость"));
        reopened.FindAll(".kos-checkin select")[0].Change("2");
        reopened.FindAll(".kos-checkin select")[1].Change("Хорошо");
        reopened.Find(".kos-checkin").Submit();
        reopened.WaitForAssertion(() => Assert.That(reopened.FindAll(".kos-checkin"), Is.Empty));
        var updated = (await app.Store.GetNotes()).Single();
        Assert.That(updated.Id, Is.EqualTo(stored.Id));
        var value = DailyCheckIn.FromNote(new NoteModel { Content = updated.Content })!;
        Assert.That((value.Energy, value.Mood), Is.EqualTo((2, "Хорошо")));
    }

    [Test]
    public async Task WorkoutDraftCanBeSavedAndEditedThroughForm()
    {
        using AppTestContext app = new();
        await app.Start();
        var cut = app.Ctx.Render<Workouts>();
        Button(cut, "Новая тренировка").Click();
        cut.Find("form").Submit();
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Запись сохранена.")));
        Assert.That(Workout.FromNote(new() { Content = (await app.Store.GetNotes()).Single().Content })!.Completed, Is.False);
        Button(cut, "Редактировать").Click();
        cut.Find("input[type=number]").Change("45");
        cut.Find("input[type=checkbox]").Change(true);
        cut.Find("form").Submit();
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Завершено за неделю: 1")));
        var stored = Workout.FromNote(new() { Content = (await app.Store.GetNotes()).Single().Content })!;
        Assert.That(stored.Minutes, Is.EqualTo(45));
        Assert.That(stored.Completed, Is.True);
    }

    [Test]
    public async Task WorkoutDetailRoute_ShowsFullRecordAndEditsTheSameStoredNote()
    {
        using AppTestContext app = new();
        await app.Start();
        INoteService notes = app.Get<INoteService>();
        await notes.Initialize();
        DateTime pastDate = DateTime.Today.AddDays(-4);
        Workout workout = new() { Date = pastDate, Kind = "Силовая", Notes = "Подробная запись", Feeling = "Бодро", Exercises = [new() { Name = "Жим", Sets = 3, Reps = 8, Weight = 62.5m }] };
        var original = new NoteModel { Title = "Прошлая тренировка", Content = workout.ToContent() };
        notes.NewNote = original;
        await notes.AddNote();
        var cut = app.Ctx.Render<Workouts>(parameters => parameters.Add(p => p.Id, original.Id));
        cut.WaitForAssertion(() => Assert.That(cut.FindAll(".kos-workout-detail"), Has.Count.EqualTo(1)));
        Assert.That(cut.Find(".kos-workout-detail").TextContent, Does.Contain("Подробная запись").And.Contain("Бодро").And.Contain("Жим"));
        Assert.That(cut.FindAll(".kos-workout-card"), Is.Empty); // detail is a separate card, not the history list
        Button(cut, "Редактировать").Click();
        Assert.That(cut.Find("details").HasAttribute("open"), Is.True);
        cut.Find("form input[type=number]").Change("55");
        cut.Find("fieldset input").Input("Жим лёжа");
        cut.FindAll("fieldset input[type=number]").Last().Change("72.5");
        cut.Find("input[type=checkbox]").Change(true);
        cut.Find("form").Submit();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("form"), Is.Empty));
        var stored = (await app.Store.GetNotes()).Single();
        var edited = Workout.FromNote(new NoteModel { Content = stored.Content })!;
        Assert.Multiple(() =>
        {
            Assert.That(stored.Id, Is.EqualTo(original.Id));
            Assert.That(edited.Date, Is.EqualTo(pastDate));
            Assert.That(edited.Completed, Is.True);
            Assert.That(edited.Minutes, Is.EqualTo(55));
            Assert.That(edited.Exercises.Single().Name, Is.EqualTo("Жим лёжа"));
            Assert.That(edited.Exercises.Single().Weight, Is.EqualTo(72.5m));
        });
        cut.Render(parameters => parameters.Add(p => p.Id, (long?)null));
        Assert.That(cut.FindAll(".kos-workout-detail"), Is.Empty);
        Assert.That(cut.FindAll(".kos-workout-card"), Has.Count.EqualTo(1));
        Assert.That(cut.Find("a[href='workouts/" + original.Id + "']").TextContent, Is.Not.Empty);
    }

    [Test]
    public async Task WorkoutDetailRoute_MissingRecordLeavesOtherNotesUntouched()
    {
        using AppTestContext app = new();
        await app.Start();
        var cut = app.Ctx.Render<Workouts>(parameters => parameters.Add(p => p.Id, 99999));
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Запись не найдена")));
        Assert.That(cut.FindAll(".kos-workout-detail"), Is.Empty);
        Assert.That(await app.Store.GetNotes(), Is.Empty);
    }
}
