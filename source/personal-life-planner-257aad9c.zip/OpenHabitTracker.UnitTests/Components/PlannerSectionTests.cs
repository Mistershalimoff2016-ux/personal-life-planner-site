using Bunit;
using OpenHabitTracker.Blazor.Pages;
using OpenHabitTracker.Data;
using OpenHabitTracker.Data.Models;
using OpenHabitTracker.Planner;
using System.Globalization;

namespace OpenHabitTracker.UnitTests.Components;

[TestFixture]
public class PlannerSectionTests
{
    private static readonly CultureInfo Russian = CultureInfo.GetCultureInfo("ru-RU");

    [Test]
    public async Task Calendar_ShowsSelectedDayTaskAndWorkoutLinks_ExcludesDeletedAndOtherDates()
    {
        using AppTestContext app = new();
        var state = await app.Start();
        DateTime today = DateTime.Today;
        await state.AddUserData(
        [
            new CategoryModel
            {
                Title = "Планы",
                Tasks =
                [
                    new() { Title = "Встреча сегодня", PlannedAt = today.AddHours(10), Priority = Priority.High },
                    new() { Title = "Удалённая задача", PlannedAt = today.AddHours(11), IsDeleted = true },
                    new() { Title = "Завтрашняя задача", PlannedAt = today.AddDays(1) }
                ],
                Notes =
                [
                    new() { Title = "Сегодня бокс", Content = new Workout { Date = today, Kind = "Бокс", Minutes = 60 }.ToContent() },
                    new() { Title = "Удалённая тренировка", Content = new Workout { Date = today, Kind = "Кардио" }.ToContent(), IsDeleted = true },
                    new() { Title = "Завтра силовая", Content = new Workout { Date = today.AddDays(1), Kind = "Силовая" }.ToContent() }
                ]
            }
        ]);
        var cut = app.Ctx.Render<PlannerCalendar>();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("a.kos-event-card").Count, Is.EqualTo(2)));
        long taskId = (await app.Store.GetTasks()).Single(t => t.Title == "Встреча сегодня").Id;
        long workoutId = (await app.Store.GetNotes()).Single(n => n.Title == "Сегодня бокс").Id;

        Assert.Multiple(() =>
        {
            Assert.That(cut.Find($"a[href='tasks/{taskId}']").TextContent, Does.Contain("Встреча сегодня").And.Contain("10:00").And.Contain("High priority"));
            Assert.That(cut.Find($"a[href='workouts/{workoutId}']").TextContent, Does.Contain("Бокс").And.Contain("60 мин"));
            Assert.That(cut.FindAll("button.kos-calendar-day").Count, Is.EqualTo(42));
            Assert.That(cut.FindAll("button.kos-calendar-day[aria-pressed='true']").Count, Is.EqualTo(1));
            Assert.That(cut.Find(".kos-stack").TextContent, Does.Not.Contain("Удалённая").And.Not.Contain("Завтрашняя").And.Not.Contain("Силовая"));
        });

        DateTime emptyDay = today.Day == 1 ? today.AddDays(2) : new(today.Year, today.Month, 1);
        string dayPrefix = emptyDay.ToString("d MMMM yyyy", Russian) + ",";
        cut.FindAll("button.kos-calendar-day").Single(b => b.GetAttribute("aria-label")!.StartsWith(dayPrefix, StringComparison.Ordinal)).Click();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("a.kos-event-card"), Is.Empty));
        Assert.That(cut.Find(".kos-empty").TextContent, Does.Contain("День без планов"));
    }

    [Test]
    public async Task Calendar_MonthNavigationSelectsTheNewMonth_AndTodayReturnsToCurrentDay()
    {
        using AppTestContext app = new();
        var state = await app.Start();
        DateTime today = DateTime.Today;
        DateTime nextMonth = new DateTime(today.Year, today.Month, 1).AddMonths(1);
        await state.AddUserData(
        [
            new CategoryModel
            {
                Tasks =
                [
                    new() { Title = "План следующего месяца", PlannedAt = nextMonth.AddHours(9) },
                    new() { Title = "План текущего дня", PlannedAt = today.AddHours(10) }
                ]
            }
        ]);
        var cut = app.Ctx.Render<PlannerCalendar>();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("a.kos-event-card").Count, Is.EqualTo(1)));
        cut.Find("button[aria-label='Следующий месяц']").Click();
        Assert.Multiple(() =>
        {
            Assert.That(cut.Find(".kos-calendar-toolbar h2").TextContent, Is.EqualTo(Russian.TextInfo.ToTitleCase(nextMonth.ToString("MMMM yyyy", Russian))));
            Assert.That(cut.Find("a.kos-event-card").TextContent, Does.Contain("План следующего месяца"));
            Assert.That(cut.Find("button.kos-calendar-day[aria-pressed='true']").TextContent.Trim(), Is.EqualTo("1"));
        });
        cut.Find(".kos-calendar-footer button").Click();
        Assert.That(cut.Find("a.kos-event-card").TextContent, Does.Contain("План текущего дня"));
    }

    [Test]
    public async Task Progress_UsesStoredWeekActivity_ExcludesDeletedDraftAndOtherWeeks()
    {
        using AppTestContext app = new();
        var state = await app.Start();
        DateTime monday = DateTime.Today.AddDays(-(((int)DateTime.Today.DayOfWeek + 6) % 7));
        await state.AddUserData(
        [
            new CategoryModel
            {
                Title = "Активность",
                Tasks =
                [
                    new() { Title = "Выполнено по плану", PlannedAt = monday, CompletedAt = monday.AddHours(12) },
                    new() { Title = "Осталось по плану", PlannedAt = monday.AddDays(1) },
                    new() { Title = "Удалённое выполнение", PlannedAt = monday, CompletedAt = monday.AddHours(13), IsDeleted = true },
                    new() { Title = "Прошлая неделя", PlannedAt = monday.AddDays(-1), CompletedAt = monday.AddDays(-1).AddHours(12) },
                    new() { Title = "Без плана, сделано сейчас", CompletedAt = monday.AddDays(2).AddHours(12) }
                ],
                Notes =
                [
                    new() { Title = "Завершена", Content = new Workout { Date = monday, Kind = "Бокс", Minutes = 45, Completed = true }.ToContent() },
                    new() { Title = "Черновик", Content = new Workout { Date = monday, Kind = "Силовая", Minutes = 70 }.ToContent() },
                    new() { Title = "Удалена", IsDeleted = true, Content = new Workout { Date = monday, Minutes = 100, Completed = true }.ToContent() },
                    new() { Title = "Прошлая", Content = new Workout { Date = monday.AddDays(-1), Minutes = 90, Completed = true }.ToContent() }
                ],
                Habits =
                [
                    new()
                    {
                        Title = "Растяжка",
                        TimesDone =
                        [
                            new() { StartedAt = monday.AddDays(1), CompletedAt = monday.AddDays(1).AddMinutes(5) },
                            new() { StartedAt = monday.AddDays(-1), CompletedAt = monday.AddDays(-1).AddMinutes(5) },
                            new() { StartedAt = monday.AddDays(3) }
                        ]
                    },
                    new()
                    {
                        Title = "Удалённая привычка", IsDeleted = true,
                        TimesDone = [new() { StartedAt = monday, CompletedAt = monday.AddMinutes(5) }]
                    }
                ]
            }
        ]);
        var cut = app.Ctx.Render<PlannerProgress>();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll(".kos-metric-card").Count, Is.EqualTo(4)));
        var metrics = cut.FindAll(".kos-metric-card");
        Assert.Multiple(() =>
        {
            Assert.That(cut.Find("progress").GetAttribute("value"), Is.EqualTo("1"));
            Assert.That(cut.Find("progress").GetAttribute("max"), Is.EqualTo("2"));
            Assert.That(metrics[0].QuerySelector(".kos-metric-value")!.TextContent, Is.EqualTo("2"));
            Assert.That(metrics[1].QuerySelector(".kos-metric-value")!.TextContent, Is.EqualTo("1"));
            Assert.That(metrics[1].TextContent, Does.Contain("45 мин"));
            Assert.That(metrics[2].QuerySelector(".kos-metric-value")!.TextContent, Is.EqualTo("1"));
            Assert.That(metrics[3].QuerySelector(".kos-metric-value")!.TextContent, Is.EqualTo("3"));
            Assert.That(cut.Find(".kos-week-chart").ParentElement!.TextContent, Does.Contain("4 отметок"));
            Assert.That(cut.FindAll(".kos-week-count").Select(e => e.TextContent), Is.EqualTo(new[] { "2", "1", "1", "0", "0", "0", "0" }));
        });
        cut.Find("button[aria-label='Предыдущая неделя']").Click();
        Assert.Multiple(() =>
        {
            Assert.That(cut.FindAll(".kos-metric-value").Select(e => e.TextContent), Is.EqualTo(new[] { "1", "1", "1", "1" }));
            Assert.That(cut.FindAll(".kos-week-count").Select(e => e.TextContent), Is.EqualTo(new[] { "0", "0", "0", "0", "0", "0", "3" }));
        });
    }
}
