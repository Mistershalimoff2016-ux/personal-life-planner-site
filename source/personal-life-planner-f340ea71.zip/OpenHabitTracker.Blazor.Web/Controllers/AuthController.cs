using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using OpenHabitTracker.Blazor.Web.Data;
using OpenHabitTracker.Data.Entities;
using OpenHabitTracker.Dto;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace OpenHabitTracker.Blazor.Web.Controllers;

[ApiController]
[IgnoreAntiforgeryToken]
[Route("api/[controller]")]
public class AuthController(SignInManager<ApplicationUser> signInManager, UserManager<ApplicationUser> userManager, IOptions<AppSettings> options, ApplicationDbContext dbContext) : ControllerBase
{
    private readonly SignInManager<ApplicationUser> _signInManager = signInManager;
    private readonly UserManager<ApplicationUser> _userManager = userManager;
    private readonly AppSettings _appSettings = options.Value;
    private readonly ApplicationDbContext _dbContext = dbContext;

    // Rotated on every launch, so this is how long an unused device stays signed in.
    private const int RefreshTokenLifetimeDays = 90;

    // How long the rotated-away value keeps working, to cover a lost response or two calls
    // refreshing at once. Rotation without this is what makes those look like an attack.
    private const int PreviousTokenGraceSeconds = 60;

    [AllowAnonymous]
    [HttpPost("jwt-token")]
    [EndpointName("GetJwtToken")]
    public async Task<ActionResult<TokenResponse>> GetJwtToken([FromBody] LoginCredentials loginCredentials)
    {
        Microsoft.AspNetCore.Identity.SignInResult result = await _signInManager.PasswordSignInAsync(loginCredentials.Username, loginCredentials.Password, isPersistent: false, lockoutOnFailure: true);

        if (!result.Succeeded)
        {
            return Unauthorized("Invalid credentials");
        }

        ApplicationUser? user = await _userManager.FindByNameAsync(loginCredentials.Username);

        if (user is null || user.UserName is null)
        {
            return Unauthorized();
        }

        TokenResponse tokenResponse = await GetTokenResponse(user);

        // a row per login, rotated in place and never removed otherwise
        await _dbContext.RefreshTokens
            .Where(rt => rt.Username == user.UserName && rt.ExpiryDate < DateTime.UtcNow)
            .ExecuteDeleteAsync();

        RefreshToken refreshToken = new()
        {
            Username = user.UserName,
            Token = tokenResponse.RefreshToken,
            ExpiryDate = DateTime.UtcNow.AddDays(RefreshTokenLifetimeDays)
        };

        _dbContext.RefreshTokens.Add(refreshToken);

        await _dbContext.SaveChangesAsync();

        return Ok(tokenResponse);
    }

    private async Task<TokenResponse> GetTokenResponse(ApplicationUser user)
    {
        string issuer = "https://app.openhabittracker.net";
        string audience = "OpenHabitTracker";
        string secret = _appSettings.JwtSecret;

        List<Claim> claims =
        [
            // The id rather than the username, because data access resolves the caller from it and a
            // username can change.
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString(CultureInfo.InvariantCulture)),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        ];

        // Roles are read from the token, so a changed role reaches a device with its next renewal.
        foreach (string role in await _userManager.GetRolesAsync(user))
        {
            claims.Add(new Claim(ClaimTypes.Role, role));
        }

        SymmetricSecurityKey key = new(Encoding.UTF8.GetBytes(secret));
        SigningCredentials creds = new(key, SecurityAlgorithms.HmacSha256);

        DateTime expires = DateTime.UtcNow.AddDays(1);

        JwtSecurityToken token = new(
            issuer: issuer,
            audience: audience,
            claims: claims,
            expires: expires,
            signingCredentials: creds);

        TokenResponse tokenResponse = new()
        {
            JwtToken = new JwtSecurityTokenHandler().WriteToken(token),
            RefreshToken = Convert.ToBase64String(RandomNumberGenerator.GetBytes(64)),
            JwtTokenExpiresAt = expires,
            Email = user.Email ?? string.Empty
        };

        return tokenResponse;
    }

    [AllowAnonymous]
    [HttpPost("refresh-token")]
    [EndpointName("GetRefreshToken")]
    public async Task<ActionResult<TokenResponse>> GetRefreshToken([FromBody] RefreshTokenRequest request)
    {
        RefreshToken? storedToken = await _dbContext.RefreshTokens.FirstOrDefaultAsync(rt => rt.Token == request.RefreshToken);

        bool withinGracePeriod = false;

        if (storedToken is null)
        {
            storedToken = await _dbContext.RefreshTokens.FirstOrDefaultAsync(rt => rt.PreviousToken == request.RefreshToken);

            if (storedToken is null)
            {
                return Unauthorized("Invalid or expired refresh token");
            }

            withinGracePeriod = storedToken.PreviousTokenValidUntil > DateTime.UtcNow;

            if (!withinGracePeriod)
            {
                // The value was rotated away and the grace period has passed, so someone is replaying
                // a token this device already exchanged. Drop the row: whoever holds either value
                // has to sign in with a password again.
                _dbContext.RefreshTokens.Remove(storedToken);

                await _dbContext.SaveChangesAsync();

                return Unauthorized("Invalid or expired refresh token");
            }
        }

        if (storedToken.ExpiryDate < DateTime.UtcNow)
        {
            return Unauthorized("Invalid or expired refresh token");
        }

        ApplicationUser? user = await _userManager.FindByNameAsync(storedToken.Username);

        if (user is null || user.UserName is null)
        {
            return Unauthorized();
        }

        TokenResponse tokenResponse = await GetTokenResponse(user);

        if (withinGracePeriod)
        {
            // The caller missed the last response, so give it the value that is current now rather
            // than rotating again and leaving it one step behind for good.
            tokenResponse.RefreshToken = storedToken.Token;
        }
        else
        {
            storedToken.PreviousToken = storedToken.Token;
            storedToken.PreviousTokenValidUntil = DateTime.UtcNow.AddSeconds(PreviousTokenGraceSeconds);

            storedToken.Token = tokenResponse.RefreshToken;
        }

        storedToken.ExpiryDate = DateTime.UtcNow.AddDays(RefreshTokenLifetimeDays);

        await _dbContext.SaveChangesAsync();

        return Ok(tokenResponse);
    }

    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [HttpGet("current-user")]
    [EndpointName("GetCurrentUser")]
    public async Task<ActionResult<UserEntity>> GetCurrentUser()
    {
        ApplicationUser? user = await _userManager.GetUserAsync(User);

        if (user is null)
        {
            return Unauthorized();
        }

        UserEntity userEntity = new()
        {
            UserName = user.UserName ?? string.Empty,
            Email = user.Email ?? string.Empty,
        };

        return Ok(userEntity);
    }
}
