# TODO:

## End-to-End Test Plan (NUnit + Microsoft.Playwright)

### Why e2e tests — what bUnit cannot catch

bUnit tests inject mock services and never execute real JS interop. This means a regression like
calling `JsInterop.SetLang()` inside `OnInitializedAsync()` on a Blazor SSR prerender will:
- **PASS in bUnit** — the mock `IJsInterop` silently succeeds.
- **CRASH in e2e** — the real app throws `InvalidOperationException: JavaScript interop calls cannot
  be issued at this time.`

E2e tests run the full app (Blazor Server, Blazor WebAssembly, or Blazor.Web) in a real browser.
They are the only test layer that can catch SSR lifecycle bugs, JS interop misuse, and broken
navigation routing.

Existing tests (`VideoTests.cs`, `LoadExamplesVideoTests.cs`) record marketing videos, not
assertions. They do not fail on bugs — they just record whatever the app shows. The tests planned
here are assertion-based.

---

### Prerequisites

#### a. App must be running at http://localhost before tests execute

The test project has no way to start the app. The developer must start the target app manually
(e.g. `OpenHabitTracker.Blazor.Web`) and keep it running during the test run.

Document this constraint in a `README.md` or at the top of each test fixture:

    // Prerequisite: start OpenHabitTracker.Blazor.Web at http://localhost before running tests.
    // dotnet run --project OpenHabitTracker.Blazor.Web --configuration Release

Reason: Playwright tests assert against a live app. Tests that run against a stale build will NOT
detect JS fixes or markup changes made since the last server restart.

#### b. Element locator strategy

`data-*` attributes (e.g. `data-main-step-1`) are owned by the GTour guided tour library.
**Do NOT add new `data-*` attributes for tests** — the tour library scans for them and extra
attributes would interfere with tour step discovery.

Tests may reuse existing `data-*` attributes where they already target the right element.
For all other elements, use locators that are already present in the markup, in priority order:

1. `id` — most stable; use when the element is unique on the page (e.g. `#closeSidebar`, `#main-content`)
   - If an element has no `id` but is unique (non-repeating) and suitable for one, **ask the user
     before adding an `id`** — ids are neutral (not owned by any library) and may be added, but
     only with explicit approval.
2. `data-*` tour attribute — stable and language-independent; reuse where it already exists.
   **Never add new `data-*` attributes.**
3. More complex structural locator — when the element repeats and has no id, combine role, CSS
   class, position (`.First`, `.Nth()`), or parent/child relationships to narrow it down
4. `aria-label` — **avoid**: values are localized via `@Loc[...]` and will break if language changes
5. Visible text / `HasText` filter — **avoid for assertions**: also localized and fragile

Dry-run a recording scenario headless before booking a recording session.
Temporarily flip `Headless` to true, add a `[Test]` that runs the scenario at every viewport it
will be recorded at, and time it. Three locator faults and one viewport-only fault were caught
that way in one pass, each of which would have wasted a take.
The mobile viewport is the one that matters: the list is hidden behind the detail there, so any
list-scoped locator that works on desktop can still fail on the phone.

Existing attributes already usable by tests (do not need to be added):
- `data-main-step-1` — menu toggle button
- `data-main-step-2` — Home nav link
- `data-main-step-3` — Notes nav link
- `data-main-step-4` — Tasks nav link
- `data-main-step-5` — Habits nav link
- `data-main-step-6` — Search toggle button
- `data-notes-step-2` — first note title button
- `data-notes-step-7` — Close button in note detail
- `data-tasks-step-2` — first task title button
- `data-tasks-step-10` — Close button in task detail
- `data-habits-step-2` — first habit title button
- `data-habits-step-11` — Close button in habit detail
- `data-data-step-1` — Load examples button in Data sidebar
- `data-search-step-1` — search input field
- `data-search-step-3` — clear search term button
- `id="closeSidebar"` — sidebar close button
- `data-habits-step-5` — checklist inside a habit list row
- `data-habits-step-6` — the habit row's small calendar; its day cells are
  `button[role='gridcell']`, and today carries `.border-primary-subtle`
- `data-habits-step-11` — Close in the habit detail
- `data-tasks-step-4` — Mark as done in a task list row
- `data-tasks-step-14` — the task timer row; its start button is `button:has(i.bi-play)`
- `data-notes-step-3` — the note's rendered markdown in the list
- `data-data-step-2` — Delete all data; the import file input is `input[type='file'].d-none`
- `id="habit-component"`, `id="task-component"`, `id="note-component"` — the open detail of each
  type, useful for scoping away from list rows and as the only reliable scroll target: scrolling
  any looser ancestor moves nothing, because the element that scrolls is the column
- `id="item-{id}"` — a checklist checkbox, and only on the read-only variant in a list row;
  the editable one in a detail uses `aria-label` instead
- `id="Priority.None"` … `id="Priority.VeryHigh"` — priority filter checkboxes
- `id="category-{id}"` — category filter checkboxes, with `label[for="category-{id}"]` beside them.
  Click the LABEL: it carries Bootstrap's `stretched-link`, which covers the input and intercepts
  the click, so clicking the checkbox itself times out.
  Every Settings toggle has the same shape — `label[for="ShowGroupedByCategory"]` and friends —
  so the click-the-label rule is general, not specific to the category filter.
  Scope to the `category-` prefix rather than taking `input[type='checkbox']` `.First`,
  which resolves to the date-range filter rendered above the category section.
- `select[aria-label='Theme']` — the theme picker (aria-label is localized, so English only)

---

---

### Playwright Quirks

#### WaitForLoadStateAsync(NetworkIdle) — FIXED

Does nothing in Blazor WASM — all SPA navigation, IndexedDB reads, and component renders are
client-side with no network traffic. Legitimate use is only after GotoAsync() for the initial
WASM download from IIS. All other occurrences have been replaced with Expect(...).ToBeVisibleAsync()
assertions or removed entirely.

#### WaitForTimeoutAsync — FIXED

Blind sleep with no knowledge of app state — always flaky. Replaced with Expect(...) assertions
that actually wait for observable state changes.

#### Browser errors do not fail tests automatically — FIXED

Playwright tests only fail if an assertion fails or the test code throws. Browser-side crashes —
JS exceptions, Blazor rendering failures, console errors — are completely invisible unless you
explicitly wire them up.

Blazor WASM does NOT throw rendering exceptions to window.onerror (which Playwright captures
as Page.PageError). Blazor catches them internally and writes to console.error, then shows
#blazor-error-ui. All three handlers are wired up in BaseTest.BaseSetUp/BaseTearDown:

    Page.PageError += (_, error) => _browserErrors.Add($"PageError: {error}");
    Page.Console += (_, msg) => { if (msg.Type == "error") _browserErrors.Add($"Console: {msg.Text}"); };
    Page.RequestFailed += (_, request) => _browserErrors.Add($"RequestFailed: {request.Url}");

BaseTearDown asserts #blazor-error-ui is hidden, then fails the test if any browser error occurred.

Why only WASM is affected and not MAUI/WPF/Photino: Blazor Hybrid's WebView JS bridge
serializes an unset ElementReference as null in JS (so guards like `if (element &&` work).
Blazor WASM passes the raw { __internalId: "" } object, which is truthy but not a DOM element,
so the guard passes and any subsequent DOM method call (e.g. element.addEventListener) crashes.

#### CountAsync() is not a wait

`await Page.Locator("...").CountAsync()` returns immediately with whatever count exists at
that millisecond. If the DOM is still updating, the result is wrong and the test is flaky.
Always use `Expect(...).ToHaveCountAsync(n)` instead — it retries until the condition is met
or times out.

#### IsVisibleAsync() is not a wait

`await Page.Locator("...").IsVisibleAsync()` is also a snapshot — it does not retry.
Use `Expect(...).ToBeVisibleAsync()` when you need to wait for an element to appear.
Only use IsVisibleAsync() when you want the current state right now (e.g. an if-branch).

#### Page.RequestFailed — FIXED

If a .wasm or .js resource fails to load, Blazor silently degrades and tests may still pass
because their assertions coincidentally match something in the partially loaded DOM.
Wired up in BaseTest.BaseSetUp alongside PageError/Console to catch broken resource loads.

#### Reload tests race async IndexedDB saves — FIXED

Mutations save to IndexedDB asynchronously; a page reload during the write discards it, so a
mutate-then-reload test races unless something synchronizes with the save. The race is decided by
runtime timing — the whole class passed on net9 and one test failed deterministically on net10.
Two classes of reload test:

- Safe by construction: the last action's UI change renders only AFTER the awaited save completes
  (the add flows hide the form after AddX returns; some settings re-render after saving).
  Their existing Expect calls already synchronize — no extra wait needed.
- Racy: the DOM shows the new value natively, BEFORE Blazor even runs the save handler
  (checkboxes, typed inputs, selects, toggle labels). The post-save re-render changes nothing
  observable, so no UI assertion can synchronize. These call
  BaseTest.WaitForIndexedDbAsync(store, predicate) before ReloadAsync to poll the actual
  persisted data.

To classify a new reload test: does the final pre-reload Expect wait on something that renders
only after the save completes? If not, add a WaitForIndexedDbAsync call with a predicate for the
mutated field.

#### Notifications are always denied headless

Headless Chromium ships no notification presenter, so `Notification.permission` reads `denied` and
`requestPermission()` resolves `denied` however the context grants it - `GrantPermissionsAsync`
with or without an explicit origin makes no difference. Headed, the same grant reads `granted`, and
a cleared context resolves `denied` without hanging on a prompt, so both answers are testable there.
`BaseTest.Headless` is virtual for this: `NotificationSettingsTests` overrides it to false.

#### #blazor-error-ui — FIXED

When Blazor crashes hard (unrecoverable error), it makes #blazor-error-ui visible.
Asserted hidden in BaseTest.BaseTearDown as an additional signal on top of the console.error handler:

    await Expect(Page.Locator("#blazor-error-ui")).ToBeHiddenAsync();

