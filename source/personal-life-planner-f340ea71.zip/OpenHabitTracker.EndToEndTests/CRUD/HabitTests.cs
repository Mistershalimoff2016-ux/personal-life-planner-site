namespace OpenHabitTracker.EndToEndTests.CRUD;

// Prerequisite: start OpenHabitTracker.Blazor.Web at http://localhost before running tests.
// See: OpenHabitTracker.EndToEndTests/TODO.md for Playwright quirks and locator guidelines.

[TestFixture]
public class HabitTests : BaseTest
{
    [SetUp]
    public async Task SetUp()
    {
        await GotoAsync(); // Load app and allow StartPage redirect to complete
        await Page.Locator("[data-main-step-5]").ClickAsync(); // SPA navigate to /habits (avoids StartPage redirect)
        await Expect(Page.Locator("button.btn-plain.input-group")).ToBeVisibleAsync();
    }

    [Test]
    public async Task AddHabit_TypeTitle_HabitAppearsInList()
    {
        await AddItemAsync("Morning Run");

        await Expect(Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Morning Run" })).ToBeVisibleAsync();
    }

    [Test]
    public async Task AddHabit_EmptyTitle_HabitIsNotAdded()
    {
        int initialCount = await Page.Locator("[data-habits-step-2]").CountAsync();

        await Page.Locator("button.btn-plain.input-group").ClickAsync();

        await Expect(Page.Locator("button:has(i.bi-floppy)")).ToBeDisabledAsync();

        await Page.Locator("button:has(i.bi-x-square)").ClickAsync();

        await Expect(Page.Locator("[data-habits-step-2]")).ToHaveCountAsync(initialCount);
    }

    [Test]
    public async Task MarkHabitAsDone_ButtonClick_ElapsedTimeUpdates()
    {
        // Disable ShowSmallCalendar so the Mark as done button (data-habits-step-4) becomes visible in the list
        await OpenSidebarAsync("bi-gear");
        await Page.Locator("label[for='ShowSmallCalendar']").ClickAsync();
        await CloseSidebarAsync();

        await AddItemAsync("Daily Stretch");

        ILocator habitRow = Page.Locator("div.input-group.flex-nowrap").Filter(new LocatorFilterOptions { Has = Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Daily Stretch" }) });

        await habitRow.Locator("[data-habits-step-4]").ClickAsync();

        // After marking done, elapsed time changes from ⊘ (LastTimeDoneAt was null) to "0 m"
        await Expect(habitRow.Locator("[data-habits-step-3]")).ToContainTextAsync("0 m");
    }

    [Test]
    public async Task DeleteHabit_AfterAdd_HabitDisappearsFromList()
    {
        await AddItemAsync("Remove Habit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Remove Habit" }).ClickAsync();

        await Page.Locator("[data-habits-step-10]").ClickAsync();

        await Expect(Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Remove Habit" })).ToHaveCountAsync(0);
    }

    [Test]
    public async Task HabitTimer_StartThenStop_ElapsedTimeUpdates()
    {
        await AddItemAsync("Timed Habit");
        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Timed Habit" }).ClickAsync();
        await Page.Locator("button[aria-label='Start']").ClickAsync();
        await Page.WaitForTimeoutAsync(500);
        await Page.Locator("button[aria-label='Stop']").ClickAsync();

        // After Stop, the Start button should be visible again (timer stopped successfully)
        await Expect(Page.Locator("button[aria-label='Start']")).ToBeVisibleAsync();

        // Close the edit component (navigates to /habits and re-renders the list)
        await Page.Locator("[data-habits-step-11]").ClickAsync();

        await Expect(Page.Locator("[data-habits-step-3]").First).ToContainTextAsync("0 m");
    }

    [Test]
    public async Task Calendar_ClickDay_ElapsedTimeUpdates()
    {
        await AddItemAsync("Calendar Habit");
        await Expect(Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Calendar Habit" })).ToBeVisibleAsync();

        // data-habits-step-6 is the small calendar in the list view
        ILocator calendar = Page.Locator("[data-habits-step-6]");
        await Expect(calendar).ToBeVisibleAsync();

        // In non-month mode, clicking a cell directly calls AddTimeDone (no Increase button needed)
        ILocator gridCells = calendar.Locator("button[role='gridcell']");
        await Expect(gridCells.First).ToBeVisibleAsync();

        // Initial state: no done time yet
        await Expect(Page.Locator("[data-habits-step-3]")).ToContainTextAsync("⊘");

        // Today is always the last cell — calendar shows last N days ending at today.
        // Do NOT use .Filter(HasText = "3") — HasText is a substring match and would match
        // "23", "30", "31" etc. before reaching "3", clicking the wrong day.
        ILocator todayCell = gridCells.Last;
        await Expect(todayCell).ToBeVisibleAsync();
        await Expect(todayCell).ToContainTextAsync($"{DateTime.Today.Day}");

        await todayCell.ClickAsync(new LocatorClickOptions { Force = true });

        // After clicking today's cell, elapsed time changes from ⊘ to "0 m"
        await Expect(Page.Locator("[data-habits-step-3]")).ToContainTextAsync("0 m");
    }

    [Test]
    public async Task DeleteHabit_MovesToTrash()
    {
        await AddItemAsync("Trashed Habit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Trashed Habit" }).ClickAsync();

        await Page.Locator("[data-habits-step-10]").ClickAsync();

        await OpenSidebarAsync("bi-trash");

        await Expect(Page.Locator("span.input-group-text").Filter(new LocatorFilterOptions { HasText = "Trashed Habit" })).ToBeVisibleAsync();
    }

    [Test]
    public async Task EditHabit_ChangesTitle_NewTitleVisible()
    {
        await AddItemAsync("Edit Me");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Edit Me" }).ClickAsync();

        await Page.Locator("input[aria-label='Habit title']").FillAsync("Edited Habit");
        await Page.Locator("input[aria-label='Habit title']").BlurAsync();

        await Page.Locator("[data-habits-step-11]").ClickAsync();

        await Expect(Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Edited Habit" })).ToBeVisibleAsync();
        await Expect(Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Edit Me" })).ToHaveCountAsync(0);
    }

    // The title saves on change, which typing alone does not raise.
    [Test]
    public async Task EditHabit_TypeTitleThenEscape_TitleKept()
    {
        await AddItemAsync("Escape Habit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Escape Habit" }).ClickAsync();

        await Page.Locator("input[aria-label='Habit title']").FillAsync("Typed Habit");
        await Page.Keyboard.PressAsync("Escape");

        await Expect(Page.Locator("#habit-component")).ToHaveCountAsync(0);
        await Expect(Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Typed Habit" })).ToBeVisibleAsync();
    }

    [Test]
    public async Task EditHabit_ChangeAllFields_CloseWorksOnFirstClick()
    {
        await AddItemAsync("Habit To Edit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Habit To Edit" }).ClickAsync();

        // Change title
        await Page.Locator("input[aria-label='Habit title']").FillAsync("Habit Edited Title");
        await Page.Locator("input[aria-label='Habit title']").BlurAsync();

        // Change repeat count (first number input inside data-habits-step-15)
        await Page.Locator("[data-habits-step-15] input[type='number']").First.FillAsync("3");
        await Page.Locator("[data-habits-step-15] input[type='number']").First.BlurAsync();

        // Change repeat interval (second number input inside data-habits-step-15)
        await Page.Locator("[data-habits-step-15] input[type='number']").Last.FillAsync("7");
        await Page.Locator("[data-habits-step-15] input[type='number']").Last.BlurAsync();

        // Change repeat period (default is Day, switch to Week)
        await Page.Locator("select[aria-label='Repeat period']").SelectOptionAsync("Week");

        // Change duration hours
        await Page.Locator("select[aria-label='Duration hours']").SelectOptionAsync("1");

        // Change duration minutes
        await Page.Locator("select[aria-label='Duration minutes']").SelectOptionAsync("30");

        // Click Close once — must close the detail panel immediately (no second click required)
        await Page.Locator("[data-habits-step-11]").ClickAsync();

        await Expect(Page.Locator("[data-habits-step-11]")).ToHaveCountAsync(0);
        await Expect(Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Habit Edited Title" })).ToBeVisibleAsync();
    }

    [Test]
    public async Task AddHabit_PersistedAfterReload()
    {
        await AddItemAsync("Persistent Habit");

        await Page.ReloadAsync();
        await Expect(Page.Locator("nav[aria-label]")).ToBeVisibleAsync();

        await NavigateToAsync("[data-main-step-5]");

        await Expect(Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Persistent Habit" })).ToBeVisibleAsync();
    }

    [Test]
    public async Task EditHabit_ChangeCategory_HabitMovesToNewGroup()
    {
        await CreateCategoryAsync("HabitMoveToCategory");
        await EnableGroupedByCategoryAsync();

        // Add uncategorized habit — SetUp already navigated to habits
        await AddItemAsync("Movable Habit");

        // Habit should appear under Uncategorized group
        await Expect(Page.Locator("button.btn-plain.border-0:has(i.bi-tag)").Filter(new LocatorFilterOptions { HasText = "Uncategorized" })).ToBeVisibleAsync();
        await Expect(Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Movable Habit" })).ToBeVisibleAsync();

        // Open habit and change category
        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Movable Habit" }).ClickAsync();
        await Page.Locator("select[aria-label='Category']").SelectOptionAsync(new SelectOptionValue { Label = "HabitMoveToCategory" });
        await Page.Locator("[data-habits-step-11]").ClickAsync(); // Close

        // Habit must appear under HabitMoveToCategory group
        await Expect(Page.Locator("button.btn-plain.border-0:has(i.bi-tag)").Filter(new LocatorFilterOptions { HasText = "HabitMoveToCategory" })).ToBeVisibleAsync();
        await Expect(Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Movable Habit" })).ToBeVisibleAsync();

        // Collapse HabitMoveToCategory — habit must disappear (confirms it is in that group)
        await Page.Locator("button.btn-plain.border-0:has(i.bi-tag)")
            .Filter(new LocatorFilterOptions { HasText = "HabitMoveToCategory" })
            .ClickAsync();
        await Expect(Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Movable Habit" })).ToHaveCountAsync(0);
    }

    // Regression guard for: bug where ChangeCategory + AddHabit both called habitCategory.Habits.Add,
    // causing the habit to appear twice in grouped-by-category view.
    [Test]
    public async Task AddHabit_WithCategory_AppearsExactlyOnce()
    {
        await CreateCategoryAsync("HabitOnceCategory");
        await EnableGroupedByCategoryAsync();

        await Page.Locator("button.btn-plain.input-group").ClickAsync();
        await Page.Locator("input[aria-required='true']").FillAsync("Once Habit");
        await Page.Locator("select[aria-label='Category']").SelectOptionAsync(new SelectOptionValue { Label = "HabitOnceCategory" });
        await Expect(Page.Locator("button:has(i.bi-floppy)")).ToBeEnabledAsync();
        await Page.Locator("button:has(i.bi-floppy)").ClickAsync();

        await Expect(Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Once Habit" })).ToHaveCountAsync(1);
    }

    [Test]
    public async Task HabitDuration_PersistedAfterReload()
    {
        await AddItemAsync("Duration Habit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Duration Habit" }).ClickAsync();

        await Page.Locator("select[aria-label='Duration hours']").SelectOptionAsync("1");
        await Page.Locator("select[aria-label='Duration minutes']").SelectOptionAsync("30");

        await Page.Locator("[data-habits-step-11]").ClickAsync(); // Close

        await WaitForIndexedDbAsync("HabitEntity", "habits => habits.some(habit => (habit.duration ?? habit.Duration) != null)"); // wait for the IndexedDB write before reload

        await Page.ReloadAsync();
        await Expect(Page.Locator("nav[aria-label]")).ToBeVisibleAsync();

        await NavigateToAsync("[data-main-step-5]");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Duration Habit" }).ClickAsync();

        await Expect(Page.Locator("select[aria-label='Duration hours']")).ToHaveValueAsync("1");
        await Expect(Page.Locator("select[aria-label='Duration minutes']")).ToHaveValueAsync("30");
    }

    [Test]
    public async Task HabitRepeatSettings_PersistedAfterReload()
    {
        await AddItemAsync("Repeat Settings Habit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Repeat Settings Habit" }).ClickAsync();

        // Change repeat count, interval, and period
        await Page.Locator("[data-habits-step-15] input[type='number']").First.FillAsync("3");
        await Page.Locator("[data-habits-step-15] input[type='number']").First.BlurAsync();

        await Page.Locator("[data-habits-step-15] input[type='number']").Last.FillAsync("7");
        await Page.Locator("[data-habits-step-15] input[type='number']").Last.BlurAsync();

        await Page.Locator("select[aria-label='Repeat period']").SelectOptionAsync("Week");

        await Page.Locator("[data-habits-step-11]").ClickAsync(); // Close

        await WaitForIndexedDbAsync("HabitEntity", "habits => habits.some(habit => (habit.repeatCount ?? habit.RepeatCount) == 3 && (habit.repeatInterval ?? habit.RepeatInterval) == 7)"); // wait for the IndexedDB write before reload

        await Page.ReloadAsync();
        await Expect(Page.Locator("nav[aria-label]")).ToBeVisibleAsync();

        await NavigateToAsync("[data-main-step-5]");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Repeat Settings Habit" }).ClickAsync();

        await Expect(Page.Locator("[data-habits-step-15] input[type='number']").First).ToHaveValueAsync("3");
        await Expect(Page.Locator("[data-habits-step-15] input[type='number']").Last).ToHaveValueAsync("7");
        await Expect(Page.Locator("select[aria-label='Repeat period']")).ToHaveValueAsync("Week");
    }

    [Test]
    public async Task HabitStartAt_SetDate_PersistedAfterReload()
    {
        await AddItemAsync("StartAt Habit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "StartAt Habit" }).ClickAsync();

        // data-habits-step-14 is the Start on date picker
        await Page.Locator("[data-habits-step-14] input[type='date']").FillAsync("2026-01-01");
        await Page.Locator("[data-habits-step-14] input[type='date']").BlurAsync();

        await Page.Locator("[data-habits-step-11]").ClickAsync(); // Close

        await WaitForIndexedDbAsync("HabitEntity", "habits => habits.some(habit => (habit.startAt ?? habit.StartAt) != null)"); // wait for the IndexedDB write before reload

        await Page.ReloadAsync();
        await Expect(Page.Locator("nav[aria-label]")).ToBeVisibleAsync();

        await NavigateToAsync("[data-main-step-5]");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "StartAt Habit" }).ClickAsync();

        await Expect(Page.Locator("[data-habits-step-14] input[type='date']")).ToHaveValueAsync("2026-01-01");
    }

    // Regression guard for: StartAt DB migration (adds DateTime? StartAt to HabitEntity).
    // ElapsedTime formula changes to: LastTimeDoneAt ?? TimeSpan.Zero.Max(DateTime.Now - (StartAt ?? CreatedAt)).
    // For a new habit with LastTimeDoneAt=null and StartAt=null, the display must still show ⊘ —
    // the Habits.razor display checks LastTimeDoneAt (not ElapsedTime) for the ⊘ vs value decision.
    [Test]
    public async Task NewHabit_BeforeMarkingDone_ElapsedTimeShowsNoData()
    {
        await AddItemAsync("ElapsedTime Test Habit");

        // data-habits-step-3 shows ⊘ when LastTimeDoneAt is null, or elapsed time when not null
        // It is always rendered in the list row regardless of ShowSmallCalendar setting
        ILocator habitRow = Page.Locator("div.input-group.flex-nowrap").Filter(
            new LocatorFilterOptions { Has = Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "ElapsedTime Test Habit" }) });

        await Expect(habitRow.Locator("[data-habits-step-3]")).ToContainTextAsync("⊘");
    }

    [Test]
    public async Task MarkHabitAsDone_OpenDetail_StreakBlockShows1()
    {
        await OpenSidebarAsync("bi-gear");
        await Page.Locator("label[for='ShowSmallCalendar']").ClickAsync();
        await Page.Locator("label[for='ShowHabitStatistics']").ClickAsync();
        await CloseSidebarAsync();

        await AddItemAsync("Streak Test Habit");

        ILocator habitRow = Page.Locator("div.input-group.flex-nowrap").Filter(
            new LocatorFilterOptions { Has = Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Streak Test Habit" }) });

        await habitRow.Locator("[data-habits-step-4]").ClickAsync();

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Streak Test Habit" }).ClickAsync();

        await Expect(Page.Locator("#habit-component")).ToBeVisibleAsync();

        ILocator streakBlock = Page.Locator("#habit-component div.p-1.border.rounded-0").First;
        await Expect(streakBlock).ToContainTextAsync("Current streak");
        await Expect(streakBlock).ToContainTextAsync("1");
    }

    [Test]
    public async Task HabitDisplayMetric_Quantity_PersistedAfterReload()
    {
        await AddItemAsync("Display Metric Habit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Display Metric Habit" }).ClickAsync();

        await Page.Locator("select[aria-label='Display']").SelectOptionAsync("Quantity");
        await Page.Locator("input[aria-label='Target quantity']").FillAsync("5");
        await Page.Locator("input[aria-label='Target quantity']").BlurAsync();

        await Page.Locator("[data-habits-step-11]").ClickAsync();

        await WaitForIndexedDbAsync("HabitEntity", "habits => habits.some(habit => (habit.targetQuantity ?? habit.TargetQuantity) == 5)"); // wait for the IndexedDB write before reload

        await Page.ReloadAsync();
        await Expect(Page.Locator("nav[aria-label]")).ToBeVisibleAsync();

        await NavigateToAsync("[data-main-step-5]");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Display Metric Habit" }).ClickAsync();

        await Expect(Page.Locator("select[aria-label='Display']")).ToHaveValueAsync("Quantity");
        await Expect(Page.Locator("input[aria-label='Target quantity']")).ToHaveValueAsync("5");
    }

    [Test]
    public async Task MarkAsDone_QuantityMode_ModalAppearsAndElapsedTimeUpdates()
    {
        await OpenSidebarAsync("bi-gear");
        await Page.Locator("label[for='ShowSmallCalendar']").ClickAsync();
        await CloseSidebarAsync();

        await AddItemAsync("Quantity Mode Habit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Quantity Mode Habit" }).ClickAsync();
        await Page.Locator("select[aria-label='Display']").SelectOptionAsync("Quantity");
        await Page.Locator("[data-habits-step-11]").ClickAsync();

        ILocator habitRow = Page.Locator("div.input-group.flex-nowrap").Filter(
            new LocatorFilterOptions { Has = Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Quantity Mode Habit" }) });

        await habitRow.Locator("[data-habits-step-4]").ClickAsync();

        await Expect(Page.Locator("div.modal.show")).ToBeVisibleAsync();

        await Page.Locator("div.modal.show button.btn-primary").ClickAsync();

        await Expect(habitRow.Locator("[data-habits-step-3]")).ToContainTextAsync("0 m");
    }

    // Path A: click day in small calendar (non-month mode) in Quantity mode
    [Test]
    public async Task Calendar_SmallCalendar_QuantityMode_ModalAppearsAndCellShowsQuantity()
    {
        await AddItemAsync("Small Cal Quantity Habit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Small Cal Quantity Habit" }).ClickAsync();
        await Page.Locator("select[aria-label='Display']").SelectOptionAsync("Quantity");
        await Page.Locator("[data-habits-step-11]").ClickAsync();

        ILocator todayCell = Page.Locator("[data-habits-step-6] button[role='gridcell']").Last;

        await todayCell.ClickAsync(new LocatorClickOptions { Force = true });

        await Expect(Page.Locator("div.modal.show")).ToBeVisibleAsync();

        await Page.Locator("div.modal.show input").FillAsync("3");
        await Page.Locator("div.modal.show button.btn-primary").ClickAsync();

        await Expect(todayCell).ToContainTextAsync("(3)");
    }

    // Path A2: + button in large calendar (month mode) in Quantity mode
    [Test]
    public async Task Calendar_LargeCalendar_IncreaseButton_QuantityMode_CellShowsQuantity()
    {
        await AddItemAsync("Large Cal Quantity Habit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Large Cal Quantity Habit" }).ClickAsync();
        await Page.Locator("select[aria-label='Display']").SelectOptionAsync("Quantity");

        string todayPrefix = DateTime.Today.ToString("dddd, MMMM d");
        ILocator todayCell = Page.Locator($"#habit-component button[role='gridcell'][aria-label^='{todayPrefix}']");
        await todayCell.ClickAsync();

        await Page.Locator("button[aria-label='Increase']").ClickAsync();

        await Expect(Page.Locator("div.modal.show")).ToBeVisibleAsync();

        await Page.Locator("div.modal.show input").FillAsync("3");
        await Page.Locator("div.modal.show button.btn-primary").ClickAsync();

        await Expect(todayCell).ToContainTextAsync("(3)");
    }

    // Path D: edit quantity in the large calendar time list
    [Test]
    public async Task LargeCalendar_EditQuantityInTimeList_CellUpdates()
    {
        await AddItemAsync("Time List Quantity Habit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Time List Quantity Habit" }).ClickAsync();
        await Page.Locator("select[aria-label='Display']").SelectOptionAsync("Quantity");

        string todayPrefix = DateTime.Today.ToString("dddd, MMMM d");
        ILocator todayCell = Page.Locator($"#habit-component button[role='gridcell'][aria-label^='{todayPrefix}']");
        await todayCell.ClickAsync();

        await Page.Locator("button[aria-label='Increase']").ClickAsync();

        await Page.Locator("div.modal.show input").FillAsync("3");
        await Page.Locator("div.modal.show button.btn-primary").ClickAsync();

        await Expect(todayCell).ToContainTextAsync("(3)");

        // Edit the quantity in the time list below the calendar
        await Page.Locator("#habit-component input[aria-label='Quantity']").FillAsync("5");
        await Page.Locator("#habit-component input[aria-label='Quantity']").BlurAsync();

        await Expect(todayCell).ToContainTextAsync("(5)");
    }

    // An end before the start is not saved, so the input must not keep showing it.
    [Test]
    public async Task LargeCalendar_EndBeforeStartInTimeList_InputShowsTheSavedEndAgain()
    {
        await AddItemAsync("Time List End Habit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Time List End Habit" }).ClickAsync();

        string todayPrefix = DateTime.Today.ToString("dddd, MMMM d");
        await Page.Locator($"#habit-component button[role='gridcell'][aria-label^='{todayPrefix}']").ClickAsync();

        await Page.Locator("button[aria-label='Increase']").ClickAsync();

        ILocator end = Page.Locator("#habit-component input[aria-label='to']");
        await Expect(end).Not.ToHaveValueAsync("");
        string savedEnd = await end.InputValueAsync();

        await end.FillAsync("00:00");
        await end.BlurAsync();

        await Expect(end).ToHaveValueAsync(savedEnd);
    }

    // Path C: timer stop in Quantity mode shows modal without cancel button
    [Test]
    public async Task Timer_Stop_QuantityMode_ModalHasNoCancelButton()
    {
        await AddItemAsync("Timer Quantity Habit");

        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Timer Quantity Habit" }).ClickAsync();
        await Page.Locator("select[aria-label='Display']").SelectOptionAsync("Quantity");

        await Page.Locator("button[aria-label='Start']").ClickAsync();
        await Page.WaitForTimeoutAsync(500);
        await Page.Locator("button[aria-label='Stop']").ClickAsync();

        await Expect(Page.Locator("div.modal.show")).ToBeVisibleAsync();

        // Timer stop modal has no cancel button (entry already saved, user must enter quantity)
        await Expect(Page.Locator("div.modal.show button.btn-close")).ToHaveCountAsync(0);

        await Page.Locator("div.modal.show button.btn-primary").ClickAsync();

        await Expect(Page.Locator("button[aria-label='Start']")).ToBeVisibleAsync();
    }

    // Regression guard for issue #21: long titles used to overflow the fixed-height habit row
    [Test]
    public async Task AddHabit_LongTitle_ClampedToRowWithFullTitleInTooltip()
    {
        string longTitle = "Long Title Habit " + string.Join(" ", Enumerable.Repeat("overflow", 30));

        await AddItemAsync(longTitle);

        ILocator titleButton = Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Long Title Habit" });
        await Expect(titleButton).ToBeVisibleAsync();

        // The full title stays available as a native tooltip
        await Expect(titleButton).ToHaveAttributeAsync("title", longTitle);

        // The clamped text must not spill below its row
        ILocator row = Page.Locator("div.input-group.flex-nowrap").Filter(new LocatorFilterOptions { Has = titleButton });
        LocatorBoundingBoxResult? rowBox = await row.BoundingBoxAsync();
        LocatorBoundingBoxResult? titleBox = await titleButton.Locator("span.title-clamp").BoundingBoxAsync();

        Assert.That(rowBox, Is.Not.Null);
        Assert.That(titleBox, Is.Not.Null);
        Assert.That(titleBox!.Y + titleBox.Height, Is.LessThanOrEqualTo(rowBox!.Y + rowBox.Height + 1));
    }

    // Two clicks that overlap each other's save must both be recorded, and no error may reach the page.
    [Test]
    public async Task SmallCalendar_DoubleClickOnADay_RecordsTwoCompletions()
    {
        await AddItemAsync("Double Click Habit");

        ILocator cells = Page.Locator("[data-habits-step-6]").First.Locator("button[role='gridcell']");
        await Expect(cells.And(Page.Locator(".border-primary-subtle"))).ToBeVisibleAsync();

        int todayIndex = await Page.EvaluateAsync<int>("() => [...document.querySelector(\"[data-habits-step-6]\").querySelectorAll(\"button[role='gridcell']\")].findIndex(c => c.classList.contains('border-primary-subtle'))");

        await cells.Nth(todayIndex - 1).DblClickAsync();

        await Expect(cells.Nth(todayIndex - 1)).ToContainTextAsync("2x");
    }

    // The app left open over midnight: the small calendar ends on the new day, with today marked.
    [Test]
    public async Task SmallCalendar_OpenOverMidnight_MarksTheNewDay()
    {
        DateTime lateEvening = DateTime.Today.AddDays(1).AddMinutes(-2);

        await Page.Clock.InstallAsync(new ClockInstallOptions { TimeDate = lateEvening });
        await AddItemAsync("Midnight Habit");

        ILocator today = Page.Locator("[data-habits-step-6]").First.Locator("button[role='gridcell'].border-primary-subtle");
        await Expect(today).ToHaveTextAsync(new Regex($"^{lateEvening.Day}"));

        await Page.Clock.FastForwardAsync("05:00");

        // opening and closing the habit repaints the list; the detail opens in the second column, so the list keeps its width
        await Page.Locator("[data-habits-step-2]").Filter(new LocatorFilterOptions { HasText = "Midnight Habit" }).ClickAsync();
        await Expect(Page.Locator("#habit-component")).ToBeVisibleAsync();
        await Page.Locator("[data-habits-step-11]").ClickAsync();
        await Expect(Page.Locator("#habit-component")).ToHaveCountAsync(0);

        await Expect(today).ToHaveTextAsync(new Regex($"^{lateEvening.AddMinutes(5).Day}"));
    }
}
