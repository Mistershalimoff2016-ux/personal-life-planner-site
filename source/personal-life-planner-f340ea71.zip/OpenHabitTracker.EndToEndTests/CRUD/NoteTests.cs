namespace OpenHabitTracker.EndToEndTests.CRUD;

// Prerequisite: start OpenHabitTracker.Blazor.Web at http://localhost before running tests.
// See: OpenHabitTracker.EndToEndTests/TODO.md for Playwright quirks and locator guidelines.

[TestFixture]
public class NoteTests : BaseTest
{
    [SetUp]
    public async Task SetUp()
    {
        await GotoAsync();
        await NavigateToAsync("[data-main-step-3]");
    }

    [Test]
    public async Task AddNote_TypeTitle_NoteAppearsInList()
    {
        await AddItemAsync("My Note");

        await Expect(Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "My Note" })).ToBeVisibleAsync();
    }

    [Test]
    public async Task AddNote_EmptyTitle_NoteIsNotAdded()
    {
        int initialCount = await Page.Locator("[data-notes-step-2]").CountAsync();

        await Page.Locator("button.btn-plain.input-group").ClickAsync();

        // Save button is disabled when title is empty
        await Expect(Page.Locator("button:has(i.bi-floppy)")).ToBeDisabledAsync();

        await Page.Locator("button:has(i.bi-x-square)").ClickAsync();

        await Expect(Page.Locator("[data-notes-step-2]")).ToHaveCountAsync(initialCount);
    }

    [Test]
    public async Task DeleteNote_AfterAdd_NoteDisappearsFromList()
    {
        await AddItemAsync("Delete Me");

        // Open note detail (second column at 1920px width)
        await Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Delete Me" }).ClickAsync();

        await Page.Locator("[data-notes-step-6]").ClickAsync();

        await Expect(Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Delete Me" })).ToHaveCountAsync(0);
    }

    [Test]
    public async Task DeleteNote_MovesToTrash()
    {
        await AddItemAsync("Trashed Note");

        await Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Trashed Note" }).ClickAsync();

        await Page.Locator("[data-notes-step-6]").ClickAsync();

        // Open Trash sidebar
        await OpenSidebarAsync("bi-trash");

        await Expect(Page.Locator("span.input-group-text").Filter(new LocatorFilterOptions { HasText = "Trashed Note" })).ToBeVisibleAsync();
    }

    [Test]
    public async Task EditNote_ChangesTitle_NewTitleVisible()
    {
        await AddItemAsync("Original");

        await Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Original" }).ClickAsync();

        // data-notes-step-5 wraps the title input in NoteComponent
        await Page.Locator("[data-notes-step-5] input").FillAsync("Updated");
        await Page.Locator("[data-notes-step-5] input").BlurAsync();

        await Page.Locator("[data-notes-step-7]").ClickAsync(); // Close note detail

        await Expect(Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Updated" })).ToBeVisibleAsync();
        await Expect(Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Original" })).ToHaveCountAsync(0);
    }

    [Test]
    public async Task EditNote_ChangeAllFields_CloseWorksOnFirstClick()
    {
        await AddItemAsync("Note To Edit");

        await Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Note To Edit" }).ClickAsync();

        // Change title
        await Page.Locator("[data-notes-step-5] input").FillAsync("Note Edited Title");
        await Page.Locator("[data-notes-step-5] input").BlurAsync();

        // Change content
        await Page.Locator("[data-notes-step-8] textarea").FillAsync("Note edited content text");
        await Page.Locator("[data-notes-step-8] textarea").BlurAsync();

        // Click Close once — must close the detail panel immediately (no second click required)
        await Page.Locator("[data-notes-step-7]").ClickAsync();

        await Expect(Page.Locator("[data-notes-step-7]")).ToHaveCountAsync(0);
        await Expect(Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Note Edited Title" })).ToBeVisibleAsync();
    }

    // The content saves on change, which typing alone does not raise.
    [Test]
    public async Task EditNote_TypeContentThenEscape_ContentKept()
    {
        await AddItemAsync("Escape Note");

        await Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Escape Note" }).ClickAsync();

        await Page.Locator("[data-notes-step-8] textarea").ClickAsync();
        await Page.Locator("[data-notes-step-8] textarea").PressSequentiallyAsync("typed before escape");
        await Page.Keyboard.PressAsync("Escape");

        await Expect(Page.Locator("#note-component")).ToHaveCountAsync(0);
        await Expect(Page.Locator("[data-notes-step-3]").Filter(new LocatorFilterOptions { HasText = "typed before escape" })).ToHaveCountAsync(1);
    }

    [Test]
    public async Task EditNote_ContentPersistsAfterReload()
    {
        await AddItemAsync("Content Note");

        await Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Content Note" }).ClickAsync();

        await Page.Locator("[data-notes-step-8] textarea").FillAsync("Persisted content text");
        await Page.Locator("[data-notes-step-8] textarea").BlurAsync();

        await Page.Locator("[data-notes-step-7]").ClickAsync(); // Close

        await WaitForIndexedDbAsync("NoteEntity", "notes => notes.some(note => (note.content ?? note.Content) == 'Persisted content text')"); // wait for the IndexedDB write before reload

        await Page.ReloadAsync();
        await Expect(Page.Locator("nav[aria-label]")).ToBeVisibleAsync();

        await NavigateToAsync("[data-main-step-3]");

        await Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Content Note" }).ClickAsync();

        await Expect(Page.Locator("[data-notes-step-8] textarea")).ToHaveValueAsync("Persisted content text");
    }

    [Test]
    public async Task AddNote_PersistedAfterReload()
    {
        await AddItemAsync("Persistent Note");

        await Page.ReloadAsync();
        await Expect(Page.Locator("nav[aria-label]")).ToBeVisibleAsync();

        await NavigateToAsync("[data-main-step-3]");

        await Expect(Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Persistent Note" })).ToBeVisibleAsync();
    }

    [Test]
    public async Task AddNote_WithSpecialCharacters_TitleDisplaysCorrectly()
    {
        const string specialTitle = "< > & \" '";

        await AddItemAsync(specialTitle);

        await Expect(Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = specialTitle })).ToBeVisibleAsync();

        await Page.ReloadAsync();
        await Expect(Page.Locator("nav[aria-label]")).ToBeVisibleAsync();
        await NavigateToAsync("[data-main-step-3]");

        await Expect(Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = specialTitle })).ToBeVisibleAsync();
    }

    [Test]
    public async Task EditNote_ChangeCategory_NoteMovesToNewGroup()
    {
        await CreateCategoryAsync("NoteMoveToCategory");
        await EnableGroupedByCategoryAsync();

        // Add uncategorized note — SetUp already navigated to notes
        await AddItemAsync("Movable Note");

        // Note should appear under Uncategorized group
        await Expect(Page.Locator("button.btn-plain.border-0:has(i.bi-tag)").Filter(new LocatorFilterOptions { HasText = "Uncategorized" })).ToBeVisibleAsync();
        await Expect(Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Movable Note" })).ToBeVisibleAsync();

        // Open note and change category
        await Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Movable Note" }).ClickAsync();
        await Page.Locator("select[aria-label='Category']").SelectOptionAsync(new SelectOptionValue { Label = "NoteMoveToCategory" });
        await Page.Locator("[data-notes-step-7]").ClickAsync(); // Close

        // Note must appear under NoteMoveToCategory group
        await Expect(Page.Locator("button.btn-plain.border-0:has(i.bi-tag)").Filter(new LocatorFilterOptions { HasText = "NoteMoveToCategory" })).ToBeVisibleAsync();
        await Expect(Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Movable Note" })).ToBeVisibleAsync();

        // Collapse NoteMoveToCategory — note must disappear (confirms it is in that group)
        await Page.Locator("button.btn-plain.border-0:has(i.bi-tag)")
            .Filter(new LocatorFilterOptions { HasText = "NoteMoveToCategory" })
            .ClickAsync();
        await Expect(Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Movable Note" })).ToHaveCountAsync(0);
    }

    // Regression guard for: bug where ChangeCategory + AddNote both called noteCategory.Notes.Add,
    // causing the note to appear twice in grouped-by-category view.
    [Test]
    public async Task AddNote_WithCategory_AppearsExactlyOnce()
    {
        await CreateCategoryAsync("NoteOnceCategory");
        await EnableGroupedByCategoryAsync();

        await Page.Locator("button.btn-plain.input-group").ClickAsync();
        await Page.Locator("input[aria-required='true']").FillAsync("Once Note");
        await Page.Locator("select[aria-label='Category']").SelectOptionAsync(new SelectOptionValue { Label = "NoteOnceCategory" });
        await Expect(Page.Locator("button:has(i.bi-floppy)")).ToBeEnabledAsync();
        await Page.Locator("button:has(i.bi-floppy)").ClickAsync();

        await Expect(Page.Locator("[data-notes-step-2]").Filter(new LocatorFilterOptions { HasText = "Once Note" })).ToHaveCountAsync(1);
    }
}
