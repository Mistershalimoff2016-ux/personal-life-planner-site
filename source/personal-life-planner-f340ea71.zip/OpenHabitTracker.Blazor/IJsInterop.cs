using Microsoft.AspNetCore.Components;
using OpenHabitTracker.Localization;

namespace OpenHabitTracker.Blazor;

public interface IJsInterop
{
    ValueTask ConsoleLog(string message);
    ValueTask SetMode(string mode);
    ValueTask SetLang(string lang);
    ValueTask<BrowserDateTimeParts> GetDateTimeParts();
    ValueTask SetTheme(string theme);
    ValueTask FocusElement(ElementReference element);
    ValueTask FocusElementById(string id);
    ValueTask FocusAndClick(ElementReference element);
    ValueTask BlurActiveElement();
    ValueTask TrapFocus(string id);
    ValueTask SaveFocus();
    ValueTask RestoreFocus();
    ValueTask SetElementProperty(ElementReference element, string property, object value);
    ValueTask<T> GetElementProperty<T>(ElementReference element, string property);
    Task<Dimensions> GetWindowDimensions();
    Task<Dimensions> GetElementDimensions(ElementReference element);
    ValueTask SaveAsUTF8(string filename, string content);
    ValueTask SetCalculateAutoHeight(ElementReference element);
    ValueTask HandleTabKey(ElementReference element);
    ValueTask PreventScrollKeys(ElementReference element);
    ValueTask<bool> RequestNotificationPermission();

    ValueTask<string> GetNotificationPermission();

    ValueTask SetVisibleAction(object dotnetRef);
    ValueTask ShowNotification(string title, string body, string route, object dotnetRef);
}
