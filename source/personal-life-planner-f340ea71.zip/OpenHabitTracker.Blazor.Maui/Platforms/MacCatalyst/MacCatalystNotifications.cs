using OpenHabitTracker.Services;
using System.Threading.Tasks;
using UserNotifications;

namespace OpenHabitTracker.Blazor.Maui;

// On Mac Catalyst the iOS settings URL opens the auto-generated settings-bundle screen rather
// than System Settings, so the notifications pane is opened by its own URL scheme instead. The
// user still picks the app from the list there.
public sealed class MacCatalystNotifications : PluginNotifications
{
    private const string NotificationsPane = "x-apple.systempreferences:com.apple.preference.notifications";

    public override async Task OpenSettings()
    {
        await Launcher.Default.OpenAsync(NotificationsPane);
    }

    // Apple reports the three states the row wants, where the plugin only reports a boolean.
    public override async Task<NotificationPermission> GetPermission()
    {
        UNNotificationSettings settings = await UNUserNotificationCenter.Current.GetNotificationSettingsAsync();

        return settings.AuthorizationStatus switch
        {
            UNAuthorizationStatus.NotDetermined => NotificationPermission.NotAsked,
            UNAuthorizationStatus.Denied => NotificationPermission.Blocked,
            // Authorized, Provisional and Ephemeral all deliver something.
            _ => NotificationPermission.Allowed
        };
    }
}
