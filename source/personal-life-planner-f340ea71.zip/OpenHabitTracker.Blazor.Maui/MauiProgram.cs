using Microsoft.Extensions.Logging;
using OpenHabitTracker.Backup;
using OpenHabitTracker.Blazor.Auth;
using OpenHabitTracker.Blazor.Files;
using OpenHabitTracker.Blazor.Layout;
using OpenHabitTracker.Blazor.Web.ApiClient;
using OpenHabitTracker.Data;
using OpenHabitTracker.EntityFrameworkCore;
using OpenHabitTracker.App;
using OpenHabitTracker.SelfTest;
using OpenHabitTracker.Services;

namespace OpenHabitTracker.Blazor.Maui;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        // Per-platform writable dir (e.g. /data/user/0/net.openhabittracker/files on Android);
        // routing the log here fixes the silent write failure of SpecialFolder.ApplicationData on Android/iOS.
        string appDataDirectory = FileSystem.Current.AppDataDirectory;
        Directory.CreateDirectory(appDataDirectory);

        // Windows and macCatalyst only: Android and iOS start the app with no command line,
        // so this is never true there and the app builds as usual.
        if (SelfTestRunner.IsRequested())
        {
            Environment.Exit(SelfTestRunner.RunSync(SelfTestChecks.Desktop(appDataDirectory), Console.Out));
        }

        AppDomain.CurrentDomain.UnhandledException += (sender, error) =>
        {
            try
            {
                string? message = error.ExceptionObject.ToString();

                System.Diagnostics.Debug.WriteLine(message);

                FileLog.Write(appDataDirectory, LogLevel.Critical, typeof(MauiProgram).FullName!, message ?? "Unhandled exception");

                Application.Current?.Dispatcher.Dispatch(async () =>
                {
                    if (Application.Current is Application application && application.Windows.Count > 0 && application.Windows[0].Page is Page page)
                        await page.DisplayAlertAsync("Error", message, "OK");
                });
            }
            catch
            {
            }
        };

        MauiAppBuilder builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();

        builder.Services.AddMauiBlazorWebView();

        builder.UseNotifications();

#if DEBUG
        builder.Services.AddBlazorWebViewDeveloperTools();
        builder.Logging.AddDebug();
        //builder.Logging.SetMinimumLevel(LogLevel.Debug);
#endif
        builder.Logging.AddConsole();
        builder.Logging.AddProvider(new FileLoggerProvider(appDataDirectory));

        string databasePath = Path.Combine(appDataDirectory, "OpenHT.db");

        builder.Services.AddServices();
        builder.Services.AddDataAccess(databasePath); // %localappdata%\Packages\...\LocalState - Environment.SpecialFolder.LocalApplicationData - FileSystem.Current.AppDataDirectory
        builder.Services.AddBackup();
        builder.Services.AddBlazor();
        builder.Services.AddScoped<IAppReview, AppReview>(); // different in Maui
        builder.Services.AddSingleton<NotificationRebuildRelay>(); // different in Maui, where App reaches it from outside the UI scope
        builder.Services.AddScoped<IOpenFile, OpenFile>(); // different in Maui, WinForms, Wpf
        builder.Services.AddScoped<ISaveFile, SaveFile>(); // different in Maui, WinForms, Wpf
        builder.Services.AddScoped<INavBarFragment, NavBarFragment>(); // different in Web
        builder.Services.AddScoped<IAssemblyProvider, AssemblyProvider>(); // different in Wasm, Web
        builder.Services.AddScoped<ILinkAttributeService, LinkAttributeService>(); // different in Photino
        builder.Services.AddScoped<IPreRenderService, PreRenderService>(); // different in Web
        builder.Services.AddScoped<IAuthFragment, OpenHabitTracker.Blazor.Auth.AuthFragment>();
        builder.Services.AddScoped<IAuthService, AuthService>();
        builder.Services.AddScoped<IAccountService, ApiAccountService>();
        builder.Services.AddHttpClients();

        MauiApp mauiApp = builder.Build();

        //ILoggerFactory loggerFactory = mauiApp.Services.GetRequiredService<ILoggerFactory>();
        // Microsoft.Extensions.Logging.Debug.DebugLoggerProvider

        ILogger<MauiApp> logger = mauiApp.Services.GetRequiredService<ILogger<MauiApp>>();
        logger.LogInformation("Initializing database");

        IDataAccess dataAccess = mauiApp.Services.GetServices<IDataAccess>().First(x => x.DataLocation == DataLocation.Local);
        dataAccess.Initialize().GetAwaiter().GetResult();

        //ClientState clientState = mauiApp.Services.GetRequiredService<ClientState>();
        //clientState.LoadUsers();
        //clientState.LoadSettings();

        //IAuthService authService = mauiApp.Services.GetRequiredService<IAuthService>();
        //authService.TryRefreshTokenLogin();

        logger.LogInformation("Running app");

        return mauiApp;
    }
}
