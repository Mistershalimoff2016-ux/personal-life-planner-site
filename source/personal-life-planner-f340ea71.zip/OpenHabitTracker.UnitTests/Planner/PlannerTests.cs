using Markdig;
using Microsoft.EntityFrameworkCore;
using NSubstitute;
using OpenHabitTracker.App;
using OpenHabitTracker.Backup.File;
using OpenHabitTracker.Data;
using OpenHabitTracker.Data.Models;
using OpenHabitTracker.Planner;
using OpenHabitTracker.Services;
using System.Text;
using Db = OpenHabitTracker.EntityFrameworkCore.ApplicationDbContext;
using Store = OpenHabitTracker.EntityFrameworkCore.DataAccess;

namespace OpenHabitTracker.UnitTests.Planner;

[TestFixture]
public class PlannerTests
{
    [Test]
    public void Today_IncludesOverdueAndCompletionsButNotDeletedOrTomorrow()
    {
        DateTime today = new(2026, 11, 17);
        TaskModel overdue = new() { PlannedAt = today.AddDays(-2) };
        TaskModel completed = new() { CompletedAt = today.AddHours(9) };
        TaskModel timed = new() { PlannedAt = today.AddHours(8), Priority = Priority.High };
        TaskModel tomorrow = new() { PlannedAt = today.AddDays(1) };
        TaskModel deleted = new() { PlannedAt = today, IsDeleted = true };
        TaskModel old = new() { PlannedAt = today.AddDays(-1), CompletedAt = today.AddDays(-1) };
        Assert.That(TodayPlan.Tasks([tomorrow, completed, deleted, timed, old, overdue], today), Is.EqualTo(new[] { overdue, timed, completed }));
    }

    [Test]
    public void Week_CountsCompletedOnlyAndUsesMondayAcrossYearBoundary()
    {
        Assert.That(Workout.CountThisWeek([
            new() { Date = new(2025,12,29), Completed = true },
            new() { Date = new(2026,1,4), Completed = true },
            new() { Date = new(2026,1,5), Completed = true },
            new() { Date = new(2026,1,1), Completed = false },
            new() { Date = new(2025,12,28), Completed = true }
        ], new(2026,1,1)), Is.EqualTo(2));
    }

    [TestCase("ordinary note")]
    [TestCase("<!-- personal-life-planner:workout:v2 -->\n```json\n{}\n```")]
    [TestCase("<!-- personal-life-planner:workout:v1 -->\n```json\n{broken}\n```")]
    [TestCase("<!-- personal-life-planner:workout:v1 -->\n```json\n{\"Exercises\":null}\n```")]
    [TestCase("<!-- personal-life-planner:workout:v1 -->\n```json\n{\"Exercises\":[null]}\n```")]
    public void OrdinaryOrUnknownOrDamagedNote_IsNotAWorkout(string content) =>
        Assert.That(Workout.FromNote(new() { Content = content }), Is.Null);

    [Test]
    public void DraftAllowsMissingDurationButCompletedWorkoutRequiresIt()
    {
        Workout workout = new();
        Assert.That(workout.Validate(), Is.Null);
        workout.Completed = true;
        Assert.That(workout.Validate(), Is.Not.Null);
        workout.Minutes = 60;
        workout.Exercises.Add(new() { Weight = -1 });
        Assert.That(workout.Validate(), Is.Not.Null);
    }

    private sealed class Factory(string path) : IDbContextFactory<Db>
    {
        public Db CreateDbContext() => new(new DbContextOptionsBuilder<Db>().UseSqlite($"Data Source={path};Pooling=False").Options);
    }
    private static ClientState State(IDataAccess store) => new([store], new(new MarkdownPipelineBuilder().UseAdvancedExtensions().Build()));

    [TestCase("json")]
    [TestCase("yaml")]
    public async Task LocalStore_ReopenEditExportRestore_PreservesWorkoutAndExistingData(string format)
    {
        string folder = Path.Combine(Path.GetTempPath(), "planner-test-" + Guid.NewGuid());
        Directory.CreateDirectory(folder);
        try
        {
            Store store = new(new Factory(Path.Combine(folder, "source.db")));
            await store.Initialize();
            ClientState state = State(store);
            await state.LoadUsers(); await state.LoadSettings();
            Workout draft = new() { Date = new(2026,11,16), Kind = "Силовая", Feeling = "Хорошо", Notes = "Первая строка\n```\nВторая", Exercises = [new() { Name = "Присед", Sets = 3, Reps = 8, Weight = 62.5m }] };
            NoteService notes = new(state, new SearchFilterService(), new(new MarkdownPipelineBuilder().Build()), Substitute.For<IAppReview>());
            await notes.Initialize(); notes.NewNote = new() { Title = "Тренировка", Content = draft.ToContent() }; await notes.AddNote();
            long id = notes.Notes!.Single().Id;
            notes.NewNote = new() { Title = "Обычная заметка", Content = "Не изменять" }; await notes.AddNote();
            TaskService tasks = new(state, new SearchFilterService(), Substitute.For<IAppReview>(), Substitute.For<INotificationScheduler>());
            await tasks.Initialize(); tasks.NewTask = new() { Title = "Задача", PlannedDate = DateTime.Today }; await tasks.AddTask();
            await tasks.MarkAsDone(tasks.Tasks!.Single());
            // Reopen from disk with fresh services, not the in-memory model.
            ClientState reopened = State(new Store(new Factory(Path.Combine(folder, "source.db"))));
            await reopened.LoadUsers(); await reopened.LoadSettings(); await reopened.LoadNotes();
            NoteModel saved = reopened.Notes![id];
            Workout workout = Workout.FromNote(saved)!;
            Assert.That(workout.Exercises.Single().Weight, Is.EqualTo(62.5m));
            Assert.That(workout.Completed, Is.False);
            workout.Completed = true; workout.Minutes = 55;
            NoteService editing = new(reopened, new SearchFilterService(), new(new MarkdownPipelineBuilder().Build()), Substitute.For<IAppReview>());
            editing.SelectedNote = saved; saved.Content = workout.ToContent(); await editing.UpdateNote();
            string backup = format == "json" ? await new JsonImportExport(reopened).GetDataExportFileString() : await new YamlImportExport(reopened).GetDataExportFileString();
            using MemoryStream stream = new(Encoding.UTF8.GetBytes(backup));
            UserImportExportData data = format == "json" ? await new JsonImportExport(reopened).ReadDataFile(stream) : await new YamlImportExport(reopened).ReadDataFile(stream);
            Store destination = new(new Factory(Path.Combine(folder, "restored.db"))); await destination.Initialize();
            ClientState restored = State(destination); await restored.LoadUsers(); await restored.LoadSettings();
            await restored.SetUserData(data);
            // A second reopen proves the import persisted.
            ClientState final = State(new Store(new Factory(Path.Combine(folder, "restored.db"))));
            await final.LoadUsers(); await final.LoadSettings(); await final.LoadNotes(); await final.LoadTasks();
            Workout result = final.Notes!.Values.Select(Workout.FromNote).OfType<Workout>().Single();
            Assert.Multiple(() =>
            {
                Assert.That(result.Completed, Is.True);
                Assert.That(result.Minutes, Is.EqualTo(55));
                Assert.That(result.Notes, Is.EqualTo(draft.Notes));
                Assert.That(result.Exercises.Single().Weight, Is.EqualTo(62.5m));
                Assert.That(final.Notes.Values.Single(n => n.Title == "Обычная заметка").Content, Is.EqualTo("Не изменять"));
                Assert.That(final.Tasks!.Values.Single().CompletedAt, Is.Not.Null);
            });
        }
        finally { Directory.Delete(folder, true); }
    }
}
