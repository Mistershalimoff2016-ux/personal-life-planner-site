using Bunit;
using GTour.Abstractions;
using Markdig;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Localization;
using NSubstitute;
using OpenHabitTracker.App;
using OpenHabitTracker.Blazor.Components;
using OpenHabitTracker.Data;
using OpenHabitTracker.Data.Models;
using OpenHabitTracker.Blazor;
using OpenHabitTracker.Services;

namespace OpenHabitTracker.UnitTests.Components;

[TestFixture]
public class HabitComponentTests
{
    private BunitContext _ctx = null!;
    private IHabitService _habitService = null!;
    private HabitModel _habit = null!;
    private ClientState _clientState = null!;

    [SetUp]
    public void SetUp()
    {
        _ctx = new BunitContext();

        _habitService = Substitute.For<IHabitService>();

        IDataAccess dataAccess = Substitute.For<IDataAccess>();
        dataAccess.DataLocation.Returns(DataLocation.Local);

        MarkdownPipeline pipeline = new MarkdownPipelineBuilder().UseAdvancedExtensions().Build();
        MarkdownToHtml markdownToHtml = new(pipeline);

        _clientState = new(new[] { dataAccess }, markdownToHtml);
        _clientState.Settings.ShowHelp = false;
        _clientState.Settings.ShowLargeCalendar = false;
        _clientState.Settings.ShowHabitStatistics = false;
        _clientState.Settings.ShowCategory = false;
        _clientState.Settings.ShowColor = false;
        _clientState.Settings.ShowCreatedUpdated = false;
        _clientState.Settings.ShowPriorityDropdown = false;

        IStringLocalizer loc = Substitute.For<IStringLocalizer>();
        loc[Arg.Any<string>()].Returns(callInfo => new LocalizedString(callInfo.RequiredArg<string>(), callInfo.RequiredArg<string>()));

        IJsInterop jsInterop = Substitute.For<IJsInterop>();

        _ctx.Services.AddScoped(_ => jsInterop);
        _ctx.Services.AddScoped(_ => _habitService);
        _ctx.Services.AddScoped(_ => _clientState);
        _ctx.Services.AddSingleton(loc);
        _ctx.Services.AddSingleton(Substitute.For<IGTourService>());
        _ctx.Services.AddSingleton(Substitute.For<IItemService>());
        _ctx.Services.AddSingleton(Substitute.For<ISearchFilterService>());

        _habit = new HabitModel { Title = "Morning Run", TimesDone = [] };
    }

    [TearDown]
    public void TearDown()
    {
        _ctx.Dispose();
    }

    [Test]
    public void Renders_HabitTitle_InExpectedElement()
    {
        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        AngleSharp.Dom.IElement titleInput = cut.Find("[data-habits-step-8] input");

        Assert.That(titleInput.GetAttribute("value"), Is.EqualTo("Morning Run"));
    }

    [Test]
    public async Task MarkAsDone_ButtonClick_InvokesHabitServiceMarkAsDone()
    {
        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        await cut.Find("[data-habits-step-9]").ClickAsync(new MouseEventArgs());

        await _habitService.Received(1).MarkAsDone(_habit);
    }

    [Test]
    public async Task StartTimer_ButtonClick_InvokesHabitServiceStart()
    {
        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        // Do NOT await: StartTimer() enters an infinite PeriodicTimer loop and never returns.
        // HabitService.Start() is called before the loop begins (mock returns Task.CompletedTask
        // synchronously), so by the time the click task suspends at WaitForNextTickAsync the call
        // is already recorded. TearDown disposes _ctx which disposes _timer, ending the loop.
        Task _ = cut.Find("[data-habits-step-19] button").ClickAsync(new MouseEventArgs());

        await _habitService.Received(1).Start(_habit);
    }

    // The quantity asked for after the stop belongs to the entry the stop completed, even when another
    // entry completes later today, like one edited to end at 23:59 or one imported at 12:00.
    [Test]
    public async Task StopTimer_QuantityHabit_SavesTheQuantityOnTheStoppedEntry()
    {
        _habit.DisplayMetric = DisplayMetric.Quantity;
        TimeModel laterToday = new() { Id = 1, StartedAt = DateTime.Today.AddHours(23), CompletedAt = DateTime.Today.AddHours(23).AddMinutes(59) };
        TimeModel running = new() { Id = 2, StartedAt = DateTime.Now };
        _habit.TimesDone = [laterToday, running];
        _habitService.When(x => x.MarkAsDone(_habit, Arg.Any<double?>())).Do(_ => running.CompletedAt = DateTime.Now);

        // The running entry shows as a running timer when the detail opens.
        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        await cut.WaitForElement("button[aria-label='Stop']").ClickAsync(new MouseEventArgs());

        cut.WaitForElement("#quantity-modal-input").Change("7");
        await cut.Find("#quantity-modal-ok").ClickAsync(new MouseEventArgs());

        await _habitService.Received(1).UpdateQuantity(_habit, running);
        Assert.That(running.Quantity, Is.EqualTo(7));
    }

    // A timer started before the detail was closed is still running in the data.
    [Test]
    public void Render_HabitWithARunningEntry_ShowsTheTimerRunningSinceItsStart()
    {
        _habit.TimesDone = [new TimeModel { Id = 1, StartedAt = DateTime.Now.AddMinutes(-5) }];

        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        Assert.Multiple(() =>
        {
            Assert.That(cut.FindAll("button[aria-label='Stop']"), Has.Count.EqualTo(1));
            Assert.That(cut.Find("[data-habits-step-19] span.input-group-text").TextContent, Does.StartWith("00:05:"));
        });
    }

    // Repeat 0 or every 0 gives an infinite ratio, and a negative number negative ratios.
    [TestCase("#countInput-0", "0")]
    [TestCase("#countInput-0", "-3")]
    [TestCase("#intervalInput-0", "0")]
    [TestCase("#intervalInput-0", "-3")]
    public void RepeatInput_BelowOne_SavesAndShowsOne(string input, string typed)
    {
        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        cut.Find(input).Change(typed);

        Assert.Multiple(() =>
        {
            Assert.That(_habit.RepeatCount, Is.EqualTo(1));
            Assert.That(_habit.RepeatInterval, Is.EqualTo(1));
            Assert.That(cut.Find(input).GetAttribute("value"), Is.EqualTo("1"));
            Assert.That(cut.Find(input).GetAttribute("min"), Is.EqualTo("1"));
        });
        _habitService.Received(1).UpdateHabit();
    }

    // The time a pause lasted is not part of the completion, so the moved start is saved on Resume.
    [Test]
    public async Task Timer_PauseThenResume_SavesTheMovedStart()
    {
        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        // Not awaited, for the reason in StartTimer_ButtonClick_InvokesHabitServiceStart.
        Task _ = cut.Find("[data-habits-step-19] button").ClickAsync(new MouseEventArgs());

        await cut.WaitForElement("button[aria-label='Pause']").ClickAsync(new MouseEventArgs());
        await cut.WaitForElement("button[aria-label='Resume']").ClickAsync(new MouseEventArgs());

        await _habitService.Received(1).SetStartTime(_habit, Arg.Any<DateTime>());
    }

    [Test]
    public async Task DeleteButton_Click_InvokesHabitServiceDeleteHabit()
    {
        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        await cut.Find("[data-habits-step-10]").ClickAsync(new MouseEventArgs());

        await _habitService.Received(1).DeleteHabit(_habit);
    }

    // --- Streak block tests ---

    [Test]
    public void Charts_WhenShowHabitChartsFalse_AreNotRendered()
    {
        // ShowHabitCharts is already false in SetUp
        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        Assert.That(cut.FindAll("[data-habits-step-27]"), Is.Empty);
    }

    [Test]
    public void Charts_WhenShowHabitChartsTrue_RenderAllFivePanels()
    {
        _clientState.Settings.ShowHabitCharts = true;

        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        Assert.Multiple(() =>
        {
            Assert.That(cut.FindAll("[data-habits-step-27]"), Has.Count.EqualTo(1));
            Assert.That(cut.FindAll("[data-habits-step-28]"), Has.Count.EqualTo(1));
            Assert.That(cut.FindAll("[data-habits-step-29]"), Has.Count.EqualTo(1));
            Assert.That(cut.FindAll("[data-habits-step-30]"), Has.Count.EqualTo(1));
            Assert.That(cut.FindAll("[data-habits-step-31]"), Has.Count.EqualTo(1));
        });
    }

    [Test]
    public void Charts_AreIndependentOfShowHabitStatistics()
    {
        _clientState.Settings.ShowHabitCharts = true;
        _clientState.Settings.ShowHabitStatistics = false;

        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        Assert.Multiple(() =>
        {
            Assert.That(cut.FindAll("[data-habits-step-27]"), Has.Count.EqualTo(1));
            Assert.That(cut.FindAll("[data-habits-step-20]"), Is.Empty);
        });
    }

    [Test]
    public void StreakBlock_WhenShowHabitStatisticsTrue_RendersCurrentStreakLabel()
    {
        _clientState.Settings.ShowHabitStatistics = true;

        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        Assert.That(cut.Markup, Does.Contain("Current streak"));
    }

    [Test]
    public void StreakBlock_WhenShowHabitStatisticsFalse_NoCurrentStreakLabel()
    {
        // ShowHabitStatistics is already false in SetUp

        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        Assert.That(cut.Markup, Does.Not.Contain("Current streak"));
    }

    [Test]
    public void StreakBlock_WhenCurrentStreakNull_Renders0()
    {
        _clientState.Settings.ShowHabitStatistics = true;
        // _habit.CurrentStreak is null by default

        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        AngleSharp.Dom.IElement streakBlock = cut.FindAll(".p-1.border.rounded-0")[0];
        Assert.That(streakBlock.TextContent, Does.Contain("0"));
    }

    [Test]
    public void StreakBlock_WhenCurrentStreak5_Renders5InStreakBlock()
    {
        _clientState.Settings.ShowHabitStatistics = true;
        _habit.CurrentStreak = new Streak { Count = 5, From = DateTime.Today.AddDays(-4), To = DateTime.Today };

        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        AngleSharp.Dom.IElement streakBlock = cut.FindAll(".p-1.border.rounded-0")[0];
        Assert.That(streakBlock.TextContent, Does.Contain("5"));
    }

    [Test]
    public void StreakBlock_WhenBestStreakNotNull_RendersBestStreakDateRange()
    {
        _clientState.Settings.ShowHabitStatistics = true;
        _habit.BestStreak = new Streak { Count = 3, From = new DateTime(2025, 1, 1), To = new DateTime(2025, 1, 3) };

        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        Assert.That(cut.Markup, Does.Contain("("));
    }

    [Test]
    public void StreakBlock_WhenBestStreakNull_NoBestStreakDateRange()
    {
        _clientState.Settings.ShowHabitStatistics = true;
        // _habit.BestStreak is null by default

        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        Assert.That(cut.Markup, Does.Not.Contain("("));
    }

    // --- DisplayMetric feature tests ---

    [Test]
    public void DisplayMetric_Select_IsRendered()
    {
        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        AngleSharp.Dom.IElement select = cut.Find("[data-habits-step-17] select");

        Assert.That(select, Is.Not.Null);
    }

    [Test]
    public void TargetQuantity_Input_HiddenWhenDisplayMetricIsRepetitions()
    {
        // _habit.DisplayMetric is Repetitions by default

        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        Assert.That(cut.FindAll("[data-habits-step-18]"), Is.Empty);
    }

    [Test]
    public void TargetQuantity_Input_VisibleWhenDisplayMetricIsQuantity()
    {
        _habit.DisplayMetric = DisplayMetric.Quantity;

        IRenderedComponent<HabitComponent> cut = _ctx.Render<HabitComponent>(
            parameters => parameters.Add(p => p.Habit, _habit));

        Assert.That(cut.Find("[data-habits-step-18]"), Is.Not.Null);
    }
}
