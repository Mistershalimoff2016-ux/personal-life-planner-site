using Bunit;
using OpenHabitTracker.Blazor.Pages;
using OpenHabitTracker.Planner;

namespace OpenHabitTracker.UnitTests.Components;

[TestFixture]
public class PlannerComponentTests
{
    [Test]
    public async Task QuickAdd_InputEnablesSaveAndCompletionPersists()
    {
        using AppTestContext app = new();
        await app.Start();
        var cut = app.Ctx.Render<Today>();
        cut.WaitForAssertion(() => Assert.That(cut.FindAll("input[maxlength]").Count, Is.EqualTo(1)));
        var input = cut.Find("input[maxlength]");
        input.Input("Купить продукты");
        var save = cut.Find("form button");
        Assert.That(save.HasAttribute("disabled"), Is.False);
        save.Click();
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Купить продукты")));
        Assert.That((await app.Store.GetTasks()).Single().Title, Is.EqualTo("Купить продукты"));
        cut.FindAll("button").Single(b => b.TextContent == "Выполнить").Click();
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Выполнено — отменить")));
        Assert.That((await app.Store.GetTasks()).Single().CompletedAt, Is.Not.Null);
    }

    [Test]
    public async Task WorkoutDraftCanBeSavedAndEditedThroughForm()
    {
        using AppTestContext app = new();
        await app.Start();
        var cut = app.Ctx.Render<Workouts>();
        cut.FindAll("button").Single(b => b.TextContent == "Новая тренировка").Click();
        cut.Find("form").Submit();
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Запись сохранена.")));
        Assert.That(Workout.FromNote(new() { Content = (await app.Store.GetNotes()).Single().Content })!.Completed, Is.False);
        cut.FindAll("button").Single(b => b.TextContent == "Редактировать").Click();
        cut.Find("input[type=number]").Change("45");
        cut.Find("input[type=checkbox]").Change(true);
        cut.Find("form").Submit();
        cut.WaitForAssertion(() => Assert.That(cut.Markup, Does.Contain("Завершено за неделю: 1")));
        var stored = Workout.FromNote(new() { Content = (await app.Store.GetNotes()).Single().Content })!;
        Assert.That(stored.Minutes, Is.EqualTo(45));
        Assert.That(stored.Completed, Is.True);
    }
}
