using HtmlAgilityPack;
using OpenHabitTracker.Data;
using OpenHabitTracker.Data.Models;
using OpenHabitTracker.Query;
using OpenHabitTracker.Services;

namespace OpenHabitTracker.UnitTests.Services;

[TestFixture]
public class SearchFilterServiceTests
{
    private SearchFilterService _sut = null!;

    [SetUp]
    public void SetUp()
    {
        _sut = new();
    }

    [TearDown]
    public void TearDown()
    {
        _sut.SearchTerm = null;
        _sut.MatchCase = false;
    }

    // --- GetQueryParameters tests ---

    [Test]
    public void GetQueryParameters_MapsSearchTermAndMatchCase()
    {
        _sut.SearchTerm = "hello";
        _sut.MatchCase = true;

        QueryParameters qp = _sut.GetQueryParameters(new SettingsModel());

        Assert.That(qp.SearchTerm, Is.EqualTo("hello"));
        Assert.That(qp.MatchCase, Is.True);
    }

    [Test]
    public void GetQueryParameters_MapsSettingsFields()
    {
        SettingsModel settings = new()
        {
            HideCompletedTasks = true,
            ShowOnlyOverSelectedRatioMin = true,
            SelectedRatioMin = 75,
            ShowOnlyUnderSelectedRatioMax = true,
            SelectedRatioMax = 200,
            SelectedRatio = Ratio.ElapsedToDesired,
            CategoryFilterDisplay = FilterDisplay.CheckBoxes,
            PriorityFilterDisplay = FilterDisplay.SelectOptions,
        };

        QueryParameters qp = _sut.GetQueryParameters(settings);

        Assert.That(qp.HideCompletedTasks, Is.True);
        Assert.That(qp.ShowOnlyOverSelectedRatioMin, Is.True);
        Assert.That(qp.SelectedRatioMin, Is.EqualTo(75));
        Assert.That(qp.ShowOnlyUnderSelectedRatioMax, Is.True);
        Assert.That(qp.SelectedRatioMax, Is.EqualTo(200));
        Assert.That(qp.SelectedRatio, Is.EqualTo(Ratio.ElapsedToDesired));
        Assert.That(qp.CategoryFilterDisplay, Is.EqualTo(FilterDisplay.CheckBoxes));
        Assert.That(qp.PriorityFilterDisplay, Is.EqualTo(FilterDisplay.SelectOptions));
    }

    [Test]
    public void GetQueryParameters_MapsTheCategoryPriorityAndSortSelections()
    {
        SettingsModel settings = new()
        {
            SelectedCategoryId = 4,
            SelectedPriority = Priority.High,
            HiddenCategoryIds = [2, 3],
        };
        settings.ShowPriority[Priority.Low] = false;
        settings.SortBy[ContentType.Task] = Sort.Duration;

        QueryParameters qp = _sut.GetQueryParameters(settings);

        Assert.Multiple(() =>
        {
            Assert.That(qp.SelectedCategoryId, Is.EqualTo(4));
            Assert.That(qp.SelectedPriority, Is.EqualTo(Priority.High));
            Assert.That(qp.HiddenCategoryIds, Is.EqualTo(new[] { 2L, 3L }));
            Assert.That(qp.ShowPriority[Priority.Low], Is.False);
            Assert.That(qp.ShowPriority[Priority.High], Is.True);
            Assert.That(qp.SortBy[ContentType.Task], Is.EqualTo(Sort.Duration));
            Assert.That(qp.SortBy[ContentType.Note], Is.EqualTo(Sort.Priority));
        });
    }

    [Test]
    public void GetQueryParameters_RelativeOffsetsBeyondTheCap_ResolveToTheCap()
    {
        SettingsModel settings = new() { PlannedFromDayOffset = -20000, PlannedToDayOffset = 20000 };

        DateTime before = DateTime.Today;
        QueryParameters qp = _sut.GetQueryParameters(settings);
        DateTime after = DateTime.Today;

        // GetQueryParameters reads the clock itself, so a run across midnight may resolve against either day.
        Assert.Multiple(() =>
        {
            Assert.That(qp.PlannedRangeStart, Is.EqualTo(before.AddDays(-SettingsModel.MaxDayOffset)).Or.EqualTo(after.AddDays(-SettingsModel.MaxDayOffset)));
            Assert.That(qp.PlannedRangeEnd, Is.EqualTo(before.AddDays(SettingsModel.MaxDayOffset)).Or.EqualTo(after.AddDays(SettingsModel.MaxDayOffset)));
        });
    }

    // --- MarkSearchResults tests ---

    [Test]
    public void MarkSearchResults_CaseInsensitive_WrapsMatchInMarkTag()
    {
        _sut.SearchTerm = "hello";
        _sut.MatchCase = false;

        string result = _sut.MarkSearchResults("Say Hello World");

        Assert.That(result, Is.EqualTo("Say <mark>Hello</mark> World"));
    }

    [Test]
    public void MarkSearchResults_CaseSensitive_MatchesExactCase()
    {
        _sut.SearchTerm = "hello";
        _sut.MatchCase = true;

        string result = _sut.MarkSearchResults("Say hello World");

        Assert.That(result, Is.EqualTo("Say <mark>hello</mark> World"));
    }

    [Test]
    public void MarkSearchResults_CaseSensitive_NoMatchOnDifferentCase()
    {
        _sut.SearchTerm = "hello";
        _sut.MatchCase = true;

        string result = _sut.MarkSearchResults("Say Hello World");

        Assert.That(result, Is.EqualTo("Say Hello World"));
    }

    [Test]
    public void MarkSearchResults_EmptySearchTerm_OnlyEncodesTheText()
    {
        _sut.SearchTerm = string.Empty;

        Assert.That(_sut.MarkSearchResults("a<b"), Is.EqualTo("a&lt;b"));
    }

    [Test]
    public void MarkSearchResults_MatchAtTheStartAndEndAndAdjacent_MarksEveryOccurrence()
    {
        _sut.SearchTerm = "ab";

        Assert.That(_sut.MarkSearchResults("ababxab"), Is.EqualTo("<mark>ab</mark><mark>ab</mark>x<mark>ab</mark>"));
    }

    [Test]
    public void MarkSearchResults_WhenSearchTermIsNull_ReturnsInputUnchanged()
    {
        _sut.SearchTerm = null;

        string result = _sut.MarkSearchResults("Some text");

        Assert.That(result, Is.EqualTo("Some text"));
    }

    // A title is plain text, and the result is rendered as markup.
    [TestCase(null, "Learn <canvas> API")]
    [TestCase("a", "Learn <canvas> API")]
    [TestCase(null, "a<b c")]
    [TestCase("t", "Tom & Jerry")]
    public void MarkSearchResults_TextWithMarkupCharacters_ShowsAsTyped(string? term, string text)
    {
        _sut.SearchTerm = term;

        string result = _sut.MarkSearchResults(text);

        Assert.That(VisibleText(result), Is.EqualTo(text));
    }

    // --- MarkSearchResultsInHtml tests ---

    [Test]
    public void MarkSearchResultsInHtml_WrapsTextNodesOnly_DoesNotCorruptHtmlTags()
    {
        _sut.SearchTerm = "bold";
        _sut.MatchCase = false;

        string html = "<p>This is <strong>bold text</strong> here.</p>";
        string result = _sut.MarkSearchResultsInHtml(html);

        Assert.That(result, Is.EqualTo("<p>This is <strong><mark>bold</mark> text</strong> here.</p>"));
    }

    [Test]
    public void MarkSearchResultsInHtml_TermOnlyInATagName_LeavesTheHtmlUnchanged()
    {
        _sut.SearchTerm = "strong";
        string html = "<p>This is <strong>bold</strong></p>";

        Assert.That(_sut.MarkSearchResultsInHtml(html), Is.EqualTo(html));
    }

    [Test]
    public void MarkSearchResultsInHtml_NoTextNodes_ReturnsTheInput()
    {
        _sut.SearchTerm = "x";
        string html = "<hr>";

        Assert.That(_sut.MarkSearchResultsInHtml(html), Is.EqualTo(html));
    }

    [Test]
    public void MarkSearchResultsInHtml_WhenSearchTermIsNull_ReturnsInputUnchanged()
    {
        _sut.SearchTerm = null;
        string html = "<p>Some text</p>";

        Assert.That(_sut.MarkSearchResultsInHtml(html), Is.EqualTo(html));
    }

    // --- MarkSearchResults multiple occurrences ---

    [Test]
    public void MarkSearchResults_CaseInsensitive_MultipleOccurrences_WrapsAll()
    {
        _sut.SearchTerm = "cat";
        _sut.MatchCase = false;

        string result = _sut.MarkSearchResults("The cat sat on the Cat mat");

        Assert.That(result, Does.Contain("<mark>cat</mark>"));
        Assert.That(result, Does.Contain("<mark>Cat</mark>"));
        Assert.That(result.Split("<mark>").Length - 1, Is.EqualTo(2));
    }

    [Test]
    public void MarkSearchResults_CaseSensitive_MultipleOccurrences_WrapsAll()
    {
        _sut.SearchTerm = "cat";
        _sut.MatchCase = true;

        string result = _sut.MarkSearchResults("the cat sat on the cat mat");

        Assert.That(result, Does.Contain("<mark>cat</mark>"));
        Assert.That(result.Split("<mark>").Length - 1, Is.EqualTo(2));
    }

    // --- GetQueryParameters DoneAt/PlannedAt mapping ---

    [Test]
    public void GetQueryParameters_MapsDoneAtFilter()
    {
        DateTime filterDate = new(2025, 6, 10);
        _sut.DoneAtFilter = filterDate;
        _sut.DoneAtCompare = DateCompare.After;

        QueryParameters qp = _sut.GetQueryParameters(new SettingsModel());

        Assert.That(qp.DoneAtFilter, Is.EqualTo(filterDate));
        Assert.That(qp.DoneAtCompare, Is.EqualTo(DateCompare.After));
    }

    [Test]
    public void GetQueryParameters_MapsPlannedAtFilter()
    {
        DateTime filterDate = new(2025, 3, 15);
        _sut.PlannedAtFilter = filterDate;
        _sut.PlannedAtCompare = DateCompare.Before;

        QueryParameters qp = _sut.GetQueryParameters(new SettingsModel());

        Assert.That(qp.PlannedAtFilter, Is.EqualTo(filterDate));
        Assert.That(qp.PlannedAtCompare, Is.EqualTo(DateCompare.Before));
    }

    // --- GetQueryParameters relative range offsets ---

    [Test]
    public void GetQueryParameters_ResolvesRelativeOffsetsToDatesFromToday()
    {
        SettingsModel settings = new()
        {
            PlannedFromDayOffset = -7,
            PlannedToDayOffset = 7,
            DoneFromDayOffset = -3,
            DoneToDayOffset = null,
        };

        DateTime before = DateTime.Today;
        QueryParameters qp = _sut.GetQueryParameters(settings);
        DateTime after = DateTime.Today;

        // GetQueryParameters reads the clock itself, so a run across midnight may resolve against either day.
        Assert.That(qp.PlannedRangeStart, Is.EqualTo(before.AddDays(-7)).Or.EqualTo(after.AddDays(-7)));
        Assert.That(qp.PlannedRangeEnd, Is.EqualTo(before.AddDays(7)).Or.EqualTo(after.AddDays(7)));
        Assert.That(qp.DoneRangeStart, Is.EqualTo(before.AddDays(-3)).Or.EqualTo(after.AddDays(-3)));
        Assert.That(qp.DoneRangeEnd, Is.Null);
    }

    [Test]
    public void GetQueryParameters_NoRelativeOffsets_LeavesRangeBoundsNull()
    {
        QueryParameters qp = _sut.GetQueryParameters(new SettingsModel());

        Assert.That(qp.PlannedRangeStart, Is.Null);
        Assert.That(qp.PlannedRangeEnd, Is.Null);
        Assert.That(qp.DoneRangeStart, Is.Null);
        Assert.That(qp.DoneRangeEnd, Is.Null);
    }

    [Test]
    public void GetQueryParameters_MapsShowDoneInRange()
    {
        QueryParameters qp = _sut.GetQueryParameters(new SettingsModel { ShowDoneInRange = true });

        Assert.That(qp.ShowDoneInRange, Is.True);
    }

    // --- MarkSearchResultsInHtml case-sensitive multiple occurrences ---

    [Test]
    public void MarkSearchResultsInHtml_CaseSensitive_MultipleOccurrences_WrapsAll()
    {
        _sut.SearchTerm = "cat";
        _sut.MatchCase = true;

        string html = "<p>the cat sat on the cat mat</p>";
        string result = _sut.MarkSearchResultsInHtml(html);

        Assert.That(result.Split("<mark>").Length - 1, Is.EqualTo(2));
        Assert.That(result, Does.Contain("<mark>cat</mark>"));
    }

    // Rendered markdown holds & < > " as entities, and a term can match letters of an entity's name.
    [TestCase("<p>Tom &amp; Jerry say</p>", "a", false, "Tom & Jerry say")]
    [TestCase("<p>Read &lt;30 pages test</p>", "t", true, "Read <30 pages test")]
    public void MarkSearchResultsInHtml_TermMatchesLettersOfAnEntity_KeepsTheVisibleText(string html, string term, bool matchCase, string visible)
    {
        _sut.SearchTerm = term;
        _sut.MatchCase = matchCase;

        string result = _sut.MarkSearchResultsInHtml(html);

        Assert.That(VisibleText(result), Is.EqualTo(visible));
        Assert.That(result, Does.Contain($"<mark>{term}</mark>"));
    }

    // A browser decodes each text node on its own, so an entity split by a tag stays as written.
    private static string VisibleText(string html)
    {
        HtmlDocument document = new();
        document.LoadHtml(html);

        return string.Concat(document.DocumentNode.SelectNodes("//text()").Select(x => HtmlEntity.DeEntitize(x.InnerText)));
    }
}
