using Markdig;
using NSubstitute;
using OpenHabitTracker.App;
using OpenHabitTracker.Data;
using OpenHabitTracker.Data.Entities;
using OpenHabitTracker.Data.Models;
using OpenHabitTracker.Services;

namespace OpenHabitTracker.UnitTests.Services;

[TestFixture]
public class CategoryServiceTests
{
    private IDataAccess _dataAccess = null!;
    private ClientState _clientState = null!;
    private INotificationScheduler _notificationScheduler = null!;
    private CategoryService _sut = null!;

    [SetUp]
    public void SetUp()
    {
        _dataAccess = Substitute.For<IDataAccess>();
        _dataAccess.DataLocation.Returns(DataLocation.Local);
        _dataAccess.GetTimes().Returns(Task.FromResult<IReadOnlyList<TimeEntity>>([]));

        MarkdownPipeline pipeline = new MarkdownPipelineBuilder().UseAdvancedExtensions().Build();
        MarkdownToHtml markdownToHtml = new(pipeline);
        _clientState = new(new[] { _dataAccess }, markdownToHtml);

        _notificationScheduler = Substitute.For<INotificationScheduler>();

        _sut = new(_clientState, _notificationScheduler);
    }

    // --- GetCategoryTitle tests ---

    [Test]
    public void GetCategoryTitle_WhenFound_ReturnsTitle()
    {
        _clientState.Categories = TestData.CategoryDict(TestData.Category(id: 5, title: "Work"));

        string result = _sut.GetCategoryTitle(5);

        Assert.That(result, Is.EqualTo("Work"));
    }

    [Test]
    public void GetCategoryTitle_WhenNotFound_ReturnsIdAsString()
    {
        _clientState.Categories = TestData.CategoryDict();

        string result = _sut.GetCategoryTitle(99);

        Assert.That(result, Is.EqualTo("99"));
    }

    // --- SetSelectedCategory tests ---

    [Test]
    public void SetSelectedCategory_WhenIdExists_SetsSelectedCategory()
    {
        CategoryModel category = TestData.Category(id: 7, title: "Work");
        _clientState.Categories = TestData.CategoryDict(category);

        _sut.SetSelectedCategory(7);

        Assert.That(_sut.SelectedCategory, Is.SameAs(category));
    }

    [Test]
    public void SetSelectedCategory_WhenIdIsNull_ClearsSelectedCategory()
    {
        CategoryModel category = TestData.Category(id: 7);
        _clientState.Categories = TestData.CategoryDict(category);
        _sut.SelectedCategory = category;

        _sut.SetSelectedCategory(null);

        Assert.That(_sut.SelectedCategory, Is.Null);
    }

    [Test]
    public void SetSelectedCategory_WhenIdDoesNotExist_SetsSelectedCategoryToNull()
    {
        _clientState.Categories = TestData.CategoryDict(TestData.Category(id: 1));

        _sut.SetSelectedCategory(99);

        Assert.That(_sut.SelectedCategory, Is.Null);
    }

    // --- AddCategory tests ---

    [Test]
    public async Task AddCategory_AddsToClientStateDictionary()
    {
        _clientState.Categories = new();
        _sut.NewCategory = new CategoryModel { Title = "Health" };

        await _sut.AddCategory();

        Assert.That(_clientState.Categories, Has.Count.EqualTo(1));
        Assert.That(_clientState.Categories.Values.Single().Title, Is.EqualTo("Health"));
    }

    [Test]
    public async Task AddCategory_ResetsNewCategoryAfterAdd()
    {
        _clientState.Categories = new();
        _sut.NewCategory = new CategoryModel { Title = "Health" };

        await _sut.AddCategory();

        // After add, NewCategory should be a fresh instance (not null, but reset)
        Assert.That(_sut.NewCategory, Is.Not.Null);
        Assert.That(_sut.NewCategory!.Title, Is.Null.Or.Empty);
    }

    // --- UpdateCategory tests ---

    [Test]
    public async Task UpdateCategory_ChangesTitle()
    {
        CategoryModel category = TestData.Category(id: 1, title: "Old Title");
        _clientState.Categories = TestData.CategoryDict(category);
        _sut.SelectedCategory = category;
        _dataAccess.GetCategory(category.Id).Returns(Task.FromResult<CategoryEntity?>(new CategoryEntity { Id = category.Id }));

        await _sut.UpdateCategory("New Title");

        Assert.That(category.Title, Is.EqualTo("New Title"));
    }

    [TestCase("")]
    [TestCase("   ")]
    public async Task UpdateCategory_EmptyTitle_KeepsTheOldTitle(string title)
    {
        CategoryModel category = TestData.Category(id: 1, title: "Old Title");
        _clientState.Categories = TestData.CategoryDict(category);
        _sut.SelectedCategory = category;

        await _sut.UpdateCategory(title);

        Assert.Multiple(() =>
        {
            Assert.That(category.Title, Is.EqualTo("Old Title"));
            Assert.That(_sut.SelectedCategory, Is.Null);
        });
        await _dataAccess.DidNotReceive().UpdateCategory(Arg.Any<CategoryEntity>());
    }

    [Test]
    public async Task UpdateCategory_ClearsSelectedCategory()
    {
        CategoryModel category = TestData.Category(id: 1, title: "Title");
        _clientState.Categories = TestData.CategoryDict(category);
        _sut.SelectedCategory = category;
        _dataAccess.GetCategory(category.Id).Returns(Task.FromResult<CategoryEntity?>(new CategoryEntity { Id = category.Id }));

        await _sut.UpdateCategory("Title");

        Assert.That(_sut.SelectedCategory, Is.Null);
    }

    // --- DeleteCategory tests ---
    // CRITICAL: DeleteCategory reads from category.Notes/Tasks/Habits (NOT from clientState collections)

    [Test]
    public async Task DeleteCategory_CascadesIsDeleted_AndCategoryId0_ToNotes()
    {
        NoteModel note = TestData.Note(id: 1, categoryId: 10);
        CategoryModel category = TestData.Category(id: 10, notes: [note]);
        _clientState.Categories = TestData.CategoryDict(category);
        _dataAccess.GetNote(note.Id).Returns(Task.FromResult<NoteEntity?>(new NoteEntity { Id = note.Id }));

        await _sut.DeleteCategory(category);

        Assert.That(note.IsDeleted, Is.True);
        Assert.That(note.CategoryId, Is.EqualTo(0));
    }

    [Test]
    public async Task DeleteCategory_CascadesIsDeleted_AndCategoryId0_ToTasks()
    {
        TaskModel task = TestData.Task(id: 1, categoryId: 10);
        CategoryModel category = TestData.Category(id: 10, tasks: [task]);
        _clientState.Categories = TestData.CategoryDict(category);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.DeleteCategory(category);

        Assert.That(task.IsDeleted, Is.True);
        Assert.That(task.CategoryId, Is.EqualTo(0));
    }

    // The trashed tasks and habits may have had reminders and digest entries.
    [Test]
    public async Task DeleteCategory_RebuildsNotificationSchedule()
    {
        TaskModel task = TestData.Task(id: 1, categoryId: 10);
        CategoryModel category = TestData.Category(id: 10, tasks: [task]);
        _clientState.Categories = TestData.CategoryDict(category);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.DeleteCategory(category);

        await _notificationScheduler.Received(1).Rebuild();
    }

    [Test]
    public async Task DeleteCategory_CascadesIsDeleted_AndCategoryId0_ToHabits()
    {
        HabitModel habit = TestData.Habit(id: 1, categoryId: 10);
        CategoryModel category = TestData.Category(id: 10, habits: [habit]);
        _clientState.Categories = TestData.CategoryDict(category);
        _dataAccess.GetHabit(habit.Id).Returns(Task.FromResult<HabitEntity?>(new HabitEntity { Id = habit.Id }));

        await _sut.DeleteCategory(category);

        Assert.That(habit.IsDeleted, Is.True);
        Assert.That(habit.CategoryId, Is.EqualTo(0));
    }

    [Test]
    public async Task DeleteCategory_RemovesFromClientStateDictionary()
    {
        CategoryModel category = TestData.Category(id: 1, title: "ToDelete");
        _clientState.Categories = TestData.CategoryDict(category);

        await _sut.DeleteCategory(category);

        Assert.That(_clientState.Categories, Does.Not.ContainKey(1L));
    }

    [Test]
    public async Task DeleteCategory_RemovesIdFromHiddenCategoryIds_WhenPresent()
    {
        CategoryModel category = TestData.Category(id: 5);
        _clientState.Categories = TestData.CategoryDict(category);
        _clientState.Settings.HiddenCategoryIds.Add(5);

        // UpdateSettings calls GetSettings — mock it
        _dataAccess.GetSettings(_clientState.Settings.Id).Returns(Task.FromResult<SettingsEntity?>(new SettingsEntity { Id = _clientState.Settings.Id }));

        await _sut.DeleteCategory(category);

        Assert.That(_clientState.Settings.HiddenCategoryIds, Does.Not.Contain(5L));
    }

    [Test]
    public async Task DeleteCategory_DoesNotCallUpdateSettings_WhenIdNotInHiddenList()
    {
        CategoryModel category = TestData.Category(id: 5);
        _clientState.Categories = TestData.CategoryDict(category);
        // Id 5 is NOT in HiddenCategoryIds

        await _sut.DeleteCategory(category);

        await _dataAccess.DidNotReceive().UpdateSettings(Arg.Any<SettingsEntity>());
    }

    // --- DeleteCategory TrashedXxx tests ---

    [Test]
    public async Task DeleteCategory_AddsNonDeletedNotes_ToTrashedNotes()
    {
        NoteModel note = TestData.Note(id: 1, categoryId: 10);
        CategoryModel category = TestData.Category(id: 10, notes: [note]);
        _clientState.Categories = TestData.CategoryDict(category);
        _clientState.TrashedNotes = new();
        _dataAccess.GetNote(note.Id).Returns(Task.FromResult<NoteEntity?>(new NoteEntity { Id = note.Id }));

        await _sut.DeleteCategory(category);

        Assert.That(_clientState.TrashedNotes, Contains.Item(note));
    }

    [Test]
    public async Task DeleteCategory_DoesNotAddAlreadyDeletedNotes_ToTrashedNotes()
    {
        NoteModel note = TestData.Note(id: 1, categoryId: 10, isDeleted: true);
        CategoryModel category = TestData.Category(id: 10, notes: [note]);
        _clientState.Categories = TestData.CategoryDict(category);
        _clientState.TrashedNotes = new();
        _dataAccess.GetNote(note.Id).Returns(Task.FromResult<NoteEntity?>(new NoteEntity { Id = note.Id }));

        await _sut.DeleteCategory(category);

        Assert.That(_clientState.TrashedNotes, Is.Empty);
    }

    [Test]
    public async Task DeleteCategory_AddsNonDeletedTasks_ToTrashedTasks()
    {
        TaskModel task = TestData.Task(id: 1, categoryId: 10);
        CategoryModel category = TestData.Category(id: 10, tasks: [task]);
        _clientState.Categories = TestData.CategoryDict(category);
        _clientState.TrashedTasks = new();
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.DeleteCategory(category);

        Assert.That(_clientState.TrashedTasks, Contains.Item(task));
    }

    [Test]
    public async Task DeleteCategory_AddsNonDeletedHabits_ToTrashedHabits()
    {
        HabitModel habit = TestData.Habit(id: 1, categoryId: 10);
        CategoryModel category = TestData.Category(id: 10, habits: [habit]);
        _clientState.Categories = TestData.CategoryDict(category);
        _clientState.TrashedHabits = new();
        _dataAccess.GetHabit(habit.Id).Returns(Task.FromResult<HabitEntity?>(new HabitEntity { Id = habit.Id }));

        await _sut.DeleteCategory(category);

        Assert.That(_clientState.TrashedHabits, Contains.Item(habit));
    }

    // --- GetCategoryTitle null guard test ---

    [Test]
    public void GetCategoryTitle_WhenCategoriesIsNull_ReturnsIdAsString()
    {
        _clientState.Categories = null;

        string result = _sut.GetCategoryTitle(99);

        Assert.That(result, Is.EqualTo("99"));
    }

    // --- AddCategory guard test ---

    [Test]
    public async Task AddCategory_WhenCategoriesIsNull_DoesNothing()
    {
        _clientState.Categories = null;
        _sut.NewCategory = new CategoryModel { Title = "Health" };

        await _sut.AddCategory();

        await _dataAccess.DidNotReceive().AddCategory(Arg.Any<CategoryEntity>());
    }

    // --- UpdateCategory guard test ---

    [Test]
    public async Task UpdateCategory_WhenSelectedCategoryIsNull_DoesNothing()
    {
        _clientState.Categories = [];
        _sut.SelectedCategory = null;

        await _sut.UpdateCategory("New Title");

        await _dataAccess.DidNotReceive().UpdateCategory(Arg.Any<CategoryEntity>());
    }

    // --- ChangeCategory tests ---

    [Test]
    public void ChangeCategory_MovesNote_BetweenCategorySubLists()
    {
        NoteModel note = TestData.Note(id: 1, categoryId: 10);
        CategoryModel oldCategory = TestData.Category(id: 10, notes: [note]);
        CategoryModel newCategory = TestData.Category(id: 20);
        _clientState.Categories = TestData.CategoryDict(oldCategory, newCategory);

        _sut.ChangeCategory(note, 20);

        Assert.That(oldCategory.Notes, Does.Not.Contain(note));
        Assert.That(newCategory.Notes, Contains.Item(note));
        Assert.That(note.CategoryId, Is.EqualTo(20L));
    }

    [Test]
    public void ChangeCategory_MovesTask_BetweenCategorySubLists()
    {
        TaskModel task = TestData.Task(id: 1, categoryId: 10);
        CategoryModel oldCategory = TestData.Category(id: 10, tasks: [task]);
        CategoryModel newCategory = TestData.Category(id: 20);
        _clientState.Categories = TestData.CategoryDict(oldCategory, newCategory);

        _sut.ChangeCategory(task, 20);

        Assert.That(oldCategory.Tasks, Does.Not.Contain(task));
        Assert.That(newCategory.Tasks, Contains.Item(task));
        Assert.That(task.CategoryId, Is.EqualTo(20L));
    }

    [Test]
    public void ChangeCategory_MovesHabit_BetweenCategorySubLists()
    {
        HabitModel habit = TestData.Habit(id: 1, categoryId: 10);
        CategoryModel oldCategory = TestData.Category(id: 10, habits: [habit]);
        CategoryModel newCategory = TestData.Category(id: 20);
        _clientState.Categories = TestData.CategoryDict(oldCategory, newCategory);

        _sut.ChangeCategory(habit, 20);

        Assert.That(oldCategory.Habits, Does.Not.Contain(habit));
        Assert.That(newCategory.Habits, Contains.Item(habit));
        Assert.That(habit.CategoryId, Is.EqualTo(20L));
    }

    [Test]
    public void ChangeCategory_FromUncategorized_AddsToNewCategory()
    {
        NoteModel note = TestData.Note(id: 1, categoryId: 0);
        CategoryModel newCategory = TestData.Category(id: 20);
        _clientState.Categories = TestData.CategoryDict(newCategory);

        _sut.ChangeCategory(note, 20);

        Assert.That(newCategory.Notes, Contains.Item(note));
        Assert.That(note.CategoryId, Is.EqualTo(20L));
    }

    [Test]
    public void ChangeCategory_ToUncategorized_RemovesFromOldCategory()
    {
        NoteModel note = TestData.Note(id: 1, categoryId: 10);
        CategoryModel oldCategory = TestData.Category(id: 10, notes: [note]);
        _clientState.Categories = TestData.CategoryDict(oldCategory);

        _sut.ChangeCategory(note, 0);

        Assert.That(oldCategory.Notes, Does.Not.Contain(note));
        Assert.That(note.CategoryId, Is.EqualTo(0L));
    }

    // --- DeleteCategory SelectedCategoryId tests ---

    [Test]
    public async Task DeleteCategory_WhenSelectedCategoryIdMatchesDeletedId_ClearsSelectedCategoryId()
    {
        CategoryModel category = TestData.Category(id: 5);
        _clientState.Categories = TestData.CategoryDict(category);
        _clientState.Settings.SelectedCategoryId = 5;
        _dataAccess.GetSettings(_clientState.Settings.Id).Returns(Task.FromResult<SettingsEntity?>(new SettingsEntity { Id = _clientState.Settings.Id }));

        await _sut.DeleteCategory(category);

        Assert.That(_clientState.Settings.SelectedCategoryId, Is.Null);
    }

    [Test]
    public async Task DeleteCategory_WhenSelectedCategoryIdDoesNotMatch_DoesNotClearIt()
    {
        CategoryModel category = TestData.Category(id: 5);
        _clientState.Categories = TestData.CategoryDict(category);
        _clientState.Settings.SelectedCategoryId = 99;

        await _sut.DeleteCategory(category);

        Assert.That(_clientState.Settings.SelectedCategoryId, Is.EqualTo(99L));
    }

    // --- ChangeCategory same-id tests ---

    [Test]
    public void ChangeCategory_WhenNewCategoryIdSameAsOld_NoNetChangeToList()
    {
        NoteModel note = TestData.Note(id: 1, categoryId: 10);
        CategoryModel category = TestData.Category(id: 10, notes: [note]);
        _clientState.Categories = TestData.CategoryDict(category);

        _sut.ChangeCategory(note, 10);

        Assert.That(category.Notes, Contains.Item(note));
        Assert.That(note.CategoryId, Is.EqualTo(10L));
    }

    // --- DeleteCategory DataAccess call test ---

    [Test]
    public async Task DeleteCategory_CallsRemoveCategoryOnDataAccess()
    {
        CategoryModel category = TestData.Category(id: 7);
        _clientState.Categories = TestData.CategoryDict(category);

        await _sut.DeleteCategory(category);

        await _dataAccess.Received(1).RemoveCategory(category.Id);
    }

    // --- ChangeCategory old-category-not-in-dict tests ---

    [Test]
    public void ChangeCategory_WhenOldCategoryNotInDict_DoesNotThrow()
    {
        NoteModel note = TestData.Note(id: 1, categoryId: 10);
        CategoryModel newCategory = TestData.Category(id: 20);
        _clientState.Categories = TestData.CategoryDict(newCategory);

        Assert.DoesNotThrow(() => _sut.ChangeCategory(note, 20));

        Assert.That(note.CategoryId, Is.EqualTo(20L));
    }

    // The add form's category select: the model is saved, and added to the category, only by AddNote.
    [Test]
    public void ChangeCategory_OfAnUnsavedModel_DoesNotAddItToTheCategory()
    {
        NoteModel newNote = TestData.Note(id: 0, categoryId: 0);
        CategoryModel category = TestData.Category(id: 20);
        _clientState.Categories = TestData.CategoryDict(category);

        _sut.ChangeCategory(newNote, 20);

        Assert.That(category.Notes, Is.Empty);
        Assert.That(newNote.CategoryId, Is.EqualTo(20L));
    }

    // --- DeleteCategory when only the categories are loaded (the Categories sidebar after a start on /notes) ---

    [Test]
    public async Task DeleteCategory_WhenTasksAndHabitsAreNotLoaded_TrashesThem()
    {
        CategoryModel category = TestData.Category(id: 10);
        _clientState.Categories = TestData.CategoryDict(category);

        _dataAccess.GetCategories().Returns(Task.FromResult<IReadOnlyList<CategoryEntity>>([new CategoryEntity { Id = 10 }]));
        _dataAccess.GetNotes().Returns(Task.FromResult<IReadOnlyList<NoteEntity>>([]));
        _dataAccess.GetTasks().Returns(Task.FromResult<IReadOnlyList<TaskEntity>>([new TaskEntity { Id = 2, CategoryId = 10 }]));
        _dataAccess.GetHabits().Returns(Task.FromResult<IReadOnlyList<HabitEntity>>([new HabitEntity { Id = 3, CategoryId = 10 }]));
        _dataAccess.GetTask(2).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = 2, CategoryId = 10 }));
        _dataAccess.GetHabit(3).Returns(Task.FromResult<HabitEntity?>(new HabitEntity { Id = 3, CategoryId = 10 }));

        await _sut.DeleteCategory(category);

        await _dataAccess.Received(1).UpdateTask(Arg.Is<TaskEntity>(x => x != null && x.Id == 2 && x.IsDeleted && x.CategoryId == 0));
        await _dataAccess.Received(1).UpdateHabit(Arg.Is<HabitEntity>(x => x != null && x.Id == 3 && x.IsDeleted && x.CategoryId == 0));
    }

    [Test]
    public async Task DeleteCategory_StoresTheTrashedNoteWithoutACategoryAndRemovesTheCategory()
    {
        NoteModel note = TestData.Note(id: 1, title: "Kept text", categoryId: 10);
        CategoryModel category = TestData.Category(id: 10, notes: [note]);
        _clientState.Categories = TestData.CategoryDict(category);
        _dataAccess.GetNote(1).Returns(Task.FromResult<NoteEntity?>(new NoteEntity { Id = 1, CategoryId = 10 }));

        await _sut.DeleteCategory(category);

        await _dataAccess.Received(1).UpdateNote(Arg.Is<NoteEntity>(x => x != null && x.Id == 1 && x.IsDeleted && x.CategoryId == 0 && x.Title == "Kept text"));
        await _dataAccess.Received(1).RemoveCategory(10);
    }

    [Test]
    public async Task DeleteCategory_CategoriesNotLoaded_DoesNothing()
    {
        _clientState.Categories = null;

        await _sut.DeleteCategory(TestData.Category(id: 10));

        await _dataAccess.DidNotReceive().RemoveCategory(Arg.Any<long>());
        await _notificationScheduler.DidNotReceive().Rebuild();
    }

    [Test]
    public async Task AddCategory_StoresTheCategoryAndPreparesTheNextOneForTheUser()
    {
        _dataAccess.When(x => x.AddCategory(Arg.Any<CategoryEntity>())).Do(callInfo => callInfo.RequiredArg<CategoryEntity>().Id = 6);
        _clientState.User = new UserModel { Id = 3 };
        _clientState.Categories = new();
        CategoryModel newCategory = new() { Title = "Health", UserId = 3 };
        _sut.NewCategory = newCategory;

        await _sut.AddCategory();

        await _dataAccess.Received(1).AddCategory(Arg.Is<CategoryEntity>(x => x != null && x.Title == "Health" && x.UserId == 3));
        Assert.Multiple(() =>
        {
            Assert.That(newCategory.Id, Is.EqualTo(6));
            Assert.That(_clientState.Categories[6], Is.SameAs(newCategory));
            Assert.That(_sut.NewCategory, Is.Not.SameAs(newCategory));
            Assert.That(_sut.NewCategory!.UserId, Is.EqualTo(3));
        });
    }

    [Test]
    public async Task UpdateCategory_StoresTheNewTitle()
    {
        CategoryModel category = TestData.Category(id: 1, title: "Old Title");
        _clientState.Categories = TestData.CategoryDict(category);
        _sut.SelectedCategory = category;
        _dataAccess.GetCategory(1).Returns(Task.FromResult<CategoryEntity?>(new CategoryEntity { Id = 1, Title = "Old Title" }));

        await _sut.UpdateCategory("New Title");

        await _dataAccess.Received(1).UpdateCategory(Arg.Is<CategoryEntity>(x => x != null && x.Id == 1 && x.Title == "New Title"));
    }

    [Test]
    public async Task Initialize_LoadsTheCategoriesAndPreparesANewCategoryForTheUser()
    {
        _dataAccess.GetCategories().Returns(Task.FromResult<IReadOnlyList<CategoryEntity>>([new CategoryEntity { Id = 4, Title = "Work" }]));
        _clientState.User = new UserModel { Id = 3 };

        await _sut.Initialize();

        Assert.Multiple(() =>
        {
            Assert.That(_sut.Categories!.Select(x => x.Title), Is.EqualTo(new[] { "Work" }));
            Assert.That(_sut.NewCategory!.UserId, Is.EqualTo(3));
            Assert.That(_sut.NewCategory.Title, Is.Empty);
        });
    }

    [Test]
    public async Task Initialize_KeepsANewCategoryAlreadyBeingTyped()
    {
        _dataAccess.GetCategories().Returns(Task.FromResult<IReadOnlyList<CategoryEntity>>([]));
        CategoryModel typing = new() { Title = "Hal" };
        _sut.NewCategory = typing;

        await _sut.Initialize();

        Assert.That(_sut.NewCategory, Is.SameAs(typing));
    }

    [Test]
    public async Task ToggleCollapsed_FlipsTheFlagAndStoresIt()
    {
        CategoryModel category = TestData.Category(id: 2);
        _dataAccess.GetCategory(2).Returns(Task.FromResult<CategoryEntity?>(new CategoryEntity { Id = 2 }));

        await _sut.ToggleCollapsed(category);

        Assert.That(category.IsCollapsed, Is.True);
        await _dataAccess.Received(1).UpdateCategory(Arg.Is<CategoryEntity>(x => x != null && x.IsCollapsed));

        _dataAccess.ClearReceivedCalls();

        await _sut.ToggleCollapsed(category);

        Assert.That(category.IsCollapsed, Is.False);
        await _dataAccess.Received(1).UpdateCategory(Arg.Is<CategoryEntity>(x => x != null && !x.IsCollapsed));
    }

    [Test]
    public async Task ToggleCompletionRule_SwitchesBetweenAllAndAnyAndStoresIt()
    {
        CategoryModel category = TestData.Category(id: 2);
        _dataAccess.GetCategory(2).Returns(Task.FromResult<CategoryEntity?>(new CategoryEntity { Id = 2 }));

        await _sut.ToggleCompletionRule(category);

        Assert.That(category.CompletionRule, Is.EqualTo(CompletionRule.Any));
        await _dataAccess.Received(1).UpdateCategory(Arg.Is<CategoryEntity>(x => x != null && x.CompletionRule == CompletionRule.Any));

        _dataAccess.ClearReceivedCalls();

        await _sut.ToggleCompletionRule(category);

        Assert.That(category.CompletionRule, Is.EqualTo(CompletionRule.All));
        await _dataAccess.Received(1).UpdateCategory(Arg.Is<CategoryEntity>(x => x != null && x.CompletionRule == CompletionRule.All));
    }

    [Test]
    public async Task ToggleCollapsedAndCompletionRule_StoredRowMissing_StillChangeTheModel()
    {
        CategoryModel category = TestData.Category(id: 2);
        _dataAccess.GetCategory(2).Returns(Task.FromResult<CategoryEntity?>(null));

        await _sut.ToggleCollapsed(category);
        await _sut.ToggleCompletionRule(category);

        Assert.Multiple(() =>
        {
            Assert.That(category.IsCollapsed, Is.True);
            Assert.That(category.CompletionRule, Is.EqualTo(CompletionRule.Any));
        });
        await _dataAccess.DidNotReceive().UpdateCategory(Arg.Any<CategoryEntity>());
    }

    [Test]
    public void ChangeCategory_CategoriesNotLoaded_LeavesTheModelAsItIs()
    {
        NoteModel note = TestData.Note(id: 3, categoryId: 1);
        _clientState.Categories = null;

        _sut.ChangeCategory(note, 2);

        Assert.That(note.CategoryId, Is.EqualTo(1));
    }

    [Test]
    public void SetSelectedCategory_CategoriesNotLoaded_KeepsTheSelection()
    {
        CategoryModel selected = TestData.Category(id: 1);
        _sut.SelectedCategory = selected;
        _clientState.Categories = null;

        _sut.SetSelectedCategory(2);

        Assert.That(_sut.SelectedCategory, Is.SameAs(selected));
    }
}
