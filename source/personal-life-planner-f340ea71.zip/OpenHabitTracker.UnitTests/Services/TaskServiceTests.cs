using Markdig;
using NSubstitute;
using OpenHabitTracker.App;
using OpenHabitTracker.Data;
using OpenHabitTracker.Data.Entities;
using OpenHabitTracker.Data.Models;
using OpenHabitTracker.Services;

namespace OpenHabitTracker.UnitTests.Services;

[TestFixture]
public class TaskServiceTests
{
    private IDataAccess _dataAccess = null!;
    private ClientState _clientState = null!;
    private SearchFilterService _searchFilterService = null!;
    private IAppReview _appReview = null!;
    private INotificationScheduler _notificationScheduler = null!;
    private TaskService _sut = null!;

    [SetUp]
    public void SetUp()
    {
        _dataAccess = Substitute.For<IDataAccess>();
        _dataAccess.DataLocation.Returns(DataLocation.Local);
        _dataAccess.GetTimes().Returns(Task.FromResult<IReadOnlyList<TimeEntity>>([]));

        MarkdownPipeline pipeline = new MarkdownPipelineBuilder().UseAdvancedExtensions().Build();
        MarkdownToHtml markdownToHtml = new(pipeline);
        _clientState = new(new[] { _dataAccess }, markdownToHtml);

        // Override dangerous default: HideCompletedTasks = true
        _clientState.Settings = new SettingsModel { HideCompletedTasks = false };

        _searchFilterService = new();
        _appReview = Substitute.For<IAppReview>();
        _notificationScheduler = Substitute.For<INotificationScheduler>();
        _sut = new(_clientState, _searchFilterService, _appReview, _notificationScheduler);
    }

    [TearDown]
    public void TearDown()
    {
        _searchFilterService.SearchTerm = null;
        _searchFilterService.DoneAtFilter = null;
        _searchFilterService.PlannedAtFilter = null;
    }

    // --- GetTasks filter tests ---

    [Test]
    public void GetTasks_NoFilter_ReturnsAllNonDeleted()
    {
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, title: "A"),
            TestData.Task(id: 2, title: "B", isDeleted: true),
            TestData.Task(id: 3, title: "C"));

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L, 3L }));
    }

    [Test]
    public void GetTasks_DeletedTask_IsExcluded()
    {
        _clientState.Tasks = TestData.TaskDict(TestData.Task(id: 1, isDeleted: true));

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result, Is.Empty);
    }

    [Test]
    public void GetTasks_HideCompletedTasks_True_ExcludesTasksWithCompletedAt()
    {
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, completedAt: null),
            TestData.Task(id: 2, completedAt: DateTime.Now));
        _clientState.Settings.HideCompletedTasks = true;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L }));
    }

    [Test]
    public void GetTasks_HideCompletedTasks_False_IncludesCompletedTasks()
    {
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, completedAt: null),
            TestData.Task(id: 2, completedAt: DateTime.Now));
        _clientState.Settings.HideCompletedTasks = false;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L, 2L }));
    }

    [Test]
    public void GetTasks_PriorityFilter_CheckBoxes_ExcludesHiddenPriority()
    {
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, priority: Priority.High),
            TestData.Task(id: 2, priority: Priority.Low));
        _clientState.Settings.PriorityFilterDisplay = FilterDisplay.CheckBoxes;
        _clientState.Settings.ShowPriority[Priority.Low] = false;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L }));
    }

    [Test]
    public void GetTasks_PriorityFilter_Dropdown_ReturnsOnlyMatchingPriority()
    {
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, priority: Priority.High),
            TestData.Task(id: 2, priority: Priority.Low));
        _clientState.Settings.PriorityFilterDisplay = FilterDisplay.SelectOptions;
        _clientState.Settings.SelectedPriority = Priority.High;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L }));
    }

    [Test]
    public void GetTasks_CategoryFilter_CheckBoxes_ExcludesHiddenCategory()
    {
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, categoryId: 10),
            TestData.Task(id: 2, categoryId: 20));
        _clientState.Settings.CategoryFilterDisplay = FilterDisplay.CheckBoxes;
        _clientState.Settings.HiddenCategoryIds.Add(20);

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L }));
    }

    [Test]
    public void GetTasks_CategoryFilter_Dropdown_ReturnsOnlyMatchingCategory()
    {
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, categoryId: 10),
            TestData.Task(id: 2, categoryId: 20));
        _clientState.Settings.CategoryFilterDisplay = FilterDisplay.SelectOptions;
        _clientState.Settings.SelectedCategoryId = 10;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L }));
    }

    [Test]
    public void GetTasks_SearchTerm_MatchesTitle()
    {
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, title: "Buy groceries"),
            TestData.Task(id: 2, title: "Call doctor"));
        _searchFilterService.SearchTerm = "groceries";
        _searchFilterService.MatchCase = false;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L }));
    }

    [Test]
    public void GetTasks_SearchTerm_MatchesItemTitle()
    {
        TaskModel task = TestData.Task(id: 1, title: "Shopping");
        task.Items = [new ItemModel { Id = 10, Title = "Milk" }];
        _clientState.Tasks = TestData.TaskDict(task, TestData.Task(id: 2, title: "Other"));
        _searchFilterService.SearchTerm = "milk";
        _searchFilterService.MatchCase = false;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L }));
    }

    [Test]
    public void GetTasks_DoneAtFilter_Before()
    {
        DateTime filterDate = new(2025, 6, 10);
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, completedAt: new DateTime(2025, 6, 5)),
            TestData.Task(id: 2, completedAt: new DateTime(2025, 6, 15)));

        _searchFilterService.DoneAtFilter = filterDate;
        _searchFilterService.DoneAtCompare = DateCompare.Before;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L }));
    }

    [Test]
    public void GetTasks_DoneAtFilter_On()
    {
        DateTime filterDate = new(2025, 6, 10);
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, completedAt: new DateTime(2025, 6, 10, 9, 0, 0)),
            TestData.Task(id: 2, completedAt: new DateTime(2025, 6, 11)));

        _searchFilterService.DoneAtFilter = filterDate;
        _searchFilterService.DoneAtCompare = DateCompare.On;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L }));
    }

    [Test]
    public void GetTasks_DoneAtFilter_After()
    {
        DateTime filterDate = new(2025, 6, 10);
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, completedAt: new DateTime(2025, 6, 15)),
            TestData.Task(id: 2, completedAt: new DateTime(2025, 6, 5)));

        _searchFilterService.DoneAtFilter = filterDate;
        _searchFilterService.DoneAtCompare = DateCompare.After;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L }));
    }

    [Test]
    public void GetTasks_DoneAtFilter_NotOn()
    {
        DateTime filterDate = new(2025, 6, 10);
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, completedAt: new DateTime(2025, 6, 10)),
            TestData.Task(id: 2, completedAt: new DateTime(2025, 6, 11)),
            TestData.Task(id: 3, completedAt: null));

        _searchFilterService.DoneAtFilter = filterDate;
        _searchFilterService.DoneAtCompare = DateCompare.NotOn;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        // NotOn: CompletedAt?.Date != filterDate — null != date is true, so task 3 is included
        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 2L, 3L }));
    }

    [Test]
    public void GetTasks_PlannedAtFilter_Before()
    {
        DateTime filterDate = new(2025, 6, 10);
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, plannedAt: new DateTime(2025, 6, 5)),
            TestData.Task(id: 2, plannedAt: new DateTime(2025, 6, 15)));

        _searchFilterService.PlannedAtFilter = filterDate;
        _searchFilterService.PlannedAtCompare = DateCompare.Before;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L }));
    }

    [Test]
    public void GetTasks_PlannedAtFilter_On()
    {
        DateTime filterDate = new(2025, 6, 10);
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, plannedAt: new DateTime(2025, 6, 10, 8, 0, 0)),
            TestData.Task(id: 2, plannedAt: new DateTime(2025, 6, 11)));

        _searchFilterService.PlannedAtFilter = filterDate;
        _searchFilterService.PlannedAtCompare = DateCompare.On;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L }));
    }

    [Test]
    public void GetTasks_PlannedAtFilter_After()
    {
        DateTime filterDate = new(2025, 6, 10);
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, plannedAt: new DateTime(2025, 6, 15)),
            TestData.Task(id: 2, plannedAt: new DateTime(2025, 6, 5)));

        _searchFilterService.PlannedAtFilter = filterDate;
        _searchFilterService.PlannedAtCompare = DateCompare.After;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 1L }));
    }

    [Test]
    public void GetTasks_PlannedAtFilter_NotOn()
    {
        DateTime filterDate = new(2025, 6, 10);
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, plannedAt: new DateTime(2025, 6, 10)),
            TestData.Task(id: 2, plannedAt: new DateTime(2025, 6, 11)));

        _searchFilterService.PlannedAtFilter = filterDate;
        _searchFilterService.PlannedAtCompare = DateCompare.NotOn;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        Assert.That(result.Select(t => t.Id), Is.EquivalentTo(new[] { 2L }));
    }

    [Test]
    public void GetTasks_SortByTitle_ReturnsAlphabetically()
    {
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, title: "Zzz"),
            TestData.Task(id: 2, title: "Aaa"),
            TestData.Task(id: 3, title: "Mmm"));
        _clientState.Settings.SortBy[ContentType.Task] = Sort.Title;

        List<TaskModel> result = _sut.GetTasks().ToList();

        Assert.That(result.Select(t => t.Title), Is.EqualTo(new[] { "Aaa", "Mmm", "Zzz" }));
    }

    [Test]
    public void GetTasks_SortByPlannedAt_ReturnsEarliestFirst()
    {
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, plannedAt: new DateTime(2025, 6, 15)),
            TestData.Task(id: 2, plannedAt: new DateTime(2025, 6, 1)),
            TestData.Task(id: 3, plannedAt: new DateTime(2025, 6, 10)));
        _clientState.Settings.SortBy[ContentType.Task] = Sort.PlannedAt;

        List<TaskModel> result = _sut.GetTasks().ToList();

        Assert.That(result[0].Id, Is.EqualTo(2L));
        Assert.That(result[1].Id, Is.EqualTo(3L));
        Assert.That(result[2].Id, Is.EqualTo(1L));
    }

    // --- AddTask tests ---

    [Test]
    public async Task AddTask_SetsTimestamps_AndAddsToClientState()
    {
        _clientState.Tasks = new();
        _sut.NewTask = new TaskModel { Title = "New Task" };

        DateTime before = DateTime.Now;
        await _sut.AddTask();
        DateTime after = DateTime.Now;

        Assert.That(_clientState.Tasks, Has.Count.EqualTo(1));
        TaskModel added = _clientState.Tasks.Values.Single();
        Assert.That(added.CreatedAt, Is.InRange(before, after));
        Assert.That(added.UpdatedAt, Is.InRange(before, after));
    }

    // --- DeleteTask tests ---

    [Test]
    public async Task DeleteTask_SetsIsDeletedTrue_AndAddsToTrash()
    {
        TaskModel task = TestData.Task(id: 1);
        _clientState.Tasks = TestData.TaskDict(task);
        _clientState.TrashedTasks = [];
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.DeleteTask(task);

        Assert.That(task.IsDeleted, Is.True);
        Assert.That(_clientState.TrashedTasks, Has.Count.EqualTo(1));
    }

    // --- UpdateTask tests ---

    [Test]
    public async Task UpdateTask_UpdatesEntityInDataAccess()
    {
        TaskModel task = TestData.Task(id: 1, title: "Old");
        _clientState.Tasks = TestData.TaskDict(task);
        _sut.SelectedTask = task;
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.UpdateTask();

        await _dataAccess.Received(1).UpdateTask(Arg.Is<TaskEntity>(e => e != null && e.Id == task.Id));
    }

    // The data access stamps UpdatedAt on the entity; the model shows it.
    [Test]
    public async Task UpdateTask_SetsUpdatedAtFromTheStoredEntity()
    {
        TaskModel task = TestData.Task(id: 1);
        task.UpdatedAt = DateTime.Now.AddDays(-10);
        _clientState.Tasks = TestData.TaskDict(task);
        _sut.SelectedTask = task;
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        DateTime stamped = DateTime.Now;
        _dataAccess.When(x => x.UpdateTask(Arg.Any<TaskEntity>())).Do(callInfo => callInfo.RequiredArg<TaskEntity>().UpdatedAt = stamped);

        await _sut.UpdateTask();

        Assert.That(task.UpdatedAt, Is.EqualTo(stamped));
    }

    // --- SetSelectedTask tests ---

    [Test]
    public void SetSelectedTask_WhenIdExists_SetsSelectedTask()
    {
        TaskModel task = TestData.Task(id: 5);
        _clientState.Tasks = TestData.TaskDict(task);

        _sut.SetSelectedTask(5);

        Assert.That(_sut.SelectedTask, Is.SameAs(task));
    }

    [Test]
    public void SetSelectedTask_WhenIdIsNull_ClearsSelectedTask()
    {
        TaskModel task = TestData.Task(id: 5);
        _clientState.Tasks = TestData.TaskDict(task);
        _sut.SelectedTask = task;

        _sut.SetSelectedTask(null);

        Assert.That(_sut.SelectedTask, Is.Null);
    }

    [Test]
    public void SetSelectedTask_WhenIdDoesNotExist_SetsSelectedTaskToNull()
    {
        _clientState.Tasks = TestData.TaskDict(TestData.Task(id: 1));

        _sut.SetSelectedTask(99);

        Assert.That(_sut.SelectedTask, Is.Null);
    }

    [Test]
    public void SetSelectedTask_WhenTaskSelected_ClearsNewTask()
    {
        TaskModel task = TestData.Task(id: 5);
        _clientState.Tasks = TestData.TaskDict(task);
        _sut.NewTask = new TaskModel { Title = "draft" };

        _sut.SetSelectedTask(5);

        Assert.That(_sut.NewTask, Is.Null);
    }

    // --- AddTask additional tests ---

    [Test]
    public async Task AddTask_WhenNewTaskIsNull_DoesNothing()
    {
        _clientState.Tasks = new();
        _sut.NewTask = null;

        await _sut.AddTask();

        Assert.That(_clientState.Tasks, Is.Empty);
    }

    // ChangeCategory only sets CategoryId on an unsaved task, so AddTask adds it to its category list.
    [Test]
    public async Task AddTask_WithNonZeroCategoryId_AddsToCategory()
    {
        CategoryModel category = TestData.Category(id: 10);
        _clientState.Categories = TestData.CategoryDict(category);
        _clientState.Tasks = new();
        TaskModel newTask = new() { Title = "Project Task", CategoryId = 10 };
        _sut.NewTask = newTask;

        await _sut.AddTask();

        Assert.That(category.Tasks, Is.EqualTo(new[] { newTask }));
    }

    // --- DeleteTask additional tests ---

    [Test]
    public void DeleteTask_WhenTrashedTasksIsNull_DoesNotThrow()
    {
        TaskModel task = TestData.Task(id: 1);
        _clientState.Tasks = TestData.TaskDict(task);
        _clientState.TrashedTasks = null;
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        Assert.DoesNotThrowAsync(() => _sut.DeleteTask(task));
    }

    // --- Start tests ---

    [Test]
    public async Task Start_SetsStartedAt_AndClearsCompletedAt()
    {
        TaskModel task = TestData.Task(id: 1, completedAt: DateTime.Now.AddHours(-1));
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        DateTime before = DateTime.Now;
        await _sut.Start(task);
        DateTime after = DateTime.Now;

        Assert.That(task.StartedAt, Is.InRange(before, after));
        Assert.That(task.CompletedAt, Is.Null);
    }

    // A completed task is announced by nothing, so starting it again makes it due again, as marking it not done does.
    [Test]
    public async Task Start_CompletedTask_RebuildsTheNotificationSchedule()
    {
        TaskModel task = TestData.Task(id: 1, completedAt: DateTime.Now.AddHours(-1));
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.Start(task);

        await _notificationScheduler.Received(1).Rebuild();
    }

    // The schedule reads only the completion, which an open task does not have.
    [Test]
    public async Task Start_OpenTask_LeavesTheNotificationScheduleAlone()
    {
        TaskModel task = TestData.Task(id: 1);
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.Start(task);

        await _notificationScheduler.DidNotReceive().Rebuild();
    }

    // --- SetStartTime tests ---

    [Test]
    public async Task SetStartTime_WhenTaskAlreadyCompleted_DoesNothing()
    {
        TaskModel task = TestData.Task(id: 1, completedAt: DateTime.Now.AddMinutes(-5));
        task.StartedAt = DateTime.Now.AddMinutes(-10);
        _clientState.Tasks = TestData.TaskDict(task);

        DateTime original = task.StartedAt!.Value;
        await _sut.SetStartTime(task, DateTime.Now.AddMinutes(-20));

        Assert.That(task.StartedAt, Is.EqualTo(original));
    }

    [Test]
    public async Task SetStartTime_WhenTaskInProgress_UpdatesStartedAt()
    {
        TaskModel task = TestData.Task(id: 1);
        task.StartedAt = DateTime.Now.AddHours(-1);
        task.CompletedAt = null;
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        DateTime newStart = DateTime.Now.AddHours(-2);
        await _sut.SetStartTime(task, newStart);

        Assert.That(task.StartedAt, Is.EqualTo(newStart));
    }

    // --- MarkAsDone tests ---

    [Test]
    public async Task MarkAsDone_WhenNotDone_SetsCompletedAt()
    {
        TaskModel task = TestData.Task(id: 1, completedAt: null);
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        DateTime before = DateTime.Now;
        await _sut.MarkAsDone(task);
        DateTime after = DateTime.Now;

        Assert.That(task.CompletedAt, Is.InRange(before, after));
    }

    [Test]
    public async Task MarkAsDone_WhenAlreadyDone_ClearsCompletedAt()
    {
        TaskModel task = TestData.Task(id: 1, completedAt: DateTime.Now.AddMinutes(-5));
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.MarkAsDone(task);

        Assert.That(task.CompletedAt, Is.Null);
    }

    [Test]
    public async Task MarkAsDone_WhenNotDoneAndNoStartedAt_SetsStartedAt()
    {
        TaskModel task = TestData.Task(id: 1, completedAt: null);
        task.StartedAt = null;
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        DateTime before = DateTime.Now;
        await _sut.MarkAsDone(task);
        DateTime after = DateTime.Now;

        Assert.That(task.StartedAt, Is.InRange(before, after));
    }

    [Test]
    public async Task MarkAsDone_WhenNotDone_SetsAllItemsDoneAt()
    {
        TaskModel task = TestData.Task(id: 1, completedAt: null);
        ItemModel item1 = new() { Id = 10, Title = "Step 1" };
        ItemModel item2 = new() { Id = 11, Title = "Step 2" };
        task.Items = [item1, item2];
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));
        _dataAccess.GetItem(item1.Id).Returns(Task.FromResult<ItemEntity?>(new ItemEntity { Id = item1.Id }));
        _dataAccess.GetItem(item2.Id).Returns(Task.FromResult<ItemEntity?>(new ItemEntity { Id = item2.Id }));

        await _sut.MarkAsDone(task);

        Assert.That(item1.DoneAt, Is.Not.Null);
        Assert.That(item2.DoneAt, Is.Not.Null);
    }

    // --- MarkAsDone additional tests ---

    [Test]
    public async Task MarkAsDone_WhenAlreadyDone_ClearsStartedAt()
    {
        TaskModel task = TestData.Task(id: 1, completedAt: DateTime.Now.AddMinutes(-5));
        task.StartedAt = DateTime.Now.AddMinutes(-10);
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.MarkAsDone(task);

        Assert.That(task.StartedAt, Is.Null);
    }

    [Test]
    public async Task MarkAsDone_WhenAlreadyDone_LeavesTheItemsAsTheyAre()
    {
        DateTime tickedAt = DateTime.Now.AddMinutes(-5);
        TaskModel task = TestData.Task(id: 1, completedAt: DateTime.Now.AddMinutes(-5));
        ItemModel item1 = new() { Id = 10, DoneAt = tickedAt };
        ItemModel item2 = new() { Id = 11, DoneAt = tickedAt };
        task.Items = [item1, item2];
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.MarkAsDone(task);

        Assert.Multiple(() =>
        {
            Assert.That(item1.DoneAt, Is.EqualTo(tickedAt));
            Assert.That(item2.DoneAt, Is.EqualTo(tickedAt));
        });
        await _dataAccess.DidNotReceive().UpdateItem(Arg.Any<ItemEntity>());
    }

    [Test]
    public async Task MarkAsDone_WhenNotDone_WithExistingStartedAt_PreservesStartedAt()
    {
        DateTime existingStartedAt = DateTime.Now.AddHours(-2);
        TaskModel task = TestData.Task(id: 1, completedAt: null);
        task.StartedAt = existingStartedAt;
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.MarkAsDone(task);

        Assert.That(task.StartedAt, Is.EqualTo(existingStartedAt));
    }

    // --- SetStartTime guard test ---

    [Test]
    public async Task SetStartTime_WhenTaskNotYetStarted_DoesNothing()
    {
        TaskModel task = TestData.Task(id: 1);
        task.StartedAt = null;
        task.CompletedAt = null;
        _clientState.Tasks = TestData.TaskDict(task);

        await _sut.SetStartTime(task, DateTime.Now.AddHours(-1));

        await _dataAccess.DidNotReceive().UpdateTask(Arg.Any<TaskEntity>());
    }

    // --- UpdateTask when entity not found ---

    [Test]
    public async Task UpdateTask_WhenGetTaskReturnsNull_DoesNotCallUpdateTask()
    {
        TaskModel task = TestData.Task(id: 1);
        _clientState.Tasks = TestData.TaskDict(task);
        _sut.SelectedTask = task;
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(null));

        await _sut.UpdateTask();

        await _dataAccess.DidNotReceive().UpdateTask(Arg.Any<TaskEntity>());
    }

    // --- GetTasks sort tests ---

    [Test]
    public void GetTasks_SortByPriority_ReturnsHighestFirst()
    {
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, priority: Priority.Low),
            TestData.Task(id: 2, priority: Priority.VeryHigh),
            TestData.Task(id: 3, priority: Priority.Medium));
        _clientState.Settings.SortBy[ContentType.Task] = Sort.Priority;

        List<TaskModel> result = _sut.GetTasks().ToList();

        Assert.That(result[0].Priority, Is.EqualTo(Priority.VeryHigh));
        Assert.That(result[1].Priority, Is.EqualTo(Priority.Medium));
        Assert.That(result[2].Priority, Is.EqualTo(Priority.Low));
    }

    [Test]
    public void GetTasks_SortByCategory_ReturnsByCategory()
    {
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, categoryId: 30),
            TestData.Task(id: 2, categoryId: 10),
            TestData.Task(id: 3, categoryId: 20));
        _clientState.Settings.SortBy[ContentType.Task] = Sort.Category;

        List<TaskModel> result = _sut.GetTasks().ToList();

        Assert.That(result.Select(t => t.CategoryId), Is.EqualTo(new[] { 10L, 20L, 30L }));
    }

    [Test]
    public void GetTasks_SortByDuration_ReturnsShortestFirst()
    {
        TaskModel taskShort = TestData.Task(id: 1);
        taskShort.Duration = new TimeOnly(0, 30, 0); // 30 min
        TaskModel taskLong = TestData.Task(id: 2);
        taskLong.Duration = new TimeOnly(2, 0, 0); // 2 hours
        _clientState.Tasks = TestData.TaskDict(taskLong, taskShort);
        _clientState.Settings.SortBy[ContentType.Task] = Sort.Duration;

        List<TaskModel> result = _sut.GetTasks().ToList();

        Assert.That(result[0].Id, Is.EqualTo(1L));
        Assert.That(result[1].Id, Is.EqualTo(2L));
    }

    [Test]
    public void GetTasks_SortByElapsedTime_ReturnsEarliestCompletedAtFirst()
    {
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, completedAt: new DateTime(2025, 6, 1)),
            TestData.Task(id: 2, completedAt: new DateTime(2025, 1, 1)));
        _clientState.Settings.SortBy[ContentType.Task] = Sort.ElapsedTime;

        List<TaskModel> result = _sut.GetTasks().ToList();

        Assert.That(result[0].Id, Is.EqualTo(2L));
        Assert.That(result[1].Id, Is.EqualTo(1L));
    }

    [Test]
    public void GetTasks_SortByTimeSpent_ReturnsLeastFirst()
    {
        TaskModel taskShort = TestData.Task(id: 1);
        taskShort.StartedAt = new DateTime(2025, 1, 1, 8, 0, 0);
        taskShort.CompletedAt = new DateTime(2025, 1, 1, 9, 0, 0); // 1 hour
        TaskModel taskLong = TestData.Task(id: 2);
        taskLong.StartedAt = new DateTime(2025, 1, 1, 8, 0, 0);
        taskLong.CompletedAt = new DateTime(2025, 1, 1, 11, 0, 0); // 3 hours
        _clientState.Tasks = TestData.TaskDict(taskLong, taskShort);
        _clientState.Settings.SortBy[ContentType.Task] = Sort.TimeSpent;

        List<TaskModel> result = _sut.GetTasks().ToList();

        Assert.That(result[0].Id, Is.EqualTo(1L));
        Assert.That(result[1].Id, Is.EqualTo(2L));
    }

    // --- PlannedAtFilter NotOn with null PlannedAt ---

    [Test]
    public void GetTasks_PlannedAtFilter_NotOn_WhenPlannedAtIsNull_IncludesTask()
    {
        DateTime filterDate = new(2025, 6, 10);
        _clientState.Tasks = TestData.TaskDict(
            TestData.Task(id: 1, plannedAt: null),
            TestData.Task(id: 2, plannedAt: new DateTime(2025, 6, 10)));

        _searchFilterService.PlannedAtFilter = filterDate;
        _searchFilterService.PlannedAtCompare = DateCompare.NotOn;

        IEnumerable<TaskModel> result = _sut.GetTasks();

        // NotOn: PlannedAt?.Date != filterDate — null != date is true, so task 1 is included
        Assert.That(result.Select(t => t.Id), Contains.Item(1L));
        Assert.That(result.Select(t => t.Id), Does.Not.Contain(2L));
    }

    // --- MarkAsDone with null Items ---

    [Test]
    public async Task MarkAsDone_WhenItemsIsNull_TaskIsMarkedDone()
    {
        TaskModel task = TestData.Task(id: 1, completedAt: null);
        task.Items = null;
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.MarkAsDone(task);

        Assert.That(task.CompletedAt, Is.Not.Null);
    }

    // --- AddTask with CategoryId=0 ---

    [Test]
    public async Task AddTask_WithCategoryId0_DoesNotAddToAnyCategory()
    {
        CategoryModel category = TestData.Category(id: 10);
        _clientState.Categories = TestData.CategoryDict(category);
        _clientState.Tasks = new();
        _sut.NewTask = new TaskModel { Title = "Uncategorized", CategoryId = 0 };

        await _sut.AddTask();

        Assert.That(category.Tasks, Is.Empty);
    }

    // --- DeleteTask soft-delete design ---

    [Test]
    public async Task DeleteTask_DoesNotRemoveFromCategoryTasks()
    {
        TaskModel task = TestData.Task(id: 1, categoryId: 10);
        CategoryModel category = TestData.Category(id: 10, tasks: [task]);
        _clientState.Categories = TestData.CategoryDict(category);
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.DeleteTask(task);

        Assert.That(category.Tasks, Contains.Item(task));
    }

    // --- GetTasks null guard ---

    [Test]
    public void GetTasks_WhenTasksIsNull_ThrowsArgumentNullException()
    {
        _clientState.Tasks = null;

        Assert.Throws<ArgumentNullException>(() => _sut.GetTasks().ToList());
    }

    // --- IAppReview engagement tests ---
    // MarkAsDone toggles - only the transition to done may count (review prompt trigger)

    [Test]
    public async Task MarkAsDone_WhenNotCompleted_RecordsExactlyOneCompletedEngagement()
    {
        TaskModel task = TestData.Task(id: 1);
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.MarkAsDone(task);

        await _appReview.Received(1).RecordEngagement(EngagementKind.Completed);
        await _appReview.Received(1).RecordEngagement(Arg.Any<EngagementKind>());
    }

    [Test]
    public async Task MarkAsDone_WhenAlreadyCompleted_RecordsNoEngagement()
    {
        TaskModel task = TestData.Task(id: 1, completedAt: DateTime.Now.AddHours(-1));
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(task.Id).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = task.Id }));

        await _sut.MarkAsDone(task); // un-done is not an engagement

        await _appReview.DidNotReceive().RecordEngagement(Arg.Any<EngagementKind>());
    }

    [Test]
    public async Task AddTask_RecordsOneContentCreatedEngagement()
    {
        _clientState.Tasks = new();
        _sut.NewTask = new TaskModel { Title = "New Task" };

        await _sut.AddTask();

        await _appReview.Received(1).RecordEngagement(EngagementKind.ContentCreated);
    }

    // A new task can carry a planned time from the moment it is added.
    [Test]
    public async Task AddTask_RebuildsNotificationSchedule()
    {
        _clientState.Tasks = new();
        _sut.NewTask = new TaskModel { Title = "New Task", PlannedAt = DateTime.Now.AddHours(1) };

        await _sut.AddTask();

        await _notificationScheduler.Received(1).Rebuild();
    }

    private static readonly DateTime _planned = new(2026, 3, 10, 9, 30, 0);

    [Test]
    public async Task AddTask_StoresTheTaskAndTakesItsId()
    {
        _dataAccess.When(x => x.AddTask(Arg.Any<TaskEntity>())).Do(callInfo => callInfo.RequiredArg<TaskEntity>().Id = 12);
        _clientState.Tasks = new();
        TaskModel newTask = new() { Title = "Pack", PlannedAt = _planned, Priority = Priority.High };
        _sut.NewTask = newTask;

        await _sut.AddTask();

        await _dataAccess.Received(1).AddTask(Arg.Is<TaskEntity>(x => x != null && x.Title == "Pack" && x.PlannedAt == _planned && x.Priority == Priority.High));
        Assert.Multiple(() =>
        {
            Assert.That(newTask.Id, Is.EqualTo(12));
            Assert.That(_clientState.Tasks[12], Is.SameAs(newTask));
            Assert.That(_sut.NewTask, Is.Null);
        });
    }

    [Test]
    public async Task UpdateTask_CopiesTheEditedFieldsToTheStoredEntityAndRebuilds()
    {
        TaskModel task = TestData.Task(id: 1, title: "Old");
        _clientState.Tasks = TestData.TaskDict(task);
        _sut.SelectedTask = task;
        _dataAccess.GetTask(1).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = 1, Title = "Old" }));

        task.Title = "New";
        task.PlannedAt = _planned;
        task.Duration = new TimeOnly(0, 45);

        await _sut.UpdateTask();

        await _dataAccess.Received(1).UpdateTask(Arg.Is<TaskEntity>(x => x != null && x.Title == "New" && x.PlannedAt == _planned && x.Duration == new TimeOnly(0, 45)));
        await _notificationScheduler.Received(1).Rebuild();
    }

    [Test]
    public async Task UpdateTask_NothingSelected_WritesNothing()
    {
        _clientState.Tasks = TestData.TaskDict(TestData.Task(id: 1));
        _sut.SelectedTask = null;

        await _sut.UpdateTask();

        await _dataAccess.DidNotReceive().GetTask(Arg.Any<long>());
        await _notificationScheduler.DidNotReceive().Rebuild();
    }

    [Test]
    public async Task MarkAsDone_NotDone_StoresTheStartAndTheCompletion()
    {
        TaskModel task = TestData.Task(id: 1);
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(1).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = 1 }));

        await _sut.MarkAsDone(task);

        DateTime completedAt = task.CompletedAt!.Value;

        Assert.That(task.StartedAt, Is.EqualTo(completedAt));
        await _dataAccess.Received(1).UpdateTask(Arg.Is<TaskEntity>(x => x != null && x.StartedAt == completedAt && x.CompletedAt == completedAt));
        await _notificationScheduler.Received(1).Rebuild();
    }

    [Test]
    public async Task MarkAsDone_NotDoneWithDuration_StartsTheDurationBeforeTheCompletionWithinTheDay()
    {
        TaskModel task = TestData.Task(id: 1);
        task.Duration = new TimeOnly(0, 30);
        _clientState.Tasks = TestData.TaskDict(task);

        await _sut.MarkAsDone(task);

        DateTime completedAt = task.CompletedAt!.Value;
        DateTime durationBefore = completedAt.AddMinutes(-30);

        // in the first half hour after midnight the start is clamped to midnight
        DateTime expected = durationBefore < completedAt.Date ? completedAt.Date : durationBefore;

        Assert.That(task.StartedAt, Is.EqualTo(expected));
    }

    [Test]
    public async Task MarkAsDone_Done_StoresTheClearedStartAndCompletionAndRebuilds()
    {
        TaskModel task = TestData.Task(id: 1, completedAt: _planned);
        task.StartedAt = _planned.AddMinutes(-10);
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(1).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = 1, StartedAt = _planned.AddMinutes(-10), CompletedAt = _planned }));

        await _sut.MarkAsDone(task);

        await _dataAccess.Received(1).UpdateTask(Arg.Is<TaskEntity>(x => x != null && x.StartedAt == null && x.CompletedAt == null));
        await _notificationScheduler.Received(1).Rebuild();
    }

    [Test]
    public async Task MarkAsDone_NotDone_TicksEveryItemAtTheCompletionTimeAndStoresIt()
    {
        TaskModel task = TestData.Task(id: 1);
        ItemModel ticked = new() { Id = 10, DoneAt = _planned };
        ItemModel open = new() { Id = 11 };
        task.Items = [ticked, open];
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetItem(10).Returns(Task.FromResult<ItemEntity?>(new ItemEntity { Id = 10, DoneAt = _planned }));
        _dataAccess.GetItem(11).Returns(Task.FromResult<ItemEntity?>(new ItemEntity { Id = 11 }));

        await _sut.MarkAsDone(task);

        DateTime completedAt = task.CompletedAt!.Value;

        Assert.Multiple(() =>
        {
            Assert.That(ticked.DoneAt, Is.EqualTo(completedAt));
            Assert.That(open.DoneAt, Is.EqualTo(completedAt));
        });
        await _dataAccess.Received(2).UpdateItem(Arg.Is<ItemEntity>(x => x != null && x.DoneAt == completedAt));
    }

    [Test]
    public async Task Start_StoresTheNewStartAndTheClearedCompletion()
    {
        TaskModel task = TestData.Task(id: 1, completedAt: _planned);
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(1).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = 1, CompletedAt = _planned }));

        await _sut.Start(task);

        DateTime startedAt = task.StartedAt!.Value;

        await _dataAccess.Received(1).UpdateTask(Arg.Is<TaskEntity>(x => x != null && x.StartedAt == startedAt && x.CompletedAt == null));
    }

    [Test]
    public async Task Start_TasksNotLoaded_ChangesNothing()
    {
        TaskModel task = TestData.Task(id: 1, completedAt: _planned);
        _clientState.Tasks = null;

        await _sut.Start(task);

        Assert.Multiple(() =>
        {
            Assert.That(task.StartedAt, Is.Null);
            Assert.That(task.CompletedAt, Is.EqualTo(_planned));
        });
    }

    [Test]
    public async Task SetStartTime_TaskInProgress_StoresTheNewStart()
    {
        TaskModel task = TestData.Task(id: 1);
        task.StartedAt = _planned;
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(1).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = 1, StartedAt = _planned }));

        await _sut.SetStartTime(task, _planned.AddHours(-1));

        await _dataAccess.Received(1).UpdateTask(Arg.Is<TaskEntity>(x => x != null && x.StartedAt == _planned.AddHours(-1)));
    }

    [Test]
    public async Task DeleteTask_StoresTheDeletedFlagAndRebuilds()
    {
        TaskModel task = TestData.Task(id: 1);
        _clientState.Tasks = TestData.TaskDict(task);
        _dataAccess.GetTask(1).Returns(Task.FromResult<TaskEntity?>(new TaskEntity { Id = 1 }));

        await _sut.DeleteTask(task);

        await _dataAccess.Received(1).UpdateTask(Arg.Is<TaskEntity>(x => x != null && x.Id == 1 && x.IsDeleted));
        await _notificationScheduler.Received(1).Rebuild();
    }

    [Test]
    public async Task Initialize_LoadsTheCategoriesAndTheTasks()
    {
        _dataAccess.GetCategories().Returns(Task.FromResult<IReadOnlyList<CategoryEntity>>([new CategoryEntity { Id = 2, Title = "Home" }]));
        _dataAccess.GetTasks().Returns(Task.FromResult<IReadOnlyList<TaskEntity>>([new TaskEntity { Id = 3, CategoryId = 2, Title = "Clean" }]));

        await _sut.Initialize();

        Assert.Multiple(() =>
        {
            Assert.That(_sut.Tasks!.Select(x => x.Title), Is.EqualTo(new[] { "Clean" }));
            Assert.That(_clientState.Categories![2].Tasks.Select(x => x.Title), Is.EqualTo(new[] { "Clean" }));
        });
    }

    [Test]
    public void SetSelectedTask_TasksNotLoaded_KeepsTheSelection()
    {
        TaskModel selected = TestData.Task(id: 1);
        _sut.SelectedTask = selected;
        _clientState.Tasks = null;

        _sut.SetSelectedTask(2);

        Assert.That(_sut.SelectedTask, Is.SameAs(selected));
    }
}
