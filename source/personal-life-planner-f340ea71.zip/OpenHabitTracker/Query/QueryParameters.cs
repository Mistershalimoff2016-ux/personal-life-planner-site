using OpenHabitTracker.Data;

namespace OpenHabitTracker.Query;

public class QueryParameters
{
    public string? SearchTerm { get; set; }

    public bool MatchCase { get; set; }

    public DateTime? DoneAtFilter { get; set; }

    public DateCompare DoneAtCompare { get; set; } = DateCompare.On;

    public DateTime? PlannedAtFilter { get; set; }

    public DateCompare PlannedAtCompare { get; set; } = DateCompare.On;

    public DateTime? PlannedRangeStart { get; set; }

    public DateTime? PlannedRangeEnd { get; set; }

    public DateTime? DoneRangeStart { get; set; }

    public DateTime? DoneRangeEnd { get; set; }

    public bool ShowDoneInRange { get; set; }

    public bool HideCompletedTasks { get; set; }

    public bool ShowOnlyOverSelectedRatioMin { get; set; }

    public bool ShowOnlyUnderSelectedRatioMax { get; set; }

    public int SelectedRatioMin { get; set; } = 50;

    public int SelectedRatioMax { get; set; } = 150;

    public Ratio SelectedRatio { get; set; }

    public FilterDisplay CategoryFilterDisplay { get; set; } = FilterDisplay.CheckBoxes;

    public FilterDisplay PriorityFilterDisplay { get; set; } = FilterDisplay.CheckBoxes;

    public long? SelectedCategoryId { get; set; }

    public Priority? SelectedPriority { get; set; }

    public List<long> HiddenCategoryIds { get; set; } = [];

    public Dictionary<Priority, bool> ShowPriority { get; set; } = new()
    {
        { Priority.None, true },
        { Priority.VeryLow, true },
        { Priority.Low, true },
        { Priority.Medium, true },
        { Priority.High, true },
        { Priority.VeryHigh, true }
    };

    public Dictionary<ContentType, Sort> SortBy { get; set; } = new()
    {
        { ContentType.Note, Sort.Priority },
        { ContentType.Task, Sort.PlannedAt },
        { ContentType.Habit, Sort.SelectedRatio }
    };
}
