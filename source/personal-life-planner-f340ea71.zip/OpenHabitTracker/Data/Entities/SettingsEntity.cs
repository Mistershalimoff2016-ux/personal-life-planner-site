namespace OpenHabitTracker.Data.Entities;

public class SettingsEntity : IUserScopedEntity
{
    public long Id { get; set; }

    public long UserId { get; set; }

    public bool IsDarkMode { get; set; } = true;

    public string Theme { get; set; } = "default";

    public string StartPage { get; set; } = string.Empty;

    public string StartSidebar { get; set; } = string.Empty;

    public string Culture { get; set; } = "en";

    public DayOfWeek FirstDayOfWeek { get; set; } = DayOfWeek.Monday;

    public string? DateFormat { get; set; }

    public string? TimeFormat { get; set; }

    public Ratio SelectedRatio { get; set; }

    public string BaseUrl { get; set; } = string.Empty;

    public string Username { get; set; } = string.Empty;

    public string RefreshToken { get; set; } = string.Empty;

    public bool RememberMe { get; set; } = true;

    public bool ShowHelp { get; set; } = true;

    public bool UncheckAllItemsOnHabitDone { get; set; } = false;

    public bool ShowPriorityDropdown { get; set; } = true;

    public bool ShowItemList { get; set; } = true;

    public bool ShowSmallCalendar { get; set; } = true;

    public int MaxSmallCalendarDays { get; set; } = 0;

    public bool ShowLargeCalendar { get; set; } = true;

    public bool ShowHabitStatistics { get; set; } = false;

    public bool ShowHabitCharts { get; set; } = false;

    public bool ShowCategory { get; set; } = true;

    public bool ShowColor { get; set; } = true;

    public bool ShowCreatedUpdated { get; set; } = false;

    public bool InsertTabsInNoteContent { get; set; } = true;

    public bool DisplayNoteContentAsMarkdown { get; set; } = true;

    public bool ShowGroupedByCategory { get; set; } = false;

    public bool ShowLastTimeDone { get; set; } = true;

    public bool HideCompletedTasks { get; set; } = true;

    public bool ShowOnlyOverSelectedRatioMin { get; set; } = false;

    public bool ShowOnlyUnderSelectedRatioMax { get; set; } = false;

    public int SelectedRatioMin { get; set; } = 50;

    public int SelectedRatioMax { get; set; } = 150;

    public int? PlannedFromDayOffset { get; set; }

    public int? PlannedToDayOffset { get; set; }

    public int? DoneFromDayOffset { get; set; }

    public int? DoneToDayOffset { get; set; }

    public bool ShowDoneInRange { get; set; } = true;

    public int HorizontalMargin { get; set; } = 1;

    public int VerticalMargin { get; set; } = 1;

    // null means off; otherwise the time of day the daily summary is delivered.
    public TimeOnly? NotificationTime { get; set; }

    // null means off; otherwise minutes before a timed task's planned moment.
    public int? NotificationLeadMinutes { get; set; }

    public DigestContent NotificationContent { get; set; }

    public Priority NotificationMinimumPriority { get; set; }

    public int NotificationHabitThreshold { get; set; } = 100;

    public bool NotificationIncludeOverdueTasks { get; set; }

    public FilterDisplay CategoryFilterDisplay { get; set; } = FilterDisplay.CheckBoxes;

    public FilterDisplay PriorityFilterDisplay { get; set; } = FilterDisplay.CheckBoxes;

    public long? SelectedCategoryId { get; set; }

    public Priority? SelectedPriority { get; set; }

    public List<long> HiddenCategoryIds { get; set; } = [];

    public Dictionary<Priority, bool> ShowPriority { get; set; } = new()
    {
        { Priority.None, true },
        { Priority.VeryLow, true },
        { Priority.Low, true },
        { Priority.Medium, true },
        { Priority.High, true },
        { Priority.VeryHigh, true }
    };

    public Dictionary<QuerySection, bool> FoldSection { get; set; } = new()
    {
        { QuerySection.Search, false },
        { QuerySection.FilterByDate, false },
        { QuerySection.FilterByCategory, false },
        { QuerySection.FilterByPriority, false },
        { QuerySection.FilterByStatus, false },
        { QuerySection.Sort, false }
    };

    public Dictionary<ContentType, Sort> SortBy { get; set; } = new()
    {
        { ContentType.Note, Sort.Priority },
        { ContentType.Task, Sort.PlannedAt },
        { ContentType.Habit, Sort.SelectedRatio }
    };
}
