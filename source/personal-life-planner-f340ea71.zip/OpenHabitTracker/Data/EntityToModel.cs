using OpenHabitTracker.Data.Entities;
using OpenHabitTracker.Data.Models;

namespace OpenHabitTracker.Data;

public static class EntityToModel
{
    public static CategoryModel ToModel(this CategoryEntity entity)
    {
        CategoryModel model = new();
        entity.CopyToModel(model);
        return model;
    }

    public static void CopyToModel(this CategoryEntity entity, CategoryModel model)
    {
        model.Id = entity.Id;
        model.UserId = entity.UserId;
        model.Title = entity.Title;
        model.IsCollapsed = entity.IsCollapsed;
        model.CompletionRule = entity.CompletionRule;
    }

    public static HabitModel ToModel(this HabitEntity entity)
    {
        HabitModel model = new();
        entity.CopyToModel(model);
        return model;
    }

    public static void CopyToModel(this HabitEntity entity, HabitModel model)
    {
        model.Id = entity.Id;
        model.CategoryId = entity.CategoryId;
        model.Priority = entity.Priority;
        model.IsDeleted = entity.IsDeleted;
        model.Title = entity.Title;
        model.Color = entity.Color;
        model.CreatedAt = entity.CreatedAt;
        model.UpdatedAt = entity.UpdatedAt;

        model.RepeatCount = entity.RepeatCount;
        model.RepeatInterval = entity.RepeatInterval;
        model.RepeatPeriod = entity.RepeatPeriod;
        model.DisplayMetric = entity.DisplayMetric;
        model.TargetQuantity = entity.TargetQuantity;
        model.Duration = entity.Duration;
        model.LastTimeDoneAt = entity.LastTimeDoneAt;
        model.StartAt = entity.StartAt;
    }

    public static ItemModel ToModel(this ItemEntity entity)
    {
        ItemModel model = new();
        entity.CopyToModel(model);
        return model;
    }

    public static void CopyToModel(this ItemEntity entity, ItemModel model)
    {
        model.Id = entity.Id;
        model.ParentId = entity.ParentId;
        model.Title = entity.Title;
        model.DoneAt = entity.DoneAt;
    }

    public static NoteModel ToModel(this NoteEntity entity)
    {
        NoteModel model = new();
        entity.CopyToModel(model);
        return model;
    }

    public static void CopyToModel(this NoteEntity entity, NoteModel model)
    {
        model.Id = entity.Id;
        model.CategoryId = entity.CategoryId;
        model.Priority = entity.Priority;
        model.IsDeleted = entity.IsDeleted;
        model.Title = entity.Title;
        model.Color = entity.Color;
        model.CreatedAt = entity.CreatedAt;
        model.UpdatedAt = entity.UpdatedAt;

        model.Content = entity.Content;
    }

    public static PriorityModel ToModel(this PriorityEntity entity)
    {
        PriorityModel model = new();
        entity.CopyToModel(model);
        return model;
    }

    public static void CopyToModel(this PriorityEntity entity, PriorityModel model)
    {
        model.Id = entity.Id;
        model.Title = entity.Title;
    }

    public static UserModel ToModel(this UserEntity entity)
    {
        UserModel model = new();
        entity.CopyToModel(model);
        return model;
    }

    public static void CopyToModel(this UserEntity entity, UserModel model)
    {
        model.Id = entity.Id;
        model.UserName = entity.UserName;
        model.Email = entity.Email;
        model.PasswordHash = entity.PasswordHash;
        model.LastChangeAt = entity.LastChangeAt;
    }

    public static SettingsModel ToModel(this SettingsEntity entity)
    {
        SettingsModel model = new();
        entity.CopyToModel(model);
        return model;
    }

    public static void CopyToModel(this SettingsEntity entity, SettingsModel model)
    {
        model.Id = entity.Id;
        model.UserId = entity.UserId;
        model.IsDarkMode = entity.IsDarkMode;
        model.Theme = entity.Theme;
        model.StartPage = entity.StartPage;
        model.StartSidebar = entity.StartSidebar;
        model.Culture = entity.Culture;
        model.FirstDayOfWeek = entity.FirstDayOfWeek;
        model.DateFormat = entity.DateFormat;
        model.TimeFormat = entity.TimeFormat;
        model.SelectedRatio = entity.SelectedRatio;
        model.BaseUrl = entity.BaseUrl;
        model.Username = entity.Username;
        model.RefreshToken = entity.RefreshToken;
        model.RememberMe = entity.RememberMe;
        model.ShowHelp = entity.ShowHelp;
        model.UncheckAllItemsOnHabitDone = entity.UncheckAllItemsOnHabitDone;
        model.ShowPriorityDropdown = entity.ShowPriorityDropdown;
        model.ShowItemList = entity.ShowItemList;
        model.ShowSmallCalendar = entity.ShowSmallCalendar;
        model.MaxSmallCalendarDays = entity.MaxSmallCalendarDays;
        model.ShowLargeCalendar = entity.ShowLargeCalendar;
        model.ShowHabitStatistics = entity.ShowHabitStatistics;
        model.ShowHabitCharts = entity.ShowHabitCharts;
        model.ShowCategory = entity.ShowCategory;
        model.ShowColor = entity.ShowColor;
        model.ShowCreatedUpdated = entity.ShowCreatedUpdated;
        model.InsertTabsInNoteContent = entity.InsertTabsInNoteContent;
        model.DisplayNoteContentAsMarkdown = entity.DisplayNoteContentAsMarkdown;
        model.ShowGroupedByCategory = entity.ShowGroupedByCategory;
        model.ShowLastTimeDone = entity.ShowLastTimeDone;
        model.HideCompletedTasks = entity.HideCompletedTasks;
        model.ShowOnlyOverSelectedRatioMin = entity.ShowOnlyOverSelectedRatioMin;
        model.ShowOnlyUnderSelectedRatioMax = entity.ShowOnlyUnderSelectedRatioMax;
        model.SelectedRatioMin = entity.SelectedRatioMin;
        model.SelectedRatioMax = entity.SelectedRatioMax;
        model.PlannedFromDayOffset = entity.PlannedFromDayOffset;
        model.PlannedToDayOffset = entity.PlannedToDayOffset;
        model.DoneFromDayOffset = entity.DoneFromDayOffset;
        model.DoneToDayOffset = entity.DoneToDayOffset;
        model.ShowDoneInRange = entity.ShowDoneInRange;
        model.HorizontalMargin = entity.HorizontalMargin;
        model.VerticalMargin = entity.VerticalMargin;
        model.NotificationTime = entity.NotificationTime;
        model.NotificationLeadMinutes = entity.NotificationLeadMinutes;
        model.NotificationContent = entity.NotificationContent;
        model.NotificationMinimumPriority = entity.NotificationMinimumPriority;
        model.NotificationHabitThreshold = entity.NotificationHabitThreshold;
        model.NotificationIncludeOverdueTasks = entity.NotificationIncludeOverdueTasks;
        model.CategoryFilterDisplay = entity.CategoryFilterDisplay;
        model.PriorityFilterDisplay = entity.PriorityFilterDisplay;
        model.SelectedCategoryId = entity.SelectedCategoryId;
        model.SelectedPriority = entity.SelectedPriority;
        model.HiddenCategoryIds = entity.HiddenCategoryIds;
        model.ShowPriority = entity.ShowPriority;
        model.FoldSection = entity.FoldSection;
        model.SortBy = entity.SortBy;
    }

    public static TaskModel ToModel(this TaskEntity entity)
    {
        TaskModel model = new();
        entity.CopyToModel(model);
        return model;
    }

    public static void CopyToModel(this TaskEntity entity, TaskModel model)
    {
        model.Id = entity.Id;
        model.CategoryId = entity.CategoryId;
        model.Priority = entity.Priority;
        model.IsDeleted = entity.IsDeleted;
        model.Title = entity.Title;
        model.Color = entity.Color;
        model.CreatedAt = entity.CreatedAt;
        model.UpdatedAt = entity.UpdatedAt;

        model.StartedAt = entity.StartedAt;
        model.CompletedAt = entity.CompletedAt;
        model.PlannedAt = entity.PlannedAt;
        model.Duration = entity.Duration;
    }

    public static TimeModel ToModel(this TimeEntity entity)
    {
        TimeModel model = new();
        entity.CopyToModel(model);
        return model;
    }

    public static void CopyToModel(this TimeEntity entity, TimeModel model)
    {
        model.Id = entity.Id;
        model.HabitId = entity.HabitId;
        model.StartedAt = entity.StartedAt;
        model.CompletedAt = entity.CompletedAt;
        model.Quantity = entity.Quantity;
    }
}
