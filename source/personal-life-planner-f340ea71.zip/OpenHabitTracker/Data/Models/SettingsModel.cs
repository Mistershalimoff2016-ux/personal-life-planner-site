namespace OpenHabitTracker.Data.Models;

public class SettingsModel
{
    internal long Id { get; set; }

    public long UserId { get; set; }

    public bool IsDarkMode { get; set; } = true;

    public string Theme { get; set; } = "default";

    public string StartPage { get; set; } = string.Empty;

    public string StartSidebar { get; set; } = string.Empty;

    public string Culture { get; set; } = "en";

    public DayOfWeek FirstDayOfWeek { get; set; } = DayOfWeek.Monday;

    public string? DateFormat { get; set; }

    public string? TimeFormat { get; set; }

    public Ratio SelectedRatio { get; set; }

    public string BaseUrl { get; set; } = string.Empty;

    public string Username { get; set; } = string.Empty;

    public string RefreshToken { get; set; } = string.Empty;

    public bool RememberMe { get; set; } = true;

    public bool ShowHelp { get; set; } = true;

    public bool UncheckAllItemsOnHabitDone { get; set; } = false;

    public bool ShowPriorityDropdown { get; set; } = true;

    public bool ShowItemList { get; set; } = true;

    public bool ShowSmallCalendar { get; set; } = true;

    public int MaxSmallCalendarDays { get; set; } = 0;

    public bool ShowLargeCalendar { get; set; } = true;

    public bool ShowHabitStatistics { get; set; } = false;

    public bool ShowHabitCharts { get; set; } = false;

    public bool ShowCategory { get; set; } = true;

    public bool ShowColor { get; set; } = true;

    public bool ShowCreatedUpdated { get; set; } = false;

    public bool InsertTabsInNoteContent { get; set; } = true;

    public bool DisplayNoteContentAsMarkdown { get; set; } = true;

    public bool ShowGroupedByCategory { get; set; } = false;

    public bool ShowLastTimeDone { get; set; } = true;

    public bool HideCompletedTasks { get; set; } = true;

    public bool ShowOnlyOverSelectedRatioMin { get; set; } = false;

    public bool ShowOnlyUnderSelectedRatioMax { get; set; } = false;

    public int SelectedRatioMin { get; set; } = 50;

    public int SelectedRatioMax { get; set; } = 150;

    public int? PlannedFromDayOffset { get; set; }

    public int? PlannedToDayOffset { get; set; }

    public int? DoneFromDayOffset { get; set; }

    public int? DoneToDayOffset { get; set; }

    public bool ShowDoneInRange { get; set; } = true;

    public int HorizontalMargin { get; set; } = 1;

    public int VerticalMargin { get; set; } = 1;

    public TimeOnly? NotificationTime { get; set; }

    public int? NotificationLeadMinutes { get; set; }

    // Split for the two selects the way ItemsModel splits Duration. Off is the checkbox's job, so
    // an unset lead time still reads as zero rather than as a value the selects cannot show.
    internal int NotificationLeadHour => NotificationLeadMinutes is int minutes ? minutes / 60 : 0;

    internal int NotificationLeadMinute => NotificationLeadMinutes is int minutes ? minutes % 60 : 0;

    public DigestContent NotificationContent { get; set; }

    public Priority NotificationMinimumPriority { get; set; }

    public int NotificationHabitThreshold { get; set; } = 100;

    public bool NotificationIncludeOverdueTasks { get; set; }

    public FilterDisplay CategoryFilterDisplay { get; set; } = FilterDisplay.CheckBoxes;

    public FilterDisplay PriorityFilterDisplay { get; set; } = FilterDisplay.CheckBoxes;

    public long? SelectedCategoryId { get; set; }

    public Priority? SelectedPriority { get; set; }

    public List<long> HiddenCategoryIds { get; set; } = [];

    public Dictionary<Priority, bool> ShowPriority { get; set; } = new()
    {
        { Priority.None, true },
        { Priority.VeryLow, true },
        { Priority.Low, true },
        { Priority.Medium, true },
        { Priority.High, true },
        { Priority.VeryHigh, true }
    };

    public Dictionary<QuerySection, bool> FoldSection { get; set; } = new()
    {
        { QuerySection.Search, false },
        { QuerySection.FilterByDate, false },
        { QuerySection.FilterByCategory, false },
        { QuerySection.FilterByPriority, false },
        { QuerySection.FilterByStatus, false },
        { QuerySection.Sort, false }
    };

    public Dictionary<ContentType, Sort> SortBy { get; set; } = new()
    {
        { ContentType.Note, Sort.Priority },
        { ContentType.Task, Sort.PlannedAt },
        { ContentType.Habit, Sort.SelectedRatio }
    };

    // Caps the day offsets so resolving them can never overflow DateTime in AddDays.
    public const int MaxDayOffset = 9000;

    // Resolves the signed day offsets into concrete date bounds relative to the given day.
    // Resolving at query time is what keeps the filter from going stale.
    // A null offset is an open-ended bound; both null means the filter is off (start and end null).
    internal (DateTime? Start, DateTime? End) ResolvePlannedRange(DateTime today) =>
        ResolveRange(PlannedFromDayOffset, PlannedToDayOffset, today);

    internal (DateTime? Start, DateTime? End) ResolveDoneRange(DateTime today) =>
        ResolveRange(DoneFromDayOffset, DoneToDayOffset, today);

    private static (DateTime? Start, DateTime? End) ResolveRange(int? fromOffset, int? toOffset, DateTime today)
    {
        DateTime? start = fromOffset is int from ? today.Date.AddDays(Math.Clamp(from, -MaxDayOffset, MaxDayOffset)) : null;
        DateTime? end = toOffset is int to ? today.Date.AddDays(Math.Clamp(to, -MaxDayOffset, MaxDayOffset)) : null;

        return (start, end);
    }

    public static SettingsModel GetDefaultSettings(long userId)
    {
        return new SettingsModel
        {
            UserId = userId,
            IsDarkMode = true,
            Theme = "default",
            StartPage = "/today",
            StartSidebar = "",
            Culture = "ru",
            FirstDayOfWeek = DayOfWeek.Monday,
            DateFormat = null,
            TimeFormat = null,
            SelectedRatio = Ratio.ElapsedToDesired,
            BaseUrl = "",
            Username = "",
            RefreshToken = "",
            RememberMe = true,
            ShowHelp = true,
            UncheckAllItemsOnHabitDone = false,
            ShowPriorityDropdown = true,
            ShowItemList = true,
            ShowSmallCalendar = true,
            MaxSmallCalendarDays = 0,
            ShowLargeCalendar = true,
            ShowHabitStatistics = false,
            ShowHabitCharts = false,
            ShowCategory = true,
            ShowColor = true,
            ShowCreatedUpdated = false,
            InsertTabsInNoteContent = true,
            DisplayNoteContentAsMarkdown = true,
            ShowGroupedByCategory = false,
            ShowLastTimeDone = true,
            HideCompletedTasks = true,
            ShowOnlyOverSelectedRatioMin = false,
            ShowOnlyUnderSelectedRatioMax = false,
            SelectedRatioMin = 50,
            SelectedRatioMax = 150,
            PlannedFromDayOffset = null,
            PlannedToDayOffset = null,
            DoneFromDayOffset = null,
            DoneToDayOffset = null,
            ShowDoneInRange = true,
            HorizontalMargin = 1,
            VerticalMargin = 3,
            NotificationTime = null,
            NotificationLeadMinutes = null,
            NotificationContent = DigestContent.Both,
            NotificationMinimumPriority = Priority.None,
            NotificationHabitThreshold = 100,
            NotificationIncludeOverdueTasks = false,
            CategoryFilterDisplay = FilterDisplay.CheckBoxes,
            PriorityFilterDisplay = FilterDisplay.CheckBoxes,
            SelectedCategoryId = null,
            SelectedPriority = null,
            HiddenCategoryIds = [],
            ShowPriority = new()
            {
                { Priority.None, true },
                { Priority.VeryLow, true },
                { Priority.Low, true },
                { Priority.Medium, true },
                { Priority.High, true },
                { Priority.VeryHigh, true }
            },
            FoldSection = new()
            {
                { QuerySection.Search, false },
                { QuerySection.FilterByDate, false },
                { QuerySection.FilterByCategory, false },
                { QuerySection.FilterByPriority, false },
                { QuerySection.FilterByStatus, false },
                { QuerySection.Sort, false }
            },
            SortBy = new()
            {
                { ContentType.Note, Sort.Priority },
                { ContentType.Task, Sort.PlannedAt },
                { ContentType.Habit, Sort.SelectedRatio }
            }
        };
    }
}
