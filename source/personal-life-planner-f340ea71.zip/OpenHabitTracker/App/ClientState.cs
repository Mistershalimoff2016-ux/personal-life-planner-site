using OpenHabitTracker.Data;
using OpenHabitTracker.Data.Entities;
using OpenHabitTracker.Data.Models;
using OpenHabitTracker.Localization;

namespace OpenHabitTracker.App;

public class ClientState
{
    private readonly Dictionary<DataLocation, IDataAccess> _dataAccessByLocation;
    private readonly MarkdownToHtml _markdownToHtml;
    private readonly ICultureTarget _cultureTarget;

    private readonly Dictionary<DataLocation, ClientData> _clientDataByLocation;
    private ClientData _clientData;

    public ClientState(IEnumerable<IDataAccess> dataAccess, MarkdownToHtml markdownToHtml, ICultureTarget? cultureTarget = null)
    {
        _dataAccessByLocation = dataAccess.ToDictionary(x => x.DataLocation);
        _markdownToHtml = markdownToHtml;
        _cultureTarget = cultureTarget ?? new ProcessCulture();

        DataLocation = DataLocation.Local;

        _clientDataByLocation = new();

        foreach (var pair in _dataAccessByLocation)
        {
            _clientDataByLocation[pair.Key] = new ClientData(pair.Value, _markdownToHtml);
        }

        _clientData = _clientDataByLocation[DataLocation];

        DataAccess = _dataAccessByLocation[DataLocation];
    }

    public DataLocation DataLocation { get; private set; }

    public IDataAccess DataAccess { get; set; }

    public bool IsRefreshing { get; private set; }

    public string? AutomaticDateFormat { get; set; }

    public string? AutomaticTimeFormat { get; set; }

    public void SetCulture()
    {
        Loc.SetCulture(_cultureTarget, Settings.Culture, Settings.DateFormat ?? AutomaticDateFormat, Settings.TimeFormat ?? AutomaticTimeFormat);
    }

    public UserModel User
    {
        get => _clientData.User;
        set => _clientData.User = value;
    }
    public SettingsModel Settings
    {
        get => _clientData.Settings;
        set => _clientData.Settings = value;
    }
    public Dictionary<long, HabitModel>? Habits
    {
        get => _clientData.Habits;
        set => _clientData.Habits = value;
    }
    public Dictionary<long, NoteModel>? Notes
    {
        get => _clientData.Notes;
        set => _clientData.Notes = value;
    }
    public Dictionary<long, TaskModel>? Tasks
    {
        get => _clientData.Tasks;
        set => _clientData.Tasks = value;
    }
    public Dictionary<long, TimeModel>? Times
    {
        get => _clientData.Times;
        set => _clientData.Times = value;
    }
    public Dictionary<long, ItemModel>? Items
    {
        get => _clientData.Items;
        set => _clientData.Items = value;
    }
    public Dictionary<long, CategoryModel>? Categories
    {
        get => _clientData.Categories;
        set => _clientData.Categories = value;
    }
    public List<HabitModel>? TrashedHabits
    {
        get => _clientData.TrashedHabits;
        set => _clientData.TrashedHabits = value;
    }
    public List<NoteModel>? TrashedNotes
    {
        get => _clientData.TrashedNotes;
        set => _clientData.TrashedNotes = value;
    }
    public List<TaskModel>? TrashedTasks
    {
        get => _clientData.TrashedTasks;
        set => _clientData.TrashedTasks = value;
    }

    private Func<Task>? _onDataReplaced;

    public void SetDataReplacedAction(Func<Task> onDataReplaced)
    {
        _onDataReplaced = onDataReplaced;
    }

    private async Task DataReplaced()
    {
        if (_onDataReplaced is not null)
            await _onDataReplaced();
    }

    private Func<Task>? _onNewAccount;

    public void SetNewAccountAction(Func<Task> onNewAccount)
    {
        _onNewAccount = onNewAccount;
    }

    public async Task SetDataLocationAndRefresh(DataLocation dataLocation)
    {
        DataLocation = dataLocation;

        _clientData = _clientDataByLocation[DataLocation];

        DataAccess = _dataAccessByLocation[DataLocation];

        if (await RefreshState(reloadUser: DataLocation == DataLocation.Remote) && _onNewAccount is not null)
            await _onNewAccount();
    }

    public async Task LoadUsers() => await LoadUsers(_clientData);

    private async Task LoadUsers(ClientData clientData)
    {
        if (clientData.User.Id == 0)
        {
            IReadOnlyList<UserEntity> users = await DataAccess.GetUsers();

            if (users.Count > 0)
            {
                clientData.User = users[0].ToModel();
            }
            else
            {
                clientData.User = new UserModel
                {
                    UserName = "admin",
                    Email = "admin@admin.com"
                };

                UserEntity userEntity = clientData.User.ToEntity();

                await DataAccess.AddUser(userEntity);

                clientData.User.Id = userEntity.Id;
            }
        }
    }

    public async Task<bool> LoadSettings() => await LoadSettings(_clientData);

    private async Task<bool> LoadSettings(ClientData clientData)
    {
        bool loadWelcomeNote = false;

        if (clientData.Settings.Id == 0)
        {
            IReadOnlyList<SettingsEntity> settings = await DataAccess.GetSettings();

            if (settings.Count > 0)
            {
                clientData.Settings = settings[0].ToModel();
            }
            else
            {
                await LoadUsers(clientData);

                clientData.Settings = SettingsModel.GetDefaultSettings(clientData.User.Id);

                SettingsEntity settingsEntity = clientData.Settings.ToEntity();

                await DataAccess.AddSettings(settingsEntity);

                clientData.Settings.Id = settingsEntity.Id;

                loadWelcomeNote = true;
            }
        }

        return loadWelcomeNote;
    }

    public async Task UpdateSettings()
    {
        if (await DataAccess.GetSettings(Settings.Id) is SettingsEntity settings)
        {
            Settings.CopyToEntity(settings);

            await DataAccess.UpdateSettings(settings);
        }
    }

    public async Task UpdateLoginSettings()
    {
        await DataAccess.UpdateLoginSettings(Settings.Id, Settings.BaseUrl, Settings.Username, Settings.RefreshToken);
    }

    public async Task LoadHabits() => await LoadHabits(_clientData);

    private async Task LoadHabits(ClientData clientData)
    {
        if (clientData.Habits is null)
        {
            await LoadCategories(clientData);

            await LoadTimes(clientData); // TODO:: remove temp fix (needed to get TimesDoneByDay, TotalTimeSpent, AverageTimeSpent, AverageInterval)

            IReadOnlyList<HabitEntity> habits = await DataAccess.GetHabits();

            // a load that overlapped this one has filled it, and its habits are already in the categories
            if (clientData.Habits is not null)
                return;

            clientData.Habits = habits.Select(x =>
            {
                HabitModel m = x.ToModel();
                m.TimesDone = clientData.Times!.Values.Where(y => y.HabitId == x.Id).ToList(); // TODO:: remove temp fix (needed to get TimesDoneByDay, TotalTimeSpent, AverageTimeSpent, AverageInterval)
                return m;
            }).ToDictionary(x => x.Id);

            foreach (HabitModel habit in clientData.Habits.Values) // TODO:: remove temp fix (needed to get TimesDoneByDay, TotalTimeSpent, AverageTimeSpent, AverageInterval)
            {
                habit.RefreshTimesDoneByDay(); // TODO:: remove temp fix (needed to get TimesDoneByDay, TotalTimeSpent, AverageTimeSpent, AverageInterval)

                if (habit.CategoryId != 0 && clientData.Categories!.TryGetValue(habit.CategoryId, out CategoryModel? habitCategory))
                    habitCategory.Habits.Add(habit);
            }
        }
    }

    public async Task LoadNotes() => await LoadNotes(_clientData);

    private async Task LoadNotes(ClientData clientData)
    {
        if (clientData.Notes is null)
        {
            await LoadCategories(clientData);

            IReadOnlyList<NoteEntity> notes = await DataAccess.GetNotes();

            // a load that overlapped this one has filled it, and its notes are already in the categories
            if (clientData.Notes is not null)
                return;

            clientData.Notes = notes.Select(x =>
            {
                NoteModel m = x.ToModel();
                m.ContentMarkdown = _markdownToHtml.GetMarkdown(x.Content);
                return m;
            }).ToDictionary(x => x.Id);

            foreach (NoteModel note in clientData.Notes.Values)
            {
                if (note.CategoryId != 0 && clientData.Categories!.TryGetValue(note.CategoryId, out CategoryModel? noteCategory))
                    noteCategory.Notes.Add(note);
            }
        }
    }

    public async Task LoadTasks() => await LoadTasks(_clientData);

    private async Task LoadTasks(ClientData clientData)
    {
        if (clientData.Tasks is null)
        {
            await LoadCategories(clientData);

            IReadOnlyList<TaskEntity> tasks = await DataAccess.GetTasks();

            // a load that overlapped this one has filled it, and its tasks are already in the categories
            if (clientData.Tasks is not null)
                return;

            clientData.Tasks = tasks.Select(x => x.ToModel()).ToDictionary(x => x.Id);

            foreach (TaskModel task in clientData.Tasks.Values)
            {
                if (task.CategoryId != 0 && clientData.Categories!.TryGetValue(task.CategoryId, out CategoryModel? taskCategory))
                    taskCategory.Tasks.Add(task);
            }
        }
    }

    public async Task LoadTimes() => await LoadTimes(_clientData);

    private async Task LoadTimes(ClientData clientData)
    {
        if (clientData.Times is null)
        {
            IReadOnlyList<TimeEntity> times = await DataAccess.GetTimes();

            // a load that overlapped this one has filled it, and the habits hold its completions
            if (clientData.Times is not null)
                return;

            clientData.Times = times.Select(c => c.ToModel()).ToDictionary(x => x.Id);
        }
    }

    public async Task LoadItems()
    {
        if (Items is null)
        {
            IReadOnlyList<ItemEntity> items = await DataAccess.GetItems();
            Items = items.Select(c => c.ToModel()).ToDictionary(x => x.Id);
        }
    }

    public async Task LoadCategories() => await LoadCategories(_clientData);

    private async Task LoadCategories(ClientData clientData)
    {
        if (clientData.Categories is null)
        {
            IReadOnlyList<CategoryEntity> categories = await DataAccess.GetCategories();

            // a load that overlapped this one has filled it, and the loaded lists are in its categories
            if (clientData.Categories is not null)
                return;

            clientData.Categories = categories.Select(c => c.ToModel()).ToDictionary(x => x.Id);
        }
    }

    public async Task LoadTrash()
    {
        if (TrashedHabits is null || TrashedNotes is null || TrashedTasks is null)
        {
            await LoadContent();

            if (Habits is not null)
                TrashedHabits = Habits.Values.Where(m => m.IsDeleted).ToList();
            if (Notes is not null)
                TrashedNotes = Notes.Values.Where(m => m.IsDeleted).ToList();
            if (Tasks is not null)
                TrashedTasks = Tasks.Values.Where(m => m.IsDeleted).ToList();
        }
    }

    private async Task LoadContent() => await LoadContent(_clientData);

    private async Task LoadContent(ClientData clientData)
    {
        await LoadCategories(clientData);

        await LoadHabits(clientData);
        await LoadNotes(clientData);
        await LoadTasks(clientData);
    }

    public async Task DeleteAllData()
    {
        await DataAccess.DeleteAllUserData();

        await RefreshState();
    }

    // Loaded data stays on screen and usable until the reload is complete, so a change made during the reload is saved,
    // and a reload that fails partway leaves it as it was.
    // A location with nothing loaded yet, like the one a login switches to, is loaded in place,
    // so a page that loads during the reload shares its lists instead of fetching them twice.
    public async Task<bool> RefreshState(bool reloadUser = false)
    {
        DataLocation dataLocation = DataLocation;

        bool loadInPlace = Categories is null && Times is null && Habits is null && Notes is null && Tasks is null;

        ClientData clientData = loadInPlace ? _clientData : new(DataAccess, _markdownToHtml);

        UserModel user = User;
        SettingsModel settings = Settings;

        IsRefreshing = true;
        bool loadWelcomeNote;

        try
        {
            if (reloadUser)
            {
                clientData.User = new();
                await LoadUsers(clientData);
            }
            else
            {
                clientData.User = user;
            }

            clientData.Settings = new();

            loadWelcomeNote = await LoadSettings(clientData);

            await LoadContent(clientData);
        }
        catch (Exception)
        {
            // The lists loaded in place hold this location's data, but the reset user and settings would show defaults.
            if (loadInPlace)
            {
                clientData.User = user;
                clientData.Settings = settings;
            }

            throw;
        }
        finally
        {
            IsRefreshing = false;
        }

        if (!loadInPlace)
        {
            _clientDataByLocation[dataLocation] = clientData;

            if (DataLocation == dataLocation)
                _clientData = clientData;
        }

        await DataReplaced();

        return loadWelcomeNote;
    }

    public async Task<UserImportExportData> GetUserData()
    {
        await LoadSettings();

        await LoadContent();

        // this is the only place that calls InitializeItems

        // but InitializeTimes can be called from InitializeHabits - so they have old data and this call does nothing because of the null check

        // Times, Items inside every task/habit could be more up to date

        Times = null; // needed because lazy load might not load all the times (Habits view was not opened)
        await LoadTimes();

        Items = null; // needed because lazy load might not load all the items (Tasks / Habits view was not opened)
        await LoadItems();

        if (Categories is null || Notes is null || Tasks is null || Habits is null || Times is null || Items is null)
            throw new NullReferenceException();

        Dictionary<long, List<HabitModel>> habitsByCategoryId = Habits.Values.GroupBy(x => x.CategoryId).ToDictionary(g => g.Key, g => g.ToList());
        Dictionary<long, List<NoteModel>> notesByCategoryId = Notes.Values.GroupBy(x => x.CategoryId).ToDictionary(g => g.Key, g => g.ToList());
        Dictionary<long, List<TaskModel>> tasksByCategoryId = Tasks.Values.GroupBy(x => x.CategoryId).ToDictionary(g => g.Key, g => g.ToList());
        Dictionary<long, List<TimeModel>> timesByHabitId = Times.Values.GroupBy(x => x.HabitId).ToDictionary(g => g.Key, g => g.ToList());
        Dictionary<long, List<ItemModel>> itemsByParentId = Items.Values.GroupBy(x => x.ParentId).ToDictionary(g => g.Key, g => g.ToList());

        // export a copy with the device-scoped block reset - an address and a login name in a file
        // that gets attached to bug reports are most of a credential pair
        SettingsModel settings = Settings.ToEntity().ToModel();
        settings.BaseUrl = string.Empty;
        settings.Username = string.Empty;
        settings.RefreshToken = string.Empty;
        settings.RememberMe = true;

        UserImportExportData userData = new()
        {
            Settings = settings,
            Categories = Categories.Values.ToList()
        };

        /*
        - no category, no items --> no problem
        - categories, no items --> no problem
        - no category, items --> add one default category with id 0, items already have CategoryId 0 by default
        - categories, items
            - every item has CategoryId != 0 --> no problem
            - some items have CategoryId != 0 --> add one default category with id 0, items already have CategoryId 0 by default
        */

        if (userData.Categories.Count == 0 ||
            Habits.Values.Any(x => x.CategoryId == 0) ||
            Notes.Values.Any(x => x.CategoryId == 0) ||
            Tasks.Values.Any(x => x.CategoryId == 0))
        {
            CategoryModel category = new() { UserId = User.Id };

            userData.Categories.Add(category);
        }

        foreach (CategoryModel category in userData.Categories)
        {
            if (notesByCategoryId.TryGetValue(category.Id, out List<NoteModel>? notes))
                category.Notes = notes;
            if (tasksByCategoryId.TryGetValue(category.Id, out List<TaskModel>? tasks))
                category.Tasks = tasks;
            if (habitsByCategoryId.TryGetValue(category.Id, out List<HabitModel>? habits))
                category.Habits = habits;
        }

        // set Items, Times in case the task, habit was not displayed / initialized yet

        // this would not be needed if every task/habit was already initialized

        foreach (TaskModel task in Tasks.Values)
        {
            task.Items ??= itemsByParentId.GetValueOrDefault(task.Id);
        }

        foreach (HabitModel habit in Habits.Values)
        {
            habit.Items ??= itemsByParentId.GetValueOrDefault(habit.Id);

            habit.TimesDone ??= timesByHabitId.GetValueOrDefault(habit.Id);
        }

        return userData;
    }

    public async Task SetUserData(UserImportExportData userData)
    {
        await ReplaceSettings(userData.Settings);

        await AddUserData(userData.Categories);
    }

    public async Task ReplaceSettings(SettingsModel settingsModel)
    {
        settingsModel.UserId = User.Id;

        // keep this device's block - the file carries the blanks written by the export above
        settingsModel.BaseUrl = Settings.BaseUrl;
        settingsModel.Username = Settings.Username;
        settingsModel.RefreshToken = Settings.RefreshToken;
        settingsModel.RememberMe = Settings.RememberMe;

        // keep this device's category filter - the file holds the ids of the database it came from,
        // and the imported categories get new ids
        settingsModel.HiddenCategoryIds = Settings.HiddenCategoryIds;
        settingsModel.SelectedCategoryId = Settings.SelectedCategoryId;

        if (Settings.Id == 0)
        {
            SettingsEntity settings = settingsModel.ToEntity();

            await DataAccess.AddSettings(settings);

            settingsModel.Id = settings.Id;

            Settings = settingsModel;
        }
        else if (await DataAccess.GetSettings(Settings.Id) is SettingsEntity settings)
        {
            settingsModel.Id = Settings.Id;

            settingsModel.CopyToEntity(settings);

            await DataAccess.UpdateSettings(settings);

            Settings = settingsModel;
        }
    }

    // Adds the categories with their notes, tasks and habits and leaves the settings as they are.
    public async Task AddUserData(List<CategoryModel> categoryModels)
    {
        // The new models are added to the loaded lists, so they have to be complete before it.
        await LoadContent();

        await AddUserData(UserDataMerge.AllNew(categoryModels));
    }

    // Matches the categories against the data already there and writes nothing.
    // The data is read from the store rather than from the loaded lists, because a refresh running at the
    // same time, like the one after Delete all data, leaves the old lists in place until it has reloaded them.
    public async Task<UserDataMerge> MergeUserData(List<CategoryModel> categoryModels, MergeOptions? options = null)
    {
        // The import adds to the loaded lists, so they have to be complete before it.
        await LoadContent();

        IReadOnlyList<CategoryEntity> categories = await DataAccess.GetCategories();
        IReadOnlyList<NoteEntity> notes = await DataAccess.GetNotes();
        IReadOnlyList<TaskEntity> tasks = await DataAccess.GetTasks();
        IReadOnlyList<HabitEntity> habits = await DataAccess.GetHabits();
        IReadOnlyList<ItemEntity> items = await DataAccess.GetItems();
        IReadOnlyList<TimeEntity> times = await DataAccess.GetTimes();

        return UserDataMerge.Create(
            categoryModels,
            categories.Select(x => x.ToModel()),
            notes.Select(x => x.ToModel()),
            tasks.Select(x => x.ToModel()),
            habits.Select(x => x.ToModel()),
            items.Select(x => x.ToModel()),
            times.Select(x => x.ToModel()),
            options);
    }

    // Adds what the merge holds and leaves the settings as they are.
    public async Task AddUserData(UserDataMerge merge)
    {
        if (merge.New.IsEmpty)
        {
            await DataReplaced();

            return;
        }

        foreach (CategoryModel category in merge.Categories)
        {
            category.UserId = User.Id;
        }

        // add categories to DB

        List<(CategoryModel Model, CategoryEntity Entity)> categories = merge.Categories
            .Where(x => !string.IsNullOrEmpty(x.Title)) // don't add the default category with no Title
            .Select(x => (Model: x, Entity: x.ToEntity()))
            .ToList();

        await DataAccess.AddCategories(categories.Select(x => x.Entity).ToList());

        // each CategoryEntity now has the id, set it to CategoryModel and to all items

        foreach ((CategoryModel Model, CategoryEntity Entity) in categories)
        {
            Model.Id = Entity.Id;

            Model.Notes.ForEach(x => x.CategoryId = Model.Id);
            Model.Tasks.ForEach(x => x.CategoryId = Model.Id);
            Model.Habits.ForEach(x => x.CategoryId = Model.Id);
        }

        // add all items to DB, including those from the default category that have CategoryId 0,
        // and those of categories that already exist

        List<(NoteModel Model, NoteEntity Entity)> notes = merge.Categories.SelectMany(x => x.Notes).Concat(merge.Notes).Select(x => (Model: x, Entity: x.ToEntity())).ToList();
        List<(TaskModel Model, TaskEntity Entity)> tasks = merge.Categories.SelectMany(x => x.Tasks).Concat(merge.Tasks).Select(x => (Model: x, Entity: x.ToEntity())).ToList();
        List<(HabitModel Model, HabitEntity Entity)> habits = merge.Categories.SelectMany(x => x.Habits).Concat(merge.Habits).Select(x => (Model: x, Entity: x.ToEntity())).ToList();

        await DataAccess.AddNotes(notes.Select(x => x.Entity).ToList());
        await DataAccess.AddTasks(tasks.Select(x => x.Entity).ToList());
        await DataAccess.AddHabits(habits.Select(x => x.Entity).ToList());

        // NoteEntity TaskEntity HabitEntity have id now, set it to NoteModel TaskModel HabitModel

        foreach ((NoteModel Model, NoteEntity Entity) in notes)
        {
            Model.Id = Entity.Id;

            Model.ContentMarkdown = _markdownToHtml.GetMarkdown(Model.Content);
        }

        foreach ((TaskModel Model, TaskEntity Entity) in tasks)
        {
            Model.Id = Entity.Id;

            Model.Items?.ForEach(x => x.ParentId = Model.Id);
        }

        foreach ((HabitModel Model, HabitEntity Entity) in habits)
        {
            Model.Id = Entity.Id;

            Model.Items?.ForEach(x => x.ParentId = Model.Id);
            Model.TimesDone?.ForEach(x => x.HabitId = Model.Id);

            Model.RefreshTimesDoneByDay();
        }

        // add all task items and habit items to DB

        List<(ItemModel Model, ItemEntity Entity)> items =
            [
                .. tasks.Where(x => x.Model.Items is not null).SelectMany(x => x.Model.Items!).Select(x => (Model: x, Entity: x.ToEntity())),
                .. habits.Where(x => x.Model.Items is not null).SelectMany(x => x.Model.Items!).Select(x => (Model: x, Entity: x.ToEntity())),
                .. merge.Items.Select(x => (Model: x, Entity: x.ToEntity()))
            ];

        await DataAccess.AddItems(items.Select(x => x.Entity).ToList());

        // each ItemEntity now has id, set it to ItemModel

        items.ForEach(x => x.Model.Id = x.Entity.Id);

        // add all habit times done to DB

        List<(TimeModel Model, TimeEntity Entity)> times = habits.Where(x => x.Model.TimesDone is not null).SelectMany(x => x.Model.TimesDone!).Concat(merge.Times).Select(x => (Model: x, Entity: x.ToEntity())).ToList();

        await DataAccess.AddTimes(times.Select(x => x.Entity).ToList());

        // each TimeEntity now has id, set it to TimeModel

        times.ForEach(x => x.Model.Id = x.Entity.Id);

        // add every model to the class member dictionary

        if (Habits is null) Habits = habits.ToDictionary(x => x.Model.Id, x => x.Model);
        else foreach (var pair in habits.ToDictionary(x => x.Model.Id, x => x.Model)) Habits[pair.Key] = pair.Value;

        if (Notes is null) Notes = notes.ToDictionary(x => x.Model.Id, x => x.Model);
        else foreach (var pair in notes.ToDictionary(x => x.Model.Id, x => x.Model)) Notes[pair.Key] = pair.Value;

        if (Tasks is null) Tasks = tasks.ToDictionary(x => x.Model.Id, x => x.Model);
        else foreach (var pair in tasks.ToDictionary(x => x.Model.Id, x => x.Model)) Tasks[pair.Key] = pair.Value;

        if (Times is null) Times = times.ToDictionary(x => x.Model.Id, x => x.Model);
        else foreach (var pair in times.ToDictionary(x => x.Model.Id, x => x.Model)) Times[pair.Key] = pair.Value;

        if (Items is null) Items = items.ToDictionary(x => x.Model.Id, x => x.Model);
        else foreach (var pair in items.ToDictionary(x => x.Model.Id, x => x.Model)) Items[pair.Key] = pair.Value;

        if (Categories is null) Categories = categories.ToDictionary(x => x.Model.Id, x => x.Model);
        else foreach (var pair in categories.ToDictionary(x => x.Model.Id, x => x.Model)) Categories[pair.Key] = pair.Value;

        // LoadTrash builds the trash lists only once, so a list already built gets the imported trashed items here.
        TrashedNotes?.AddRange(notes.Select(x => x.Model).Where(x => x.IsDeleted));
        TrashedTasks?.AddRange(tasks.Select(x => x.Model).Where(x => x.IsDeleted));
        TrashedHabits?.AddRange(habits.Select(x => x.Model).Where(x => x.IsDeleted));

        // no CategoryModel sub-list wiring for the new categories, unlike LoadNotes / LoadTasks / LoadHabits.
        // those build fresh models out of entities, so the sub-lists start empty;
        // here notes, tasks and habits are the flattened sub-lists themselves (SelectMany above),
        // and they came from the CategoryModel instances just put into Categories,
        // so every model is already in its category - adding it again renders it twice in grouped view.

        await WireIntoExistingData(merge);

        if (merge.HiddenCategories.Count > 0)
        {
            Settings.HiddenCategoryIds.AddRange(merge.HiddenCategories.Select(x => x.Id));

            await UpdateSettings();
        }

        await DataReplaced();
    }

    // The new models of a merge belong to categories, tasks and habits that are already loaded, and
    // whose lists are filled only once, so the new ones are added to those lists.
    private async Task WireIntoExistingData(UserDataMerge merge)
    {
        foreach (NoteModel note in merge.Notes)
        {
            if (Categories!.TryGetValue(note.CategoryId, out CategoryModel? category))
                category.Notes.Add(note);
        }

        foreach (TaskModel task in merge.Tasks)
        {
            if (Categories!.TryGetValue(task.CategoryId, out CategoryModel? category))
                category.Tasks.Add(task);
        }

        foreach (HabitModel habit in merge.Habits)
        {
            if (Categories!.TryGetValue(habit.CategoryId, out CategoryModel? category))
                category.Habits.Add(habit);
        }

        // A list that is still null is loaded later, with the new items and completions in it.

        foreach (ItemModel item in merge.Items)
        {
            if (Tasks!.TryGetValue(item.ParentId, out TaskModel? task))
                task.Items?.Add(item);
            else if (Habits!.TryGetValue(item.ParentId, out HabitModel? habit))
                habit.Items?.Add(item);
        }

        foreach (IGrouping<long, TimeModel> timesOfHabit in merge.Times.GroupBy(x => x.HabitId))
        {
            if (!Habits!.TryGetValue(timesOfHabit.Key, out HabitModel? habit))
                continue;

            if (habit.TimesDone is not null)
            {
                habit.TimesDone.AddRange(timesOfHabit);

                habit.RefreshTimesDoneByDay();
            }

            // LastTimeDoneAt is the latest completion, which an imported completion can be.
            DateTime lastTimeDoneAt = timesOfHabit.Max(x => x.CompletedAt ?? x.StartedAt);

            if (habit.LastTimeDoneAt is null || habit.LastTimeDoneAt < lastTimeDoneAt)
            {
                habit.LastTimeDoneAt = lastTimeDoneAt;

                if (await DataAccess.GetHabit(habit.Id) is HabitEntity habitEntity)
                {
                    habitEntity.LastTimeDoneAt = lastTimeDoneAt;

                    await DataAccess.UpdateHabit(habitEntity);
                    habit.UpdatedAt = habitEntity.UpdatedAt;
                }
            }
        }
    }
}
