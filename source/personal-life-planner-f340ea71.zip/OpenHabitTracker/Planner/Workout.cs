using System.Text.Json;
using OpenHabitTracker.Data.Models;

namespace OpenHabitTracker.Planner;

// Stored as an ordinary note: all existing local stores, sync and backups retain the record.
// Never infer a workout from its title; the explicit versioned envelope is required.
public sealed class Workout
{
    public const string Prefix = "<!-- personal-life-planner:workout:v1 -->\n```json\n";
    public DateTime Date { get; set; } = DateTime.Today;
    public string Kind { get; set; } = "Бокс";
    public int Minutes { get; set; }
    public bool Completed { get; set; }
    public string Feeling { get; set; } = "";
    public string Notes { get; set; } = "";
    public List<Exercise> Exercises { get; set; } = [];

    public string ToContent() => Prefix + JsonSerializer.Serialize(this) + "\n```";

    public static Workout? FromNote(NoteModel note)
    {
        if (note.IsDeleted || !note.Content.StartsWith(Prefix, StringComparison.Ordinal) || !note.Content.EndsWith("\n```", StringComparison.Ordinal))
            return null;
        try
        {
            Workout? workout = JsonSerializer.Deserialize<Workout>(note.Content[Prefix.Length..^4]);
            return workout is { Exercises: not null, Kind: not null, Notes: not null, Feeling: not null }
                && workout.Exercises.All(e => e is not null) ? workout : null;
        }
        catch (JsonException) { return null; }
    }

    public string? Validate()
    {
        if (string.IsNullOrWhiteSpace(Kind)) return "Укажите вид тренировки.";
        if (Minutes < 0 || Minutes > 1440 || (Completed && Minutes == 0)) return "Продолжительность: от 1 до 1440 минут для завершённой тренировки.";
        if (Exercises.Any(e => e is null || e.Sets < 0 || e.Reps < 0 || e.Weight < 0)) return "Подходы, повторения и вес не могут быть отрицательными.";
        return null;
    }

    public static int CountThisWeek(IEnumerable<Workout> workouts, DateTime today)
    {
        DateTime monday = today.Date.AddDays(-(((int)today.DayOfWeek + 6) % 7));
        return workouts.Count(w => w.Completed && w.Date.Date >= monday && w.Date.Date < monday.AddDays(7));
    }
}

public sealed class Exercise
{
    public string Name { get; set; } = "";
    public int? Sets { get; set; }
    public int? Reps { get; set; }
    public decimal? Weight { get; set; }
}
