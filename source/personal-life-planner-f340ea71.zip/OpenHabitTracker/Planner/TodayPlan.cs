using OpenHabitTracker.Data.Models;

namespace OpenHabitTracker.Planner;

public static class TodayPlan
{
    // Include overdue unfinished tasks and today's completions, independently of list filters.
    public static IEnumerable<TaskModel> Tasks(IEnumerable<TaskModel> tasks, DateTime today) => tasks
        .Where(t => !t.IsDeleted && (t.CompletedAt?.Date == today.Date ||
            (t.PlannedAt?.Date == today.Date) ||
            (t.CompletedAt == null && t.PlannedAt?.Date < today.Date)))
        .OrderBy(t => t.CompletedAt != null).ThenBy(t => t.PlannedAt).ThenByDescending(t => t.Priority);
}
